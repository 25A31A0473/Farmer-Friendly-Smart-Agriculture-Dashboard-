import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Volume2, X, Send, Bot, Loader, ChevronDown } from 'lucide-react';

/* ================================================================
   KNOWLEDGE BASE — answers for common farming questions
   ================================================================ */
const KB = {
  en: {
    greeting:   ['Hello! I am AgroSafe AI — your farming assistant. Ask me about weather, crops, or schedules!'],
    weather:    ['Based on current forecasts, temperatures are high with low humidity. Schedule irrigation for early morning.'],
    risk:       ['The current climate risk level is moderate. Watch for heat stress and ensure drip irrigation is active.'],
    crop_now:   ['Based on the current season, you can sow Tomato, Chilli, Sugarcane, or Groundnut in Telangana/AP.'],
    schedule:   ['Visit the Crop Planner page! Select your crop and sowing date to get a complete 7-phase growth schedule.'],
    pest:       ['Common threats this season are Aphids and Whitefly. Spray Neem Oil 5ml/L as a preventive measure.'],
    irrigation: ['Irrigate in early morning (5–7am) or evening (5–7pm) to minimise evaporation. Drip irrigation saves 40% water.'],
    fertiliser: ['At this growth stage, apply 30 kg Urea/acre as top dressing. Spray micronutrients (Zinc 0.5%) if leaves show yellowing.'],
    harvest:    ['Harvest in early morning for best quality. Ensure grain moisture is below 14% before storage.'],
    soil:       ['Test your soil pH annually. Most crops prefer pH 6.0–7.0. Add limestone to raise pH or sulfur to lower it.'],
    market:     ['Check mandi prices at Agmarknet.gov.in or eNAM portal for live commodity prices. The current price for Rice is ₹2250 and Wheat is ₹2125.'],
    community:  ['You can manage your farming group in the Community Alerts dashboard. Set a daily time, and we will call everyone!'],
    remind:     ['I have heard your request. You can set the daily reminder time in the Community Alerts section to notify your whole group.'],
    help:       ['I can answer questions about: weather risk, crops to sow, pest control, irrigation, fertiliser, schedule planning, community alerts, market prices, soil health, finance, loans, and sustainability.'],
    unknown:    ['I am not sure about that. Try asking about weather risk, community group alerts, crop schedule, irrigation, finance, or pest control.'],
    finance:    ['You can apply for micro-loans or crop insurance in the Finance & Loans hub. Try PMFBY for govt insurance, or KCC for low-interest loans.'],
    sustainability: ['To reduce your carbon footprint, we suggest drip irrigation and planting cover crops. Check the Sustainability module for green subsidies.']
  },
  hi: {
    greeting:   ['नमस्ते! मैं AgroSafe AI हूँ — आपका खेती सहायक। मौसम, फसल, या समुदाय अलर्ट के बारे में पूछें!'],
    weather:    ['मौसम पूर्वानुमान के अनुसार, तापमान अधिक है और आर्द्रता कम। सुबह जल्दी सिंचाई करें।'],
    risk:       ['वर्तमान जलवायु जोखिम मध्यम है। गर्मी के तनाव पर ध्यान दें।'],
    crop_now:   ['आप टमाटर, मिर्च, गन्ना, और मूंगफली बो सकते हैं।'],
    market:     ['वर्तमान मंडी भाव: चावल ₹2250, गेहूं ₹2125। वह eNAM पोर्टल पर अधिक जानकारी प्राप्त करें।'],
    community:  ['आप कम्युनिटी अलर्ट डैशबोर्ड में अपने समूह का प्रबंधन कर सकते हैं।'],
    help:       ['मैं मौसम, फसल, सिंचाई, कम्युनिटी अलर्ट और मंडी भाव के बारे में जानकारी दे सकता हूँ।'],
    unknown:    ['मुझे यकीन नहीं। मौसम, समूह अलर्ट, या सिंचाई के बारे में पूछें।'],
  },
  te: {
    greeting:   ['నమస్కారం! నేను AgroSafe AI — మీ వ్యవసాయ సహాయకుడిని. వాతావరణం, పంటలు లేదా కమ్యూనిటీ అలర్ట్‌ల గురించి అడగండి!'],
    weather:    ['వాతావరణ సూచన ప్రకారం, ఉష్ణోగ్రత ఎక్కువగా ఉంది. తెల్లవారుజామమున నీటిపారుదల చేయండి.'],
    risk:       ['వాతావరణ ప్రమాదం మధ్యస్థంగా ఉంది. వేడి ఒత్తిడికి జాగ్రత్తగా ఉండండి.'],
    crop_now:   ['టమాటో, మిర్చి, చెరకు మరియు వేరుశనగ వేయవచ్చు.'],
    market:     ['మండి ధరలు: వరి ₹2250, గోధుమ ₹2125. వివరాలకు eNAM వెబ్సైట్ చూడండి.'],
    community:  ['మీరు కమ్యూనిటీ అలర్ట్‌ల డాష్‌బోర్డ్‌లో మీ సమూహాన్ని నిర్వహించవచ్చు.'],
    help:       ['నేను వాతావరణం, పంటలు, నీటిపారుదల, కమ్యూనిటీ గ్రూప్ మరియు మండి ధరల గురించి చెప్పగలను.'],
    unknown:    ['నాకు తెలియదు. వాతావరణం, కమ్యూనిటీ అలర్ట్ లేదా నీటిపారుదల గురించి అడగండి.'],
  },
};

function classify(text, lang) {
  const t = text.toLowerCase();
  if (/hello|hi|namaste|నమస్కారం|नमस्ते/.test(t)) return 'greeting';
  if (/weather|rain|temperature|forecast|मौसम|వాతావరణం/.test(t)) return 'weather';
  if (/risk|flood|drought|danger|ప్రమాదం|खतरा/.test(t)) return 'risk';
  if (/sow|plant|which crop|what crop|అేమి/.test(t)) return 'crop_now';
  if (/schedule|plan|timeline|phases|షెడ్యూల్|कार्यक्रम/.test(t)) return 'schedule';
  if (/pest|disease|insect|aphid|కీట|कीट/.test(t)) return 'pest';
  if (/irrig|water|drip|నీటి|सिंचाई/.test(t)) return 'irrigation';
  if (/fertil|urea|npk|nutrient|ఎరువు|उर्वरक/.test(t)) return 'fertiliser';
  if (/harvest|cut|reap|కోత|कटाई/.test(t)) return 'harvest';
  if (/soil|ph|loam|మట్టి|मिट्टी/.test(t)) return 'soil';
  if (/market|price|mandi|sell|మండి|मंडी|ధర/.test(t)) return 'market';
  if (/community|group|remind|సమూహం|समूह/.test(t)) return 'community';
  if (/remind|am|pm|टाइम|సమయం/.test(t)) return 'remind';
  if (/finance|loan|insurance|money|credit|రుణం|లోన్|ऋण|लोन/.test(t)) return 'finance';
  if (/sustainab|carbon|green|eco|footprint|పచ్చదనం|పర్యావరణం|पर्यावरण/.test(t)) return 'sustainability';
  if (/help|what can|what do|ఏం|क्या/.test(t)) return 'help';
  return 'unknown';
}

function getAnswer(text, lang) {
  const key = classify(text, lang);
  const answers = KB[lang]?.[key] || KB['en'][key] || KB['en']['unknown'];
  return answers[Math.floor(Math.random() * answers.length)];
}

/* ================================================================ */
export default function VoiceAssistant({ lang = 'en' }) {
  const [isOpen, setIsOpen]       = useState(false);
  const [listening, setListening] = useState(false);
  const [messages, setMessages]   = useState([]);
  const [input, setInput]         = useState('');
  const [thinking, setThinking]   = useState(false);
  const [pulse, setPulse]         = useState(false);
  const recognitionRef = useRef(null);
  const bottomRef      = useRef(null);

  // Scroll to bottom on new message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  // Greeting on open
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const greeting = KB[lang]?.greeting?.[0] || KB.en.greeting[0];
      setMessages([{ role:'assistant', text: greeting, time: now() }]);
      speak(greeting, lang);
    }
  }, [isOpen]);

  const getVoiceLang = (code) => {
    const map = {
      'hi': 'hi-IN', 'bn': 'bn-IN', 'te': 'te-IN', 
      'mr': 'mr-IN', 'ta': 'ta-IN', 'ml': 'ml-IN', 
      'gu': 'gu-IN', 'kn': 'kn-IN', 'en': 'en-IN'
    };
    return map[code] || 'en-IN';
  };

  const speak = (text, l = lang) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang  = getVoiceLang(l);
    u.rate  = 0.95;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  const sendMessage = useCallback(async (text) => {
    if (!text.trim()) return;
    const userMsg = { role:'user', text: text.trim(), time: now() };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setThinking(true);
    
    try {
      // Connect to Gemini-powered backend
      const res = await fetch('http://localhost:8000/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text.trim(), lang }),
      });
      
      if (!res.ok) throw new Error("Backend unreachable");
      
      const data = await res.json();
      const answer = data.response;
      
      setMessages(m => [...m, { role:'assistant', text: answer, time: now() }]);
      speak(answer, lang);
    } catch (e) {
      console.warn("AI backend offline, falling back to local knowledge base.", e);
      // Local fallback for offline use
      const answer = getAnswer(text, lang);
      setMessages(m => [...m, { role:'assistant', text: answer, time: now() }]);
      speak(answer, lang);
    } finally {
      setThinking(false);
    }
  }, [lang]);

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition not supported. Please type your question.');
      return;
    }
    const rec = new SpeechRecognition();
    rec.lang        = getVoiceLang(lang);
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onstart  = () => { setListening(true); setPulse(true); };
    rec.onresult = e => {
      const t = e.results[0][0].transcript;
      setListening(false); setPulse(false);
      sendMessage(t);
    };
    rec.onerror  = () => { setListening(false); setPulse(false); };
    rec.onend    = () => { setListening(false); setPulse(false); };
    rec.start();
    recognitionRef.current = rec;
  };

  const stopListening = () => {
    recognitionRef.current?.stop();
    setListening(false); setPulse(false);
  };

  const QUICK = {
    en: ["What\'s the weather risk?","Which crop should I sow?","Tell me the crop schedule","Pest control tips","Market prices","Finance & Loans","Sustainability tips"],
    hi: ["मौसम का जोखिम क्या है?","मंडी भाव?","सामुदायिक अलर्ट", "लोन और बीमा"],
    te: ["వాతావరణ ప్రమాదం ఏమిటి?","మండి ధరలు","కమ్యూనిటీ అలర్ట్", "రుణం మరియు భీమా"],
  };
  const quickButtons = QUICK[lang] || QUICK.en;

  return (
    <>
      {/* ---- Floating Trigger ---- */}
      <button
        className={`va-fab ${pulse ? 'va-fab-pulse' : ''}`}
        onClick={() => setIsOpen(o => !o)}
        title="AgroSafe Voice Assistant"
        id="voice-assistant-fab"
      >
        {isOpen ? <X size={24}/> : <Bot size={24}/>}
      </button>

      {/* ---- Chat Panel ---- */}
      {isOpen && (
        <div className="va-panel">
          {/* Header */}
          <div className="va-header">
            <div className="va-header-dot"/>
            <div>
              <div className="va-header-title">AgroSafe AI Assistant</div>
              <div className="va-header-sub">
                {listening ? '🎙️ Listening…' : 'Online · ' + (lang.toUpperCase())}
              </div>
            </div>
            <button className="va-close-btn" onClick={() => setIsOpen(false)}>
              <ChevronDown size={18}/>
            </button>
          </div>

          {/* Messages */}
          <div className="va-messages">
            {messages.map((m, i) => (
              <div key={i} className={`va-message-row ${m.role === 'user' ? 'va-row-user' : 'va-row-bot'}`}>
                {m.role === 'assistant' && (
                  <div className="va-avatar"><Bot size={14}/></div>
                )}
                <div className={`va-bubble ${m.role === 'user' ? 'va-bubble-user' : 'va-bubble-bot'}`}>
                  <p>{m.text}</p>
                  <div className="va-msg-meta">
                    {m.time}
                    {m.role === 'assistant' && (
                      <button className="va-replay" onClick={() => speak(m.text, lang)}>
                        <Volume2 size={10}/>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {thinking && (
              <div className="va-message-row va-row-bot">
                <div className="va-avatar"><Bot size={14}/></div>
                <div className="va-bubble va-bubble-bot va-thinking">
                  <span/><span/><span/>
                </div>
              </div>
            )}
            <div ref={bottomRef}/>
          </div>

          {/* Quick replies */}
          <div className="va-quick-row">
            {quickButtons.map((q, i) => (
              <button key={i} className="va-quick-btn" onClick={() => sendMessage(q)}>{q}</button>
            ))}
          </div>

          {/* Input row */}
          <div className="va-input-row">
            <button
              className={`va-mic-btn ${listening ? 'va-mic-active' : ''}`}
              onClick={listening ? stopListening : startListening}
              title={listening ? 'Stop' : 'Speak'}
            >
              {listening ? <MicOff size={18}/> : <Mic size={18}/>}
            </button>
            <input
              className="va-text-input"
              placeholder="Type your question…"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
            />
            <button className="va-send-btn" onClick={() => sendMessage(input)} disabled={!input.trim()}>
              <Send size={16}/>
            </button>
          </div>
        </div>
      )}

      <style>{`
        /* FAB */
        .va-fab {
          position:fixed; bottom:28px; right:28px; z-index:9999;
          width:58px; height:58px; border-radius:50%;
          background:linear-gradient(135deg,#16a34a,#0d9488);
          color:#fff; border:none; cursor:pointer;
          display:flex; align-items:center; justify-content:center;
          box-shadow:0 8px 32px rgba(22,163,74,.4);
          transition:transform .2s, box-shadow .2s;
        }
        .va-fab:hover { transform:scale(1.08); box-shadow:0 12px 40px rgba(22,163,74,.5); }
        .va-fab-pulse { animation:va-pulse 1.5s ease-in-out infinite; }
        @keyframes va-pulse {
          0%,100% { box-shadow:0 8px 32px rgba(22,163,74,.4); }
          50%      { box-shadow:0 8px 48px rgba(22,163,74,.7); transform:scale(1.05); }
        }

        /* Panel */
        .va-panel {
          position:fixed; bottom:100px; right:28px; z-index:9998;
          width:360px; max-width:calc(100vw - 40px);
          background:#fff; border-radius:24px;
          box-shadow:0 24px 80px rgba(0,0,0,.18);
          display:flex; flex-direction:column;
          overflow:hidden; animation:va-slide-in .25s ease;
          border:1px solid #e2e8f0;
        }
        @keyframes va-slide-in {
          from { opacity:0; transform:translateY(20px) scale(.97); }
          to   { opacity:1; transform:none; }
        }

        /* Header */
        .va-header {
          display:flex; align-items:center; gap:10px;
          padding:14px 16px;
          background:linear-gradient(135deg,#064e3b,#16a34a);
          color:#fff;
        }
        .va-header-dot { width:10px; height:10px; border-radius:50%; background:#4ade80; flex-shrink:0; box-shadow:0 0 6px #4ade80; animation:blink 2s ease-in-out infinite; }
        @keyframes blink { 50% { opacity:.3; } }
        .va-header-title { font-weight:700; font-size:14px; }
        .va-header-sub   { font-size:11px; opacity:.8; margin-top:1px; }
        .va-close-btn { margin-left:auto; background:rgba(255,255,255,.2); border:none; color:#fff; border-radius:50%; width:28px; height:28px; display:flex; align-items:center; justify-content:center; cursor:pointer; }

        /* Messages */
        .va-messages { flex:1; overflow-y:auto; padding:14px; max-height:320px; display:flex; flex-direction:column; gap:10px; }
        .va-messages::-webkit-scrollbar { width:3px; }
        .va-messages::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
        .va-message-row { display:flex; align-items:flex-end; gap:8px; }
        .va-row-user { flex-direction:row-reverse; }
        .va-avatar { width:28px; height:28px; border-radius:50%; background:linear-gradient(135deg,#16a34a,#0d9488); color:#fff; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .va-bubble { max-width:78%; padding:10px 14px; border-radius:16px; font-size:13px; line-height:1.5; }
        .va-bubble p { margin:0 0 4px; }
        .va-bubble-bot  { background:#f1f5f9; color:#1e293b; border-bottom-left-radius:4px; }
        .va-bubble-user { background:linear-gradient(135deg,#16a34a,#0d9488); color:#fff; border-bottom-right-radius:4px; }
        .va-msg-meta { font-size:10px; opacity:.6; display:flex; align-items:center; gap:6px; }
        .va-replay { background:none; border:none; padding:0; cursor:pointer; opacity:.7; color:inherit; }
        .va-thinking { display:flex; gap:5px; align-items:center; padding:14px 18px; }
        .va-thinking span { width:8px; height:8px; border-radius:50%; background:#94a3b8; animation:va-dot .9s ease-in-out infinite; }
        .va-thinking span:nth-child(2) { animation-delay:.2s; }
        .va-thinking span:nth-child(3) { animation-delay:.4s; }
        @keyframes va-dot { 0%,80%,100% { transform:scale(.6); opacity:.4; } 40% { transform:scale(1); opacity:1; } }

        /* Quick */
        .va-quick-row { display:flex; gap:6px; overflow-x:auto; padding:8px 12px; border-top:1px solid #f1f5f9; }
        .va-quick-row::-webkit-scrollbar { display:none; }
        .va-quick-btn { white-space:nowrap; background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a; padding:5px 12px; border-radius:999px; font-size:12px; font-weight:600; cursor:pointer; flex-shrink:0; transition:background .15s; }
        .va-quick-btn:hover { background:#dcfce7; }

        /* Input */
        .va-input-row { display:flex; gap:8px; align-items:center; padding:12px 14px; border-top:1px solid #f1f5f9; }
        .va-mic-btn { width:38px; height:38px; border-radius:50%; background:#f1f5f9; border:none; color:#64748b; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:background .15s, color .15s; flex-shrink:0; }
        .va-mic-btn:hover { background:#fef2f2; color:#ef4444; }
        .va-mic-active { background:#fef2f2 !important; color:#ef4444 !important; animation:va-pulse 1.2s ease-in-out infinite; }
        .va-text-input { flex:1; padding:8px 12px; border:1px solid #e2e8f0; border-radius:12px; font-size:13px; outline:none; }
        .va-text-input:focus { border-color:#16a34a; box-shadow:0 0 0 3px rgba(22,163,74,.12); }
        .va-send-btn { width:36px; height:36px; border-radius:50%; background:#16a34a; color:#fff; border:none; display:flex; align-items:center; justify-content:center; cursor:pointer; flex-shrink:0; transition:background .15s; }
        .va-send-btn:hover { background:#15803d; }
        .va-send-btn:disabled { opacity:.4; cursor:not-allowed; }
      `}</style>
    </>
  );
}

function now() {
  return new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
}
