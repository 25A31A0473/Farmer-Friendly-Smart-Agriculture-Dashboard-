import React, { useState, useEffect, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { Globe, Mic, CloudSun, Leaf, Apple, HeartPulse, Menu, X, ShieldAlert, CalendarDays, Bell, ShoppingBag, Users, ShieldCheck, ArrowRight, Settings as SettingsIcon, Store, Camera, Truck, Activity, IndianRupee, GraduationCap, PhoneCall, Info, CloudLightning, Radio } from 'lucide-react';
import VoiceAssistant from './components/VoiceAssistant';
import { auth } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { useTranslation } from 'react-i18next';

// Lazy load all pages to isolate any module-level errors and improve performance
const WeatherDashboard    = lazy(() => import('./pages/WeatherDashboard'));
const CropDiagnosis       = lazy(() => import('./pages/CropDiagnosis'));
const FoodSafety          = lazy(() => import('./pages/FoodSafety'));
const HealthcareTriage    = lazy(() => import('./pages/HealthcareTriage'));
const About               = lazy(() => import('./pages/About'));
const Login               = lazy(() => import('./pages/Login'));
const ClimateRisk         = lazy(() => import('./pages/ClimateRisk'));
const CropPlanner         = lazy(() => import('./pages/CropPlanner'));
const CommunityAlerts     = lazy(() => import('./pages/CommunityAlerts'));
const Marketplace         = lazy(() => import('./pages/Marketplace'));
const ResourceMarketplace = lazy(() => import('./pages/ResourceMarketplace'));
const Settings            = lazy(() => import('./pages/Settings'));
const SecurityCenter      = lazy(() => import('./pages/SecurityCenter'));
const FinancialHub        = lazy(() => import('./pages/FinancialHub'));
const SustainabilityModule = lazy(() => import('./pages/SustainabilityModule'));
const SmartCropForecasting = lazy(() => import('./pages/SmartCropForecasting'));
const CommunityHub        = lazy(() => import('./pages/CommunityHub'));
const ConsumerEngagement  = lazy(() => import('./pages/ConsumerEngagement'));
const AITutors            = lazy(() => import('./pages/AITutors'));
const SoilHealthAnalysis  = lazy(() => import('./pages/SoilHealthAnalysis'));
const TransportationLogistics = lazy(() => import('./pages/TransportationLogistics'));


const PageLoader = () => (
  <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',fontSize:'18px',color:'#16a34a',fontFamily:'sans-serif',gap:'12px'}}>
    <span style={{animation:'spin 1s linear infinite',display:'inline-block'}}>🌱</span> Loading…
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>
);


// Mapping local language codes to Indian BCP 47 codes
const getVoiceLang = (code) => {
  const map = {
    'hi': 'hi-IN', 'bn': 'bn-IN', 'te': 'te-IN', 
    'mr': 'mr-IN', 'ta': 'ta-IN', 'ur': 'ur-IN', 
    'gu': 'gu-IN', 'kn': 'kn-IN', 'en': 'en-IN'
  };
  return map[code] || 'en-IN';
};

function AppContent() {
  const { t, i18n } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [user, setUser] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try { await signOut(auth); } catch (e) {}
  };

  const handleVoice = () => {
     // Speak the welcome text from i18n
     const text = t('voice.greeting', 'Welcome to AgroSafe.');
     const utterance = new SpeechSynthesisUtterance(text);
     utterance.lang = getVoiceLang(i18n.language);
     window.speechSynthesis.speak(utterance);
  };

  const isHome = location.pathname === '/';

  return (
    <div className="h-screen w-full overflow-y-auto overflow-x-hidden flex flex-col font-sans bg-kpop-darkBg text-white selection:bg-kpop-neonPink relative custom-scrollbar touch-pan-y">
      {/* Global animated background for the whole app */}
      <div className="fixed inset-0 z-[-1] bg-gradient-to-br from-kpop-darkBg via-kpop-purple/20 to-kpop-darkBg animate-gradient-x opacity-60 pointer-events-none"></div>
      {/* Conditionally hide Navbar on Landing Page */}
      {!isHome && (
        <nav className="glassmorphism sticky top-0 z-50 border-b border-kpop-glassBorder">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Link to="/dashboard" className="flex items-center gap-2">
                  <Store className="h-8 w-8 text-kpop-neonPink animate-pulse-slow" />
                  <span className="font-bold text-xl text-white text-glow">Kisan Mart</span>
                </Link>
              </div>

               {/* Quick Action Nav */}
              <div className="hidden md:flex items-center space-x-4">
                 <button onClick={handleVoice} className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all duration-300 flex items-center gap-2 font-bold px-4 shadow-[0_0_15px_rgba(255,42,133,0.3)] hover:shadow-[0_0_25px_rgba(255,42,133,0.6)]" title="Voice Assistant">
                  <Mic className="h-5 w-5 animate-pulse text-kpop-neonPink" /> {t('nav.voice','Voice Guide')}
                </button>
                
                <div className="relative">
                  <button onClick={() => setShowNotifications(!showNotifications)} className="p-2 text-white/70 hover:text-kpop-cyan transition-colors relative">
                    <Bell className="h-6 w-6" />
                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-kpop-neonPink rounded-full shadow-[0_0_10px_#ff007f] animate-pulse"></span>
                  </button>
                  {showNotifications && (
                    <div className="absolute right-0 mt-2 w-80 glassmorphism rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.8)] border border-white/10 overflow-hidden z-50 animate-in fade-in zoom-in duration-200">
                      <div className="bg-black/40 px-4 py-3 border-b border-white/10 flex justify-between items-center">
                        <h3 className="font-bold text-white">Alerts</h3>
                        <span className="text-xs bg-kpop-neonPink text-white px-2 py-1 rounded-md font-bold">3 New</span>
                      </div>
                      <div className="max-h-80 overflow-y-auto custom-scrollbar">
                        <div className="p-4 border-b border-white/5 hover:bg-white/5 cursor-pointer">
                          <p className="text-sm font-bold text-white mb-1 flex items-center gap-2"><Leaf className="w-4 h-4 text-kpop-cyan"/> Subsidies</p>
                          <p className="text-xs text-white/60">Your application for solar pump subsidy is approved.</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                                
                {user ? (
                  <button onClick={handleLogout} className="text-sm font-bold text-red-400 hover:text-red-300 px-3 py-2 rounded-lg hover:bg-red-900/30 transition-colors">
                    {t('nav.logout','Logout')}
                  </button>
                ) : (
                  <Link to="/login" className="text-sm font-medium text-white bg-gradient-to-r from-kpop-pink to-kpop-purple hover:from-kpop-neonPink hover:to-kpop-purple px-5 py-2 rounded-full shadow-[0_0_20px_rgba(139,92,246,0.5)] transition-all">
                    {t('nav.login','Login')}
                  </Link>
                )}
              </div>
            </div>
          </div>
        </nav>
      )}

      {/* Main Content */}
      <main className="flex-grow">
        <Suspense fallback={<PageLoader />}>
          <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/dashboard" element={<MainDashboard />} />
          <Route path="/weather" element={<WeatherDashboard />} />
          <Route path="/climate-risk" element={<ClimateRisk />} />
          <Route path="/crop-planner" element={<CropPlanner />} />
          <Route path="/community-alerts" element={<CommunityAlerts />} />
          <Route path="/crop" element={<CropDiagnosis />} />
          <Route path="/food" element={<FoodSafety />} />
          <Route path="/health" element={<HealthcareTriage />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/resources" element={<ResourceMarketplace />} />
          <Route path="/security" element={<SecurityCenter />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/finance" element={<FinancialHub />} />
          <Route path="/sustainability" element={<SustainabilityModule />} />
          <Route path="/forecasting" element={<SmartCropForecasting />} />
          <Route path="/community-hub" element={<CommunityHub />} />
          <Route path="/consumer-engagement" element={<ConsumerEngagement />} />
          <Route path="/ai-tutors" element={<AITutors />} />
          <Route path="/soil-health" element={<SoilHealthAnalysis />} />
          <Route path="/transportation" element={<TransportationLogistics />} />

        </Routes>
        </Suspense>
      </main>
      <VoiceAssistant lang={i18n.language} />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

// ----------------------------------------------------------------------
// 1. Landing Page (Minimal: Languages Left, Button Center)
// ----------------------------------------------------------------------
function LandingPage() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  const handleLanguageChange = (lang) => {
    i18n.changeLanguage(lang);
    document.documentElement.dir = lang === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
    
    // Voice feedback on hover/click seamlessly
    const u = new SpeechSynthesisUtterance("Language set.");
    u.lang = getVoiceLang(lang);
    window.speechSynthesis.speak(u);
  };

  const LANGUAGES = [
     { code: 'hi', label: 'Hindi (हिंदी)' },
     { code: 'bn', label: 'Bengali (বাংলা)' },
     { code: 'te', label: 'Telugu (తెలుగు)' },
     { code: 'mr', label: 'Marathi (मराठी)' },
     { code: 'ta', label: 'Tamil (தமிழ்)' },
     { code: 'ml', label: 'Malayalam (മലയാളം)' },
     { code: 'gu', label: 'Gujarati (ગુજરાતી)' },
     { code: 'kn', label: 'Kannada (ಕನ್ನಡ)' },
     { code: 'en', label: 'English' }
  ];

  return (
    <div className="h-screen w-full flex bg-nature-950 overflow-hidden relative font-sans">
      <div 
         className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-60"
         style={{ backgroundImage: 'url("/composite-bg.png")' }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-nature-950 via-green-900/40 to-nature-950 opacity-80 pointer-events-none" />
      
      {/* Left Sidebar: Languages */}
      <div className="relative z-10 w-80 glassmorphism h-full flex flex-col pt-12 pb-6 shadow-[10px_0_50px_rgba(20,83,45,0.5)] border-r-white/10 bg-nature-900/40 backdrop-blur-md">
        <h2 className="text-green-400 uppercase tracking-[0.4em] text-[11px] font-black ml-8 mb-8">{t('lang.select','Select Language')}</h2>
        <div className="flex-1 overflow-y-auto px-4 custom-scrollbar">
          {LANGUAGES.map(l => (
            <button
              key={l.code}
              onClick={() => handleLanguageChange(l.code)}
              className={`w-full text-left px-6 py-4 rounded-2xl mb-3 font-bold transition-all duration-300 ${
                i18n.language === l.code 
                 ? 'bg-gradient-to-r from-green-500 to-emerald-700 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)] scale-[1.02]' 
                 : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white border border-white/5'
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{l.label}</span>
                {i18n.language === l.code && <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_10px_white]"/>}
              </div>
            </button>
          ))}
        </div>
        <div className="mt-auto px-8 flex items-center gap-3 text-white/70 pt-4 border-t border-white/10">
           <Globe className="w-5 h-5 text-emerald-400"/>
           <span className="text-xs font-medium tracking-wide">8 Indian Languages Active</span>
        </div>
      </div>

      {/* Center: Kisan Mart Button */}
      <div className="relative z-10 flex-1 flex items-center justify-center">
         <button 
           onClick={() => navigate('/dashboard')}
           className="group relative flex flex-col items-center justify-center p-16 outline-none animate-float"
         >
           <div className="absolute inset-0 bg-green-500 rounded-[4rem] blur-[80px] opacity-20 group-hover:opacity-40 transition-opacity duration-700" />
           <div className="relative glassmorphism bg-nature-900/40 rounded-[3rem] px-20 py-16 shadow-[0_20px_60px_-15px_rgba(20,83,45,0.8)] transform transition-transform duration-500 group-hover:scale-105 group-active:scale-95 flex flex-col items-center gap-8 border border-green-500/20 backdrop-blur-2xl">
              <Store className="w-28 h-28 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]" />
              <h1 className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-green-300 to-white tracking-tighter">{t('action.enter', 'AgroSafe')}</h1>
              <div className="flex items-center gap-3 text-nature-950 font-black uppercase tracking-[0.3em] text-sm bg-green-400 px-8 py-3 rounded-full shadow-[0_0_20px_rgba(74,222,128,0.4)] group-hover:bg-white transition-colors">
                {t('enter.platform','Enter Platform')} <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
              </div>
           </div>
         </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 2. Alphabetical Dashboard
// ----------------------------------------------------------------------
function MainDashboard() {
  const { t, i18n } = useTranslation();
  
  // 23 Comprehensive Modules - All features visible
  const features = [
    { key: "weather",             title: t('features.weather',             'Weather Dashboard'),            icon: <CloudSun />,      link: "/weather",              hoverColor: "group-hover:text-sky-400" },
    { key: "climateRisk",         title: t('features.climateRisk',         'Climate Risk Predictor'),        icon: <CloudLightning />, link: "/climate-risk",          hoverColor: "group-hover:text-amber-400" },
    { key: "cropDiagnosis",       title: t('features.cropDiagnosis',       'Crop Diagnosis (AI)'),           icon: <Activity />,      link: "/crop",                 hoverColor: "group-hover:text-emerald-400" },
    { key: "cropPlanner",         title: t('features.cropPlanner',         'Crop Planner'),                  icon: <CalendarDays />,  link: "/crop-planner",         hoverColor: "group-hover:text-lime-400" },
    { key: "soilHealth",          title: t('features.soilHealth',          'Soil Health Analysis'),          icon: <Activity />,      link: "/soil-health",          hoverColor: "group-hover:text-amber-500" },
    { key: "forecasting",         title: t('features.forecasting',         'Smart Crop Forecasting'),        icon: <Activity />,      link: "/forecasting",          hoverColor: "group-hover:text-blue-400" },
    { key: "sustainability",      title: t('features.sustainability',      'Climate & Sustainability'),       icon: <Leaf />,          link: "/sustainability",        hoverColor: "group-hover:text-green-500" },
    { key: "farmerUpload",        title: t('features.farmerUpload',        'Farmer Upload (Kisan Mart)'),    icon: <Camera />,        link: "/marketplace",          state: { tab: 'farmer' }, hoverColor: "group-hover:text-teal-400" },
    { key: "consumerMarket",      title: t('features.consumerMarket',      'Consumer Marketplace'),          icon: <Store />,         link: "/marketplace",          state: { tab: 'consumer' }, hoverColor: "group-hover:text-teal-500" },
    { key: "healthTriage",        title: t('features.healthTriage',        'AI Health Assistant'),           icon: <HeartPulse />,    link: "/health",               hoverColor: "group-hover:text-rose-400" },
    { key: "foodSafety",          title: t('features.foodSafety',          'Food Safety & Nutrition'),       icon: <Apple />,         link: "/food",                 hoverColor: "group-hover:text-red-500" },
    { key: "security",            title: t('features.security',            'Emergency & Citizen Safety'),    icon: <ShieldCheck />,   link: "/security",             hoverColor: "group-hover:text-orange-500" },
    { key: "transportation",      title: t('features.transportation',      'Transportation & Logistics'),    icon: <Truck />,         link: "/transportation",       hoverColor: "group-hover:text-amber-400" },
    { key: "finance",             title: t('features.finance',             'Finance, Insurance & Loans'),    icon: <IndianRupee />,   link: "/finance",              hoverColor: "group-hover:text-emerald-500" },
    { key: "communityHub",        title: t('features.communityHub',        'Community Hub & Learning'),      icon: <Users />,         link: "/community-hub",        hoverColor: "group-hover:text-cyan-400" },
    { key: "communityAlerts",     title: t('features.communityAlerts',     'Community Alerts & AI Calling'), icon: <Bell />,          link: "/community-alerts",     hoverColor: "group-hover:text-yellow-400" },
    { key: "resourceMarketplace", title: t('features.resourceMarketplace', 'Resource Person Module'),        icon: <Users />,         link: "/resources",            hoverColor: "group-hover:text-cyan-500" },
    { key: "aiTutors",            title: t('features.aiTutors',            'AI Tutorials'),                  icon: <GraduationCap />, link: "/ai-tutors",            hoverColor: "group-hover:text-indigo-500" },
    { key: "consumerEngagement",  title: t('features.consumerEngagement',  'Smart Notifications & Alerts'),  icon: <ShieldAlert />,   link: "/consumer-engagement",  hoverColor: "group-hover:text-pink-400" },
    { key: "settings",            title: t('features.settings',            'UI/UX Settings'),                icon: <SettingsIcon />,  link: "/settings",             hoverColor: "group-hover:text-gray-400" },
    { key: "about",               title: t('features.about',               'About AgroSafe'),                icon: <Info />,          link: "/about",                hoverColor: "group-hover:text-purple-400" },
    { key: "login",               title: t('features.login',               'Account & Login'),               icon: <PhoneCall />,     link: "/login",                hoverColor: "group-hover:text-slate-400" },
  ];

  // Sort strictly alphabetically by the currently rendered Language translation
  const translatedFeatures = [...features].sort((a, b) => a.title.localeCompare(b.title, i18n.language));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
      <div className="mb-12 flex justify-between items-end border-b border-white/10 pb-6">
        <div>
           <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-green-500/20 text-green-400 border border-green-500/30 rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-4">
              Dashboard Active • {i18n.language.toUpperCase()}
           </div>
           <h1 className="text-5xl font-black text-white tracking-tight">{t('dashboard.title','AgroSafe Modules')}</h1>
           <p className="text-white/50 text-sm mt-1">{t('dashboard.subtitle','22 Features • All Operational')}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {translatedFeatures.map(feature => (
          <Link key={feature.key} to={feature.link} state={feature.state || {}} className={`bg-nature-900/60 backdrop-blur-md rounded-3xl p-8 flex flex-col items-center text-center gap-5 group border border-nature-700/50 hover:border-green-500/50 transition-all duration-300 shadow-lg hover:shadow-2xl hover:-translate-y-1`}>
            <div className="bg-nature-800/80 group-hover:bg-nature-800 p-5 rounded-[2rem] transition-all duration-300 border border-nature-700/50">
               {React.cloneElement(feature.icon, { className: `h-10 w-10 text-emerald-100 transition-all duration-300 group-hover:scale-110 ${feature.hoverColor}` })}
            </div>
            <h2 className={`text-xl font-bold text-white mt-2 transition-colors duration-300 ${feature.hoverColor}`}>{feature.title}</h2>
          </Link>
        ))}
      </div>

      <div className="mt-16 text-center pt-8 border-t border-white/10">
        <p className="text-xs font-black text-white/30 uppercase tracking-[0.4em] mb-4">Proudly Aligned With</p>
        <div className="flex flex-wrap justify-center items-center gap-4">
           {['🇺🇳 Zero Hunger', '🇺🇳 Good Health', '🇺🇳 Decent Work', '🇺🇳 Industry Innovation'].map(sdg => (
             <span key={sdg} className="px-5 py-2 bg-white/5 border border-white/10 text-white/70 rounded-xl text-xs font-bold backdrop-blur-sm hover:bg-white/10 transition-colors cursor-default">{sdg}</span>
           ))}
        </div>
      </div>
    </div>
  );
}
