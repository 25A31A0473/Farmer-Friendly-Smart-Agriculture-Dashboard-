import React, { useState } from 'react';
import { BookOpen, Video, Zap, GraduationCap, Cpu, Globe, Rocket, MessageSquare, Play, ChevronRight, Star, Clock } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';

const TUTORIALS = [
  {
    id: 1,
    title: "Precision Farming 101",
    desc: "Learn how to use GPS and sensors to optimize crop yields and reduce waste.",
    icon: <Globe className="w-6 h-6" />,
    duration: "45 mins",
    level: "Intermediate",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: 2,
    title: "Smart Irrigation Systems",
    desc: "Master the art of automated water management using IoT devices.",
    icon: <Zap className="w-6 h-6" />,
    duration: "30 mins",
    level: "Beginner",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: 3,
    title: "Drone Monitoring",
    desc: "How to use multi-spectral drone imagery to spot pests and diseases early.",
    icon: <Rocket className="w-6 h-6" />,
    duration: "1 hour",
    level: "Advanced",
    rating: 5.0,
    image: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=400&q=80"
  }
];

const NEW_TECH = [
  {
    title: "AI Crop Doctor",
    desc: "Real-time diagnosis using computer vision.",
    icon: <Cpu className="text-purple-400" />,
    status: "Live"
  },
  {
    title: "Soil IoT Mesh",
    desc: "Wireless sensor networks for ground data.",
    icon: <Zap className="text-yellow-400" />,
    status: "Beta"
  },
  {
    title: "Autonomous Harvesters",
    desc: "Self-driving machinery for large scale farms.",
    icon: <Rocket className="text-blue-400" />,
    status: "Coming Soon"
  }
];


export default function AITutors() {
  const { t } = useTranslation();
  const [activeCourse, setActiveCourse] = useState(null);

  return (
    <div className="min-h-screen bg-[#050a10] text-white pb-20 font-sans selection:bg-indigo-500/30">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_50%_0%,rgba(79,70,229,0.15),transparent_50%)]"></div>
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-bold mb-8">
              <GraduationCap className="w-4 h-4" />
              {t('aitutor.badge', 'AI-Powered Education')}
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-6 bg-gradient-to-b from-white to-gray-400 bg-clip-text text-transparent">
              {t('aitutor.title', 'AI Tutors & Future Tech')}
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
              {t('aitutor.subtitle', 'Master the next generation of agriculture with interactive AI tutoring and deep-dives into emerging farming technologies.')}
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 space-y-24">
        
        {/* Featured Tech Grid */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {NEW_TECH.map((tech, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                className="group relative p-8 rounded-3xl bg-gray-900/50 border border-white/5 hover:border-indigo-500/30 transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4">
                  <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded ${tech.status === 'Live' ? 'bg-green-500/20 text-green-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                    {tech.status}
                  </span>
                </div>
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {React.cloneElement(tech.icon, { size: 28 })}
                </div>
                <h3 className="text-xl font-bold mb-2">{t(tech.title, tech.title)}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{t(tech.desc, tech.desc)}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Course Modules */}
        <section>
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-black mb-2">{t('aitutor.courses', 'Interactive Learning Modules')}</h2>
              <p className="text-gray-500">{t('aitutor.courses_sub', 'AI-curated paths for sustainable and high-yield farming.')}</p>
            </div>
            <button className="flex items-center gap-2 text-indigo-400 font-bold hover:text-indigo-300 transition-colors">
              {t('View All', 'View All')} <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {TUTORIALS.map((course) => (
              <div 
                key={course.id}
                className="group bg-gray-900/40 rounded-[2.5rem] overflow-hidden border border-white/5 hover:border-indigo-500/20 transition-all flex flex-col"
              >
                <div className="h-56 relative overflow-hidden">
                  <img src={course.image} alt={course.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-950/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-6 flex items-center gap-4">
                    <div className="flex items-center gap-1 text-xs font-bold text-white">
                      <Clock className="w-3 h-3 text-indigo-400" /> {course.duration}
                    </div>
                    <div className="flex items-center gap-1 text-xs font-bold text-white">
                      <Star className="w-3 h-3 text-yellow-400 fill-current" /> {course.rating}
                    </div>
                  </div>
                  <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center pl-1 shadow-2xl">
                      <Play className="w-6 h-6 fill-current" />
                    </div>
                  </button>
                </div>
                <div className="p-8 flex flex-col flex-1">
                  <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-3">{course.level}</div>
                  <h3 className="text-2xl font-bold mb-4">{t(course.title, course.title)}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-8 flex-1">{t(course.desc, course.desc)}</p>
                  <button className="w-full py-4 bg-white/5 hover:bg-white text-white hover:text-black rounded-2xl font-black transition-all border border-white/10 hover:border-white">
                    {t('aitutor.start', 'Start Tutoring')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* AI Tutor Chat Teaser */}
        <section className="relative p-12 rounded-[3rem] bg-gradient-to-br from-indigo-900/40 to-purple-900/40 border border-white/10 overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full opacity-10">
            <MessageSquare className="w-full h-full text-white" />
          </div>
          <div className="relative z-10 max-w-2xl">
            <h2 className="text-4xl font-black mb-6">{t('aitutor.chat_title', 'Ask Your Personalized AI Tutor')}</h2>
            <p className="text-indigo-100/70 text-lg mb-8 leading-relaxed">
              {t('aitutor.chat_desc', 'Got a specific problem? Our AI Tutors are trained on global agricultural data and local soil conditions to give you precise, actionable advice 24/7.')}
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-10 py-4 bg-white text-black rounded-2xl font-black shadow-xl shadow-white/10 hover:scale-105 transition-transform flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                {t('aitutor.open_chat', 'Start Consultation')}
              </button>
              <button className="px-10 py-4 bg-indigo-500/20 text-white rounded-2xl font-black border border-indigo-500/30 hover:bg-indigo-500/30 transition-colors">
                {t('aitutor.voice', 'Voice Mode')}
              </button>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
