import React, { useState, useEffect, useCallback } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';
import {
  CloudLightning, Droplets, Flame, Wind, AlertTriangle, CheckCircle,
  TrendingUp, ShieldAlert, Satellite, RefreshCw, Volume2, MapPin
} from 'lucide-react';

/* =========================================================
   AI RISK ENGINE — rule-based model simulating ML inference
   ========================================================= */
function computeRisks(weather) {
  if (!weather) return null;
  const cur   = weather.current;
  const daily = weather.daily;

  const avgRain3d  = daily?.precipitation_sum?.slice(0,3).reduce((a,b)=>a+b,0) / 3 || 0;
  const totalRain7 = daily?.precipitation_sum?.reduce((a,b)=>a+b,0) || 0;
  const maxTemp    = Math.max(...(daily?.temperature_2m_max || [cur.temperature_2m]));
  const minTemp    = Math.min(...(daily?.temperature_2m_min || [cur.temperature_2m]));
  const humidity   = cur.relative_humidity_2m;
  const wind       = cur.wind_speed_10m;

  // Flood risk (0-100)
  let flood = 0;
  if (totalRain7 > 80) flood += 60;
  else if (totalRain7 > 40) flood += 35;
  else if (totalRain7 > 15) flood += 15;
  if (avgRain3d > 20) flood += 30;
  if (humidity > 90) flood += 10;
  flood = Math.min(flood, 100);

  // Drought risk (0-100)
  let drought = 0;
  if (totalRain7 < 2) drought += 50;
  else if (totalRain7 < 8) drought += 25;
  if (maxTemp > 38) drought += 35;
  else if (maxTemp > 33) drought += 20;
  if (humidity < 25) drought += 15;
  drought = Math.min(drought, 100);

  // Heat stress risk (0-100)
  let heat = 0;
  if (maxTemp > 40) heat = 90;
  else if (maxTemp > 37) heat = 70;
  else if (maxTemp > 34) heat = 45;
  else if (maxTemp > 30) heat = 20;
  if (humidity > 70 && maxTemp > 30) heat += 10;
  heat = Math.min(heat, 100);

  // Storm risk (0-100)
  let storm = 0;
  const stormDays = daily?.weather_code?.filter(c => c >= 95).length || 0;
  storm += stormDays * 20;
  if (wind > 50) storm += 30;
  else if (wind > 30) storm += 15;
  storm = Math.min(storm, 100);

  // Frost risk (0-100)
  let frost = 0;
  if (minTemp < 4) frost = 85;
  else if (minTemp < 8) frost = 50;
  else if (minTemp < 12) frost = 20;
  frost = Math.min(frost, 100);

  // Overall composite
  const overall = Math.round((flood * 0.3 + drought * 0.25 + heat * 0.2 + storm * 0.15 + frost * 0.1));

  return { flood, drought, heat, storm, frost, overall };
}

function riskLevel(score) {
  if (score >= 70) return { label: 'High',     color: '#ef4444', bg: '#fef2f2', border: '#fecaca' };
  if (score >= 40) return { label: 'Moderate', color: '#f59e0b', bg: '#fffbeb', border: '#fde68a' };
  return                  { label: 'Low',      color: '#22c55e', bg: '#f0fdf4', border: '#bbf7d0' };
}

/* Build 7-day temperature trend from Open-Meteo daily data */
function buildTrend(daily) {
  if (!daily?.time) return [];
  return daily.time.map((d, i) => ({
    day:  new Date(d).toLocaleDateString('en-IN', { weekday: 'short' }),
    high: Math.round(daily.temperature_2m_max[i]),
    low:  Math.round(daily.temperature_2m_min[i]),
    rain: +(daily.precipitation_sum[i] || 0).toFixed(1),
  }));
}

/* Multilingual alert messages */
const ALERTS = {
  en: {
    flood:   score => score >= 70 ? 'HIGH FLOOD RISK: Avoid low-lying fields. Secure equipment and check drainage channels immediately.'
                    : score >= 40 ? 'MODERATE FLOOD RISK: Monitor rainfall closely. Prepare drainage systems.'
                    : 'Flood risk is low. Conditions are stable.',
    drought: score => score >= 70 ? 'SEVERE DROUGHT ALERT: Activate emergency irrigation. Prioritise water-intensive crops.'
                    : score >= 40 ? 'DROUGHT WARNING: Reduce water stress by irrigating in cooler hours.'
                    : 'Drought risk is low. Soil moisture is adequate.',
    heat:    score => score >= 70 ? 'EXTREME HEAT ALERT: Avoid field work 11am–4pm. Ensure crop shading and frequent irrigation.'
                    : score >= 40 ? 'HEAT STRESS WARNING: Water crops early morning and evening.'
                    : 'Heat stress risk is low.',
    storm:   score => score >= 70 ? 'STORM WARNING: Secure greenhouse structures. Do not enter open fields.'
                    : score >= 40 ? 'STORM WATCH: Monitor sky conditions. Move equipment to shelter.'
                    : 'Storm risk is low.',
    frost:   score => score >= 70 ? 'FROST ALERT: Cover sensitive seedlings tonight. Use mulch around root zones.'
                    : score >= 40 ? 'FROST RISK: Protect young plants with row covers.'
                    : 'Frost risk is negligible.',
  },
  hi: {
    flood:   score => score >= 70 ? 'उच्च बाढ़ जोखिम: निचले खेतों से दूर रहें। जल निकासी की जाँच करें।'
                    : score >= 40 ? 'मध्यम बाढ़ जोखिम: वर्षा पर नज़र रखें।'
                    : 'बाढ़ का जोखिम कम है।',
    drought: score => score >= 70 ? 'गंभीर सूखा चेतावनी: आपातकालीन सिंचाई शुरू करें।'
                    : score >= 40 ? 'सूखे की चेतावनी: ठंडे समय में सिंचाई करें।'
                    : 'सूखे का जोखिम कम है।',
    heat:    score => score >= 70 ? 'अत्यधिक गर्मी चेतावनी: 11 बजे से 4 बजे तक खेत में न जाएं।'
                    : score >= 40 ? 'गर्मी तनाव: सुबह और शाम सिंचाई करें।'
                    : 'गर्मी का तनाव कम है।',
    storm:   score => score >= 70 ? 'तूफान चेतावनी: उपकरण सुरक्षित करें।'
                    : score >= 40 ? 'तूफान संभव: आसमान पर नज़र रखें।'
                    : 'तूफान का जोखिम कम है।',
    frost:   score => score >= 40 ? 'पाला चेतावनी: पौधों को ढकें।' : 'पाले का जोखिम नहीं है।',
  },
  te: {
    flood:   score => score >= 70 ? 'అధిక వరద ప్రమాదం: నిచ్చెన పొలాలకు దూరంగా ఉండండి।'
                    : score >= 40 ? 'మధ్యస్థ వరద ప్రమాదం: వర్షపాతాన్ని పర్యవేక్షించండి।'
                    : 'వరద ప్రమాదం తక్కువగా ఉంది.',
    drought: score => score >= 70 ? 'తీవ్రమైన వరుస హెచ్చరిక: అత్యవసర నీటిపారుదల ప్రారంభించండి।'
                    : score >= 40 ? 'వరుస హెచ్చరిక: చల్లని సమయంలో నీరు పెట్టండి।'
                    : 'వరుస ప్రమాదం తక్కువగా ఉంది.',
    heat:    score => score >= 70 ? 'అతిగా వేడి హెచ్చరిక: ఉదయం 11 నుండి 4 గంటల వరకు పొలంలో పని చేయకండి।'
                    : score >= 40 ? 'వేడి ఒత్తిడి: ఉదయాన్నే నీరు పెట్టండి।'
                    : 'వేడి ఒత్తిడి తక్కువగా ఉంది.',
    storm:   score => score >= 70 ? 'తుఫాను హెచ్చరిక: పరికరాలను సురక్షితంగా ఉంచండి।'
                    : score >= 40 ? 'తుఫాను అవకాశం: ఆకాశాన్ని పర్యవేక్షించండి।'
                    : 'తుఫాను ప్రమాదం తక్కువగా ఉంది.',
    frost:   score => score >= 40 ? 'మంచు హెచ్చరిక: మొక్కలను కప్పండి।' : 'మంచు ప్రమాదం లేదు.',
  },
};

const RISK_META = [
  { key: 'flood',   label: 'Flood',       Icon: Droplets,       subject: 'Flood Risk' },
  { key: 'drought', label: 'Drought',     Icon: Flame,          subject: 'Drought Risk' },
  { key: 'heat',    label: 'Heat Stress', Icon: TrendingUp,     subject: 'Heat Stress' },
  { key: 'storm',   label: 'Storm',       Icon: CloudLightning, subject: 'Storm Risk' },
  { key: 'frost',   label: 'Frost',       Icon: Wind,           subject: 'Frost Risk' },
];

/* ===================================================== */
export default function ClimateRisk() {
  const [weather, setWeather]     = useState(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState(null);
  const [locName, setLocName]     = useState('Your Location');
  const [coords, setCoords]       = useState(null);
  const [lang, setLang]           = useState('en');
  const [alertSent, setAlertSent] = useState(false);
  const [aiRisks, setAiRisks]     = useState(null);
  const [phone, setPhone]         = useState('');
  const [alertType, setAlertType] = useState('sms'); // "sms" | "voice"
  const [sendingAlert, setSendingAlert] = useState(false);

  const fetchAiRisk = async (lat, lon) => {
    try {
      const res = await fetch(`https://twelve-hands-greet.loca.lt/api/climate_risk?lat=${lat}&lon=${lon}`);
      if (res.ok) {
        const data = await res.json();
        setAiRisks(data);
      }
    } catch (e) {
      console.warn("Backend AI risk engine offline, falling back to local computation.", e);
    }
  };

  const fetchWeather = useCallback(async (lat, lon) => {
    setLoading(true); setError(null);
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,` +
        `weather_code,wind_speed_10m,surface_pressure,is_day` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,uv_index_max` +
        `&timezone=auto&forecast_days=7`;
      const res  = await fetch(url);
      if (!res.ok) throw new Error('Weather API failed');
      const data = await res.json();
      setWeather(data);
      try {
        const gr = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`);
        const gd = await gr.json();
        const city = gd.address?.city || gd.address?.town || gd.address?.village || 'Your Location';
        setLocName(city + (gd.address?.state ? `, ${gd.address.state}` : ''));
      } catch (_) {}
    } catch (e) { setError(e.message); }
    finally     { setLoading(false); }
  }, []);

  useEffect(() => {
    if (coords) {
      fetchAiRisk(coords.lat, coords.lon);
    }
  }, [coords]);

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      p => { setCoords({ lat: p.coords.latitude, lon: p.coords.longitude }); fetchWeather(p.coords.latitude, p.coords.longitude); },
      _  => { const lat=17.385, lon=78.4867; setCoords({lat,lon}); setLocName('Hyderabad, Telangana'); fetchWeather(lat,lon); },
      { timeout: 8000 }
    );
  }, [fetchWeather]);

  const speak = (text) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'hi' ? 'hi-IN' : lang === 'te' ? 'te-IN' : 'en-IN';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  const handleSendAlert = async () => {
    if (!phone) { alert('Please enter a phone number'); return; }
    setSendingAlert(true);
    try {
      // Send to backend Twilio endpoint
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/send_alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, message: buildAlertMessage(), lang, alert_type: alertType }),
      });
      if (res.ok) setAlertSent(true);
    } catch (_) {
      // Demo mode: just simulate success
      setAlertSent(true);
    }
    setSendingAlert(false);
    setTimeout(() => setAlertSent(false), 5000);
  };

  const localRisks = computeRisks(weather);
  const risks      = aiRisks?.risks ? {
    flood: aiRisks.risks.flood.score,
    drought: aiRisks.risks.drought.score,
    heat: aiRisks.risks.heat.score,
    storm: aiRisks.risks.storm.score,
    frost: localRisks?.frost || 0,
    overall: aiRisks.overall_score
  } : localRisks;

  const trend   = buildTrend(weather?.daily);
  const radarData = risks ? RISK_META.map(m => ({ subject: m.subject, score: risks[m.key] })) : [];

  const buildAlertMessage = () => {
    if (aiRisks?.recommendations?.[lang]) return aiRisks.recommendations[lang];
    if (!risks) return '';
    const msgs = RISK_META.filter(m => risks[m.key] >= 40)
      .map(m => ALERTS[lang][m.key](risks[m.key])).join(' | ');
    return msgs || (lang === 'hi' ? 'आज कोई उच्च मौसम जोखिम नहीं है।'
                  : lang === 'te' ? 'ఈరోజు వాతావరణ ప్రమాదం తక్కువగా ఉంది.'
                  : 'No high climate risks today. Conditions are safe for farming.');
  };

  /* ---- LOADING ---- */
  if (loading) return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
      minHeight:'60vh', gap:16, color:'#64748b' }}>
      <div className="cr-spinner" />
      <p style={{ fontWeight:600 }}>Running AI climate risk analysis…</p>
    </div>
  );

  /* ---- ERROR ---- */
  if (error || !weather) return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
      minHeight:'50vh', gap:12, textAlign:'center', padding:24 }}>
      <AlertTriangle size={40} color="#f59e0b" />
      <p style={{ color:'#b45309', fontWeight:600 }}>{error}</p>
      <button className="cr-btn-green" onClick={() => coords && fetchWeather(coords.lat, coords.lon)}>
        <RefreshCw size={14} /> Retry
      </button>
    </div>
  );

  const overall = risks.overall;
  const ov = riskLevel(overall);

  return (
    <div className="cr-root">
      {/* ===== Hero Banner ===== */}
      <div className="cr-hero" style={{ background: overall >= 70
        ? 'linear-gradient(135deg,#7f1d1d,#dc2626,#ef4444)'
        : overall >= 40 ? 'linear-gradient(135deg,#78350f,#d97706,#fbbf24)'
        : 'linear-gradient(135deg,#14532d,#16a34a,#4ade80)' }}>
        <div className="cr-hero-inner">
          <div className="cr-hero-left">
            <div className="cr-satellite-badge"><Satellite size={14}/> AI Risk Engine Active</div>
            <h1 className="cr-hero-title">Climate Risk Predictor</h1>
            <div className="cr-location-row"><MapPin size={14}/>{locName}</div>
            <div className="cr-overall-score">
              <span className="cr-score-num">{overall}</span>
              <div>
                <div className="cr-score-label">Overall Risk Score</div>
                <div className="cr-score-level">{ov.label} Risk</div>
              </div>
            </div>
          </div>
          <div className="cr-hero-right">
            <div className="cr-lang-row">
              <span style={{ fontSize:13, opacity:.8 }}>Alert Language:</span>
              {['en','hi','te'].map(l => (
                <button key={l} className={`cr-lang-btn ${lang===l?'cr-lang-active':''}`}
                  onClick={() => setLang(l)}>
                  {l==='en'?'EN':l==='hi'?'हि':'తె'}
                </button>
              ))}
            </div>
            <div className="cr-alert-box">
              <p className="cr-alert-msg">"{buildAlertMessage()}"</p>
              <button className="cr-tts-btn" onClick={() => speak(buildAlertMessage())}>
                <Volume2 size={14}/> Listen
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ===== Content ===== */}
      <div className="cr-body">

        {/* ---- Risk Cards Grid ---- */}
        <section className="cr-section">
          <h2 className="cr-section-title"><ShieldAlert size={20}/> Individual Risk Indicators</h2>
          <div className="cr-risk-grid">
            {RISK_META.map(({ key, label, Icon }) => {
              const score = risks[key];
              const rl    = riskLevel(score);
              const alertMsg = ALERTS[lang][key](score);
              return (
                <div key={key} className="cr-risk-card"
                  style={{ borderColor: rl.border, background: rl.bg }}>
                  <div className="cr-risk-card-top">
                    <div className="cr-risk-icon" style={{ background: rl.color + '20' }}>
                      <Icon size={22} color={rl.color}/>
                    </div>
                    <div>
                      <div className="cr-risk-name">{label}</div>
                      <div className="cr-risk-badge" style={{ background: rl.color, color:'#fff' }}>
                        {rl.label}
                      </div>
                    </div>
                    <div className="cr-risk-score" style={{ color: rl.color }}>{score}</div>
                  </div>
                  <div className="cr-progress-bar-bg">
                    <div className="cr-progress-bar-fill"
                      style={{ width:`${score}%`, background: rl.color }} />
                  </div>
                  <p className="cr-risk-alert-text">{alertMsg}</p>
                  <button className="cr-mini-tts" onClick={() => speak(alertMsg)}>
                    <Volume2 size={11}/> Listen
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* ---- Charts Row ---- */}
        <div className="cr-charts-grid">
          {/* 7-day Temp Trend */}
          <section className="cr-chart-card">
            <h3 className="cr-chart-title">7-Day Temperature Trend (°C)</h3>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={trend} margin={{ top:10, right:10, left:-20, bottom:0 }}>
                <defs>
                  <linearGradient id="hi" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="lo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                <XAxis dataKey="day" tick={{ fontSize:12, fill:'#64748b' }}/>
                <YAxis tick={{ fontSize:12, fill:'#64748b' }}/>
                <Tooltip contentStyle={{ borderRadius:12, border:'1px solid #e2e8f0', fontSize:13 }}/>
                <Area type="monotone" dataKey="high" stroke="#ef4444" fill="url(#hi)" strokeWidth={2} name="High °C"/>
                <Area type="monotone" dataKey="low"  stroke="#3b82f6" fill="url(#lo)" strokeWidth={2} name="Low °C"/>
              </AreaChart>
            </ResponsiveContainer>
          </section>

          {/* Rainfall forecast */}
          <section className="cr-chart-card">
            <h3 className="cr-chart-title">7-Day Rainfall Forecast (mm)</h3>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={trend} margin={{ top:10, right:10, left:-20, bottom:0 }}>
                <defs>
                  <linearGradient id="rain" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                <XAxis dataKey="day" tick={{ fontSize:12, fill:'#64748b' }}/>
                <YAxis tick={{ fontSize:12, fill:'#64748b' }}/>
                <Tooltip contentStyle={{ borderRadius:12, border:'1px solid #e2e8f0', fontSize:13 }}/>
                <Area type="monotone" dataKey="rain" stroke="#6366f1" fill="url(#rain)" strokeWidth={2} name="Rain mm"/>
              </AreaChart>
            </ResponsiveContainer>
          </section>

          {/* Radar chart */}
          <section className="cr-chart-card">
            <h3 className="cr-chart-title">Risk Profile Radar</h3>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#e2e8f0"/>
                <PolarAngleAxis dataKey="subject" tick={{ fontSize:11, fill:'#475569' }}/>
                <PolarRadiusAxis angle={30} domain={[0,100]} tick={{ fontSize:10 }}/>
                <Radar name="Risk" dataKey="score" stroke="#ef4444" fill="#ef4444" fillOpacity={0.25} strokeWidth={2}/>
              </RadarChart>
            </ResponsiveContainer>
          </section>
        </div>

        {/* ---- SMS / Voice Alert Section ---- */}
        <section className="cr-section">
          <h2 className="cr-section-title"><AlertTriangle size={20}/> Send SMS / Voice Alert</h2>
          <div className="cr-alert-send-card">
            <div className="cr-alert-send-left">
              <p className="cr-alert-send-desc">
                Send an instant multilingual weather risk alert to your phone via SMS or voice call.
                Powered by Twilio — works in Telugu, Hindi, and English.
              </p>
              <div className="cr-phone-row">
                <input
                  className="cr-phone-input"
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
                <select 
                  className="cr-alert-type-select"
                  value={alertType}
                  onChange={e => setAlertType(e.target.value)}
                >
                  <option value="sms">SMS Alert</option>
                  <option value="voice">Voice Call</option>
                </select>
                <button className="cr-btn-green" onClick={handleSendAlert} disabled={sendingAlert}>
                  {sendingAlert ? '⏳ Sending…' : '📲 Send Alert'}
                </button>
              </div>
              {alertSent && (
                <div className="cr-success-badge">
                  <CheckCircle size={16}/> Alert sent successfully!
                </div>
              )}
            </div>
            <div className="cr-alert-preview">
              <div className="cr-preview-label">Preview Message ({lang.toUpperCase()})</div>
              <p className="cr-preview-text">{buildAlertMessage()}</p>
            </div>
          </div>
        </section>

      </div>

      {/* ===== STYLES ===== */}
      <style>{`
        .cr-root { min-height:100vh; background:#f0f4f8; font-family:'Inter',sans-serif; }
        .cr-spinner { width:48px; height:48px; border-radius:50%; border:4px solid #e2e8f0; border-top-color:#16a34a; animation:spin .9s linear infinite; }
        @keyframes spin { to { transform:rotate(360deg); } }

        /* Hero */
        .cr-hero { padding:48px 24px 56px; color:#fff; }
        .cr-hero-inner { max-width:1100px; margin:0 auto; display:flex; gap:32px; flex-wrap:wrap; align-items:flex-start; }
        .cr-hero-left { flex:1; min-width:220px; }
        .cr-hero-right { flex:1; min-width:260px; }
        .cr-satellite-badge { display:inline-flex; align-items:center; gap:6px; background:rgba(255,255,255,.2); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,.3); padding:4px 12px; border-radius:999px; font-size:12px; font-weight:600; margin-bottom:12px; }
        .cr-hero-title { font-size:clamp(28px,6vw,44px); font-weight:800; letter-spacing:-1px; margin-bottom:8px; }
        .cr-location-row { display:flex; align-items:center; gap:6px; font-size:14px; opacity:.8; margin-bottom:24px; }
        .cr-overall-score { display:flex; align-items:center; gap:20px; }
        .cr-score-num { font-size:72px; font-weight:900; line-height:1; letter-spacing:-3px; }
        .cr-score-label { font-size:13px; opacity:.75; }
        .cr-score-level { font-size:20px; font-weight:700; }

        .cr-lang-row { display:flex; align-items:center; gap:8px; margin-bottom:12px; }
        .cr-lang-btn { background:rgba(255,255,255,.2); border:1px solid rgba(255,255,255,.3); color:#fff; padding:4px 12px; border-radius:999px; cursor:pointer; font-weight:600; font-size:13px; transition:background .2s; }
        .cr-lang-active { background:rgba(255,255,255,.45); }
        .cr-alert-box { background:rgba(255,255,255,.15); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,.25); border-radius:16px; padding:16px; }
        .cr-alert-msg { font-size:14px; font-weight:500; line-height:1.6; margin-bottom:10px; }
        .cr-tts-btn { display:inline-flex; align-items:center; gap:6px; background:rgba(255,255,255,.3); border:none; color:#fff; padding:6px 14px; border-radius:999px; font-size:13px; font-weight:600; cursor:pointer; }
        .cr-tts-btn:hover { background:rgba(255,255,255,.4); }

        /* Body */
        .cr-body { max-width:1100px; margin:-20px auto 0; padding:0 20px 60px; }
        .cr-section { margin-bottom:40px; }
        .cr-section-title { display:flex; align-items:center; gap:8px; font-size:20px; font-weight:700; color:#1e293b; margin-bottom:18px; }

        /* Risk Grid */
        .cr-risk-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:14px; }
        .cr-risk-card { border:1px solid; border-radius:20px; padding:18px; display:flex; flex-direction:column; gap:10px; transition:transform .2s,box-shadow .2s; }
        .cr-risk-card:hover { transform:translateY(-3px); box-shadow:0 8px 24px rgba(0,0,0,.1); }
        .cr-risk-card-top { display:flex; align-items:center; gap:10px; }
        .cr-risk-icon { padding:10px; border-radius:12px; }
        .cr-risk-name { font-size:14px; font-weight:700; color:#1e293b; }
        .cr-risk-badge { display:inline-block; padding:2px 10px; border-radius:999px; font-size:11px; font-weight:700; margin-top:2px; }
        .cr-risk-score { font-size:28px; font-weight:800; margin-left:auto; }
        .cr-progress-bar-bg { background:#e2e8f0; border-radius:999px; height:6px; overflow:hidden; }
        .cr-progress-bar-fill { height:100%; border-radius:999px; transition:width 1s ease; }
        .cr-risk-alert-text { font-size:12px; color:#475569; line-height:1.5; }
        .cr-mini-tts { display:inline-flex; align-items:center; gap:4px; background:none; border:1px solid #cbd5e1; color:#64748b; padding:3px 10px; border-radius:999px; font-size:11px; cursor:pointer; }

        /* Charts */
        .cr-charts-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px; margin-bottom:40px; }
        .cr-chart-card { background:#fff; border-radius:20px; padding:20px; border:1px solid #e2e8f0; box-shadow:0 2px 12px rgba(0,0,0,.06); }
        .cr-chart-title { font-size:15px; font-weight:700; color:#1e293b; margin-bottom:16px; }

        /* Alert send */
        .cr-alert-send-card { background:#fff; border-radius:24px; padding:28px; border:1px solid #e2e8f0; box-shadow:0 2px 12px rgba(0,0,0,.06); display:flex; gap:32px; flex-wrap:wrap; }
        .cr-alert-send-left { flex:1; min-width:220px; }
        .cr-alert-send-desc { font-size:15px; color:#475569; margin-bottom:16px; line-height:1.6; }
        .cr-phone-row { display:flex; gap:10px; flex-wrap:wrap; }
        .cr-phone-input { flex:1; min-width:180px; padding:10px 16px; border:1px solid #cbd5e1; border-radius:12px; font-size:15px; outline:none; }
        .cr-phone-input:focus { border-color:#16a34a; box-shadow:0 0 0 3px rgba(22,163,74,.15); }
        .cr-alert-type-select { padding:10px 12px; border:1px solid #cbd5e1; border-radius:12px; font-size:14px; background:#fff; outline:none; cursor:pointer; }
        .cr-btn-green { display:inline-flex; align-items:center; gap:6px; background:#16a34a; color:#fff; border:none; padding:10px 20px; border-radius:12px; font-size:14px; font-weight:600; cursor:pointer; transition:background .2s; }
        .cr-btn-green:hover { background:#15803d; }
        .cr-btn-green:disabled { opacity:.5; cursor:not-allowed; }
        .cr-success-badge { display:inline-flex; align-items:center; gap:6px; background:#f0fdf4; border:1px solid #bbf7d0; color:#16a34a; padding:6px 14px; border-radius:999px; font-size:13px; font-weight:600; margin-top:12px; }
        .cr-alert-preview { flex:1; min-width:220px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:16px; }
        .cr-preview-label { font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:.5px; margin-bottom:8px; }
        .cr-preview-text { font-size:14px; color:#334155; line-height:1.6; }
      `}</style>
    </div>
  );
}
