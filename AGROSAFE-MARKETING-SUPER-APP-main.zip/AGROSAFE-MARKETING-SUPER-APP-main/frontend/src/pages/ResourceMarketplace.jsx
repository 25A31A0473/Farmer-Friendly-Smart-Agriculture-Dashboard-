import React, { useState } from 'react';
import { Users, Calendar, Filter, Star, MapPin, PhoneCall, ShieldCheck, Briefcase, MessageSquareText } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const WORKERS = [
  { id: 1, name: "Ramesh Babu", skill: "Tractor Driver & Ploughing", rating: 4.8, jobs: 124, distance: "2 km away", price: "₹800/day", verified: true },
  { id: 2, name: "Sita Lakshmi", skill: "Harvesting & Sorting", rating: 4.9, jobs: 312, distance: "1.5 km away", price: "₹400/day", verified: true },
  { id: 3, name: "Kiran Kumar", skill: "Pesticide Spraying (Drone)", rating: 4.7, jobs: 89, distance: "5 km away", price: "₹1200/day", verified: true },
  { id: 4, name: "Venkatesh", skill: "General Labour", rating: 4.5, jobs: 45, distance: "3 km away", price: "₹500/day", verified: false },
];

export default function ResourceMarketplace() {
  const { t } = useTranslation();
  const [selectedWorker, setSelectedWorker] = useState(null);

  return (
    <div className="max-w-7xl mx-auto px-4 py-10 font-sans">
      <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-black uppercase tracking-widest mb-4">
            <Briefcase className="w-4 h-4" /> {t('resources.tag', 'Workforce Coordination')}
          </div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">{t('resources.title', 'Resource Marketplace')}</h2>
          <p className="text-slate-500 text-lg mt-2 font-medium">{t('resources.subtitle', 'Find and hire verified local agricultural experts instantly.')}</p>
        </div>
        <button className="px-6 py-3 bg-slate-900 text-white font-bold rounded-2xl flex items-center gap-2 hover:bg-black transition-all shadow-lg shadow-slate-200">
          <Filter className="w-5 h-5"/> {t('resources.filter', 'Filter Skills')}
        </button>
      </div>

      <div className="bg-blue-50 border border-blue-100 rounded-[2rem] p-6 mb-8 flex flex-col md:flex-row gap-6 items-center justify-between">
         <div>
            <h3 className="text-xl font-bold flex items-center gap-2 text-blue-900"><MessageSquareText className="w-6 h-6 text-blue-500" /> Worker Knowledge Share</h3>
            <p className="text-blue-700 text-sm mt-1">Updates from skilled workers in your region.</p>
         </div>
         <div className="flex-1 overflow-hidden relative h-16 w-full">
            <div className="absolute animate-[marquee_20s_linear_infinite] whitespace-nowrap flex gap-8 items-center h-full">
               <span className="bg-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm border border-blue-100"><b>Ramesh (Tractor):</b> Soil is too damp for ploughing today in North Village!</span>
               <span className="bg-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm border border-blue-100"><b>Kiran (Drone):</b> Offering 10% off for group drone spraying this weekend.</span>
               <span className="bg-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm border border-blue-100"><b>Sita (Harvest):</b> Looking for 2 more workers to join my sorting team tomorrow.</span>
            </div>
         </div>
         <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm whitespace-nowrap transition-colors">Share Update</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Workers List */}
        <div className="lg:col-span-8 space-y-4">
          {WORKERS.map(worker => (
            <div key={worker.id} className="bg-white border text-left border-gray-100 rounded-3xl p-6 shadow-sm hover:shadow-lg transition-all flex flex-col md:flex-row gap-6 items-start md:items-center cursor-pointer" onClick={() => setSelectedWorker(worker)}>
               <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center shrink-0">
                 <Users className="w-8 h-8 text-slate-400" />
               </div>
               <div className="flex-1 w-full">
                 <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-xl font-bold text-slate-900">{worker.name}</h3>
                    {worker.verified && <ShieldCheck className="w-5 h-5 text-blue-500" />}
                 </div>
                 <p className="text-slate-500 font-medium mb-3">{worker.skill}</p>
                 <div className="flex flex-wrap items-center gap-4 text-sm font-bold text-slate-400">
                    <span className="flex items-center gap-1 text-amber-500"><Star className="w-4 h-4 fill-current"/> {worker.rating}</span>
                    <span className="flex items-center gap-1"><Briefcase className="w-4 h-4"/> {worker.jobs} jobs</span>
                    <span className="flex items-center gap-1"><MapPin className="w-4 h-4"/> {worker.distance}</span>
                 </div>
               </div>
               <div className="flex flex-col items-end gap-3 shrink-0">
                  <span className="text-xl font-black text-slate-900">{worker.price}</span>
                  <button className="px-6 py-2.5 bg-nature-50 text-nature-700 hover:bg-nature-600 hover:text-white font-bold rounded-xl transition-colors">Select</button>
               </div>
            </div>
          ))}
        </div>

        {/* Sidebar Scheduling */}
        <div className="lg:col-span-4">
           {selectedWorker ? (
             <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white sticky top-24 shadow-2xl">
               <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Calendar className="text-amber-400"/> {t('resources.schedule', 'Schedule Work')}</h3>
               
               <div className="bg-white/10 p-5 rounded-2xl backdrop-blur-sm mb-6">
                 <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">{t('resources.selected_person', 'Selected Person')}</p>
                 <p className="text-xl font-black mb-1">{selectedWorker.name}</p>
                 <p className="text-amber-400 font-medium">{selectedWorker.skill}</p>
               </div>

               <div className="space-y-4 mb-8">
                 <div>
                   <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('resources.select_date', 'Select Date')}</label>
                   <input type="date" className="w-full mt-2 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-400" />
                 </div>
                 <div>
                   <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('resources.days_needed', 'Days Needed')}</label>
                   <select className="w-full mt-2 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-400">
                     <option className="bg-slate-900">{t('resources.duration_1d', '1 Day')}</option>
                     <option className="bg-slate-900">{t('resources.duration_2d', '2 Days')}</option>
                     <option className="bg-slate-900">{t('resources.duration_1w', '1 Week')}</option>
                   </select>
                 </div>
               </div>

               <button className="w-full py-4 bg-amber-500 hover:bg-amber-600 text-slate-900 font-black rounded-xl mb-3 transition-colors shadow-lg shadow-amber-500/20">{t('resources.book_now', 'Book Now')}</button>
               <button className="w-full py-4 bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"><PhoneCall className="w-5 h-5"/> {t('resources.call_directly', 'Call Directly')}</button>
             </div>
           ) : (
             <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2.5rem] p-10 text-center flex flex-col items-center justify-center h-[500px] sticky top-24">
                <Users className="w-16 h-16 text-slate-300 mb-4" />
                <p className="text-slate-500 font-bold text-lg">{t('resources.empty_state', 'Select a resource person to view scheduling options.')}</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
}
