import React, { useState, useEffect } from 'react';
import { Users, Award, Briefcase, Zap, MapPin, CheckCircle, ShieldAlert, Sparkles, HandHeart } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function ResourceDashboard() {
  const { t } = useTranslation();
  const [tasks, setTasks] = useState([]);
  const [volunteers, setVolunteers] = useState(mockVolunteers);
  const [loading, setLoading] = useState(true);

  // Gamification state
  const [credits, setCredits] = useState(1250);
  const [badges] = useState([
    { name: "Super Helper", icon: <HandHeart className="w-5 h-5" />, color: "text-rose-500", bg: "bg-rose-100" },
    { name: "Fast Response", icon: <Zap className="w-5 h-5" />, color: "text-amber-500", bg: "bg-amber-100" }
  ]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/resources/tasks');
      if (res.ok) {
        const data = await res.json();
        setTasks(data.length ? data : mockTasks);
      } else setTasks(mockTasks);
    } catch {
      setTasks(mockTasks);
    }
    setLoading(false);
  };

  const handleVolunteer = (taskId) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'assigned' } : t));
    setCredits(prev => prev + 150); // Gamification reward
  };

  const urgencyColors = {
    critical: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', icon: ShieldAlert },
    high: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', icon: Zap },
    medium: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', icon: Sparkles },
    low: { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200', icon: CheckCircle }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans">
      <div className="bg-white border-b border-slate-200 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <h1 className="text-4xl font-black text-slate-900 flex items-center gap-3">
              <Users className="w-10 h-10 text-blue-600" /> Community Resource
            </h1>
            <p className="text-slate-500 font-medium mt-2 text-lg">AI-Optimized Task Delegation & Volunteer Matching</p>
          </div>
          
          <div className="flex gap-4">
            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100 flex items-center gap-4">
              <div className="bg-amber-100 p-3 rounded-full"><Award className="w-6 h-6 text-amber-600" /></div>
              <div>
                <p className="text-xs font-bold text-amber-900 uppercase tracking-widest leading-none mb-1">Impact Credits</p>
                <p className="text-2xl font-black text-amber-600 leading-none">{credits}</p>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hidden sm:flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mr-2">Badges</span>
              {badges.map(b => (
                <div key={b.name} title={b.name} className={`w-10 h-10 rounded-full flex items-center justify-center ${b.bg} ${b.color}`}>
                  {b.icon}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Task Board */}
        <div className="lg:col-span-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Urgent Community Needs</h2>
            <button className="text-blue-600 font-bold hover:underline text-sm">Post a Request</button>
          </div>

          <div className="space-y-4">
            {loading ? (
              <div className="p-10 text-center text-slate-500">Ranking tasks using AI...</div>
            ) : tasks.map((task, i) => {
              const uColor = urgencyColors[task.urgency];
              const Icon = uColor.icon;
              return (
                <div key={task.id || i} className={`bg-white rounded-[2rem] p-6 border transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${uColor.bg} ${uColor.border} bg-opacity-30`}>
                  <div className="flex flex-col sm:flex-row justify-between gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1 ${uColor.bg} ${uColor.text} bg-opacity-100`}>
                          <Icon className="w-3 h-3" /> {task.urgency} Priority
                        </span>
                        <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {task.village}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">{task.title}</h3>
                      <p className="text-slate-600 font-medium leading-relaxed">{task.description}</p>
                    </div>
                    
                    <div className="flex flex-col items-end justify-between min-w-[140px]">
                      <div className="text-right mb-4 sm:mb-0">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Reward</span>
                        <span className="text-lg font-black text-amber-500 flex items-center justify-end gap-1"><Award className="w-4 h-4" /> +150</span>
                      </div>
                      <button 
                        onClick={() => handleVolunteer(task.id || i)}
                        disabled={task.status === 'assigned'}
                        className={`w-full py-3 rounded-xl font-bold capitalize transition-all active:scale-95 flex items-center justify-center gap-2 ${
                          task.status === 'assigned' ? 'bg-slate-100 text-slate-400 border border-slate-200' : 'bg-slate-900 hover:bg-black text-white shadow-lg shadow-slate-300'
                        }`}
                      >
                        {task.status === 'assigned' ? 'Assigned' : <><HandHeart className="w-4 h-4" /> Volunteer</>}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Volunteer Matches */}
        <div className="lg:col-span-4">
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-200 shadow-sm sticky top-24">
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <Briefcase className="w-6 h-6 text-slate-400" /> Auto-Matched Heroes
            </h3>
            
            <div className="space-y-6">
              {volunteers.map(vol => (
                <div key={vol.id} className="flex gap-4 items-center group">
                  <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center font-black group-hover:bg-blue-100 group-hover:text-blue-700 transition-colors">
                    {vol.volunteer_name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-slate-900 leading-none mb-1">{vol.volunteer_name}</p>
                    <p className="text-xs text-slate-500 font-medium truncate mb-2">{vol.skills.join(" • ")}</p>
                    <div className="flex gap-1">
                      {vol.preferred_village === 'Any' ? (
                        <span className="px-2 py-0.5 bg-green-50 text-green-700 rounded text-[10px] font-bold uppercase tracking-wider">Mobile</span>
                      ) : (
                        <span className="px-2 py-0.5 bg-slate-50 text-slate-500 rounded text-[10px] font-bold uppercase tracking-wider">{vol.preferred_village}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <button className="w-full mt-8 py-4 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-2xl transition-colors text-sm">
              View All Volunteers
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

const mockTasks = [
  { id: 1, title: "Emergency Harvest Help", description: "Approaching storm tomorrow. Need 5 people to help clear 2 acres of mature tomatoes.", urgency: "critical", village: "Medak", status: "open" },
  { id: 2, title: "Repair Main Canal", description: "Irrigation channel blocked by debris. Tools provided, need manual labor.", urgency: "high", village: "Warangal", status: "open" },
  { id: 3, title: "Tractor Sharing Request", description: "Need to plough half an acre. Willing to pay fuel and rental costs.", urgency: "medium", village: "Nizamabad", status: "assigned" }
];

const mockVolunteers = [
  { id: 1, volunteer_name: "Ramakrishna", skills: ["Tractor Driver", "Heavy Lifting"], preferred_village: "Warangal" },
  { id: 2, volunteer_name: "Anita M.", skills: ["First Aid", "Sorting"], preferred_village: "Any" },
  { id: 3, volunteer_name: "NGO Rural Aid", skills: ["Logistics", "Food Distibution"], preferred_village: "Any" }
];
