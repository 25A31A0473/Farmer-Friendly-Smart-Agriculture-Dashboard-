import React, { useState } from 'react';
import { Layers, Droplet, Sprout, RefreshCw, CheckCircle, AlertTriangle, Info, Upload } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const DATA = { ph:6.4, n:72, p:48, k:85, moisture:62, organic:3.8, temp:24.5, health:78 };

function Bar({ label, value, max=100, color, unit='%', badge }) {
  return (
    <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div>
          <p className="text-[11px] font-black uppercase tracking-widest text-gray-400">{label}</p>
          <p className="text-3xl font-black text-gray-900">{value}<span className="text-sm text-gray-400 ml-1">{unit}</span></p>
        </div>
        {badge && <span className={`text-xs font-black px-3 py-1 rounded-full ${badge==='Good'?'bg-green-100 text-green-700':badge==='Low'?'bg-amber-100 text-amber-700':'bg-red-100 text-red-700'}`}>{badge}</span>}
      </div>
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{width:`${Math.min((value/max)*100,100)}%`,background:color}} />
      </div>
    </div>
  );
}

export default function SoilHealthAnalysis() {
  const { t } = useTranslation();
  const [tab, setTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  const [scan, setScan] = useState('Today, 8:30 AM');

  const rescan = () => { setLoading(true); setTimeout(()=>{setLoading(false);setScan('Just now');},1800); };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 text-white py-12 px-4 sm:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-5">
              <div className="bg-white/10 p-4 rounded-2xl backdrop-blur">
                <Layers className="w-12 h-12 text-emerald-300" />
              </div>
              <div>
                <p className="text-emerald-300 text-xs font-black uppercase tracking-widest mb-1">AI-Powered</p>
                <h1 className="text-4xl font-black">{t('soil.title','Soil Health Analysis')}</h1>
                <p className="text-emerald-100 mt-1">{t('soil.subtitle','Real-time NPK, pH, moisture and microbial scores.')}</p>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center text-3xl font-black border-4 border-white/30 ${DATA.health>=70?'bg-green-500':'bg-amber-500'}`}>{DATA.health}</div>
              <p className="text-xs text-emerald-200 font-bold">Overall Health</p>
              <p className="text-xs text-white/50">Last scan: {scan}</p>
            </div>
          </div>
          <div className="flex gap-3 mt-8 flex-wrap">
            {['overview','nutrients','recommendations'].map(t2=>(
              <button key={t2} onClick={()=>setTab(t2)} className={`px-5 py-2 rounded-full font-bold text-sm capitalize transition-all ${tab===t2?'bg-white text-green-900':'bg-white/10 text-white hover:bg-white/20'}`}>{t2}</button>
            ))}
            <button onClick={rescan} disabled={loading} className="ml-auto flex items-center gap-2 px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full font-bold text-sm disabled:opacity-50 transition-all">
              <RefreshCw className={`w-4 h-4 ${loading?'animate-spin':''}`}/>{loading?'Scanning...':'Re-Scan'}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-8 mt-10 space-y-8">
        {tab==='overview' && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
              <Bar label="Soil pH" value={DATA.ph} max={14} color="#10b981" unit="" badge="Good"/>
              <Bar label="Moisture" value={DATA.moisture} color="#3b82f6" badge="Good"/>
              <Bar label="Temperature" value={DATA.temp} max={50} color="#f59e0b" unit="°C" badge="Good"/>
              <Bar label="Organic Matter" value={DATA.organic} max={10} color="#8b5cf6" unit="%" badge="Low"/>
            </div>
            <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
              <h2 className="text-xl font-black text-gray-900 mb-6">NPK Nutrient Levels</h2>
              <div className="space-y-5">
                {[{l:'Nitrogen (N)',v:DATA.n,c:'#10b981',b:'Good'},{l:'Phosphorus (P)',v:DATA.p,c:'#f59e0b',b:'Low'},{l:'Potassium (K)',v:DATA.k,c:'#6366f1',b:'Good'}].map(n=>(
                  <div key={n.l}>
                    <div className="flex justify-between mb-1">
                      <span className="font-bold text-gray-700 text-sm">{n.l}</span>
                      <span className="text-sm font-black" style={{color:n.c}}>{n.v} kg/ha • {n.b}</span>
                    </div>
                    <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{width:`${n.v}%`,background:n.c}}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-xl font-black text-emerald-900 mb-2">Connect IoT Soil Probes</h3>
                <p className="text-emerald-700 text-sm">Link your physical sensors for live NPK data. Compatible with all major brands.</p>
              </div>
              <div className="flex gap-3">
                <button className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg"><Upload className="w-5 h-5"/>Upload CSV</button>
                <button className="px-6 py-3 bg-white text-emerald-700 border border-emerald-300 rounded-xl font-bold hover:bg-emerald-50 transition-colors">Pair Sensor</button>
              </div>
            </div>
          </>
        )}

        {tab==='nutrients' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {l:'Nitrogen',v:DATA.n,max:150,c:'#10b981',u:'kg/ha',b:'Good',d:'Supports leaf and stem growth. Current level is adequate for moderate crops.'},
              {l:'Phosphorus',v:DATA.p,max:150,c:'#f59e0b',u:'kg/ha',b:'Low',d:'Low phosphorus reduces root development. Apply DAP at 50 kg/acre.'},
              {l:'Potassium',v:DATA.k,max:150,c:'#6366f1',u:'kg/ha',b:'Good',d:'Supports water regulation and disease resistance. Field is healthy.'},
              {l:'Microbial Health',v:DATA.health,max:100,c:'#ec4899',u:'score',b:'Good',d:'Healthy microbes indicate active nutrient cycling. Avoid excess pesticides.'},
              {l:'Organic Matter',v:DATA.organic,max:10,c:'#8b5cf6',u:'%',b:'Low',d:'Apply 2 tonnes/acre vermicompost to raise above 5%.'},
              {l:'Soil pH',v:DATA.ph,max:14,c:'#14b8a6',u:'',b:'Good',d:'pH 6.4 is ideal for most crops. No lime application needed.'},
            ].map(n=>(
              <div key={n.l} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <Bar label={n.l} value={n.v} max={n.max} color={n.c} unit={n.u} badge={n.b}/>
                <p className="text-gray-500 text-sm mt-3 flex gap-2"><Info className="w-4 h-4 text-gray-300 shrink-0 mt-0.5"/>{n.d}</p>
              </div>
            ))}
          </div>
        )}

        {tab==='recommendations' && (
          <div className="space-y-5">
            <h2 className="text-2xl font-black text-gray-900">AI Recommendations</h2>
            {[
              {icon:<Sprout className="w-5 h-5 text-emerald-600"/>,title:'Add Organic Compost',desc:'Increase organic matter from 3.8% to 5% by applying 2 tonnes/acre of vermicompost before the next sowing.',s:'info'},
              {icon:<Droplet className="w-5 h-5 text-blue-600"/>,title:'Irrigation Schedule',desc:'Soil moisture at 62% is adequate. Irrigate every 3 days and maintain 60–70%. Avoid over-watering.',s:'ok'},
              {icon:<AlertTriangle className="w-5 h-5 text-amber-600"/>,title:'Phosphorus Deficiency',desc:'Apply DAP fertilizer at 50 kg/acre. Low phosphorus reduces root development and fruit yield.',s:'warn'},
            ].map((r,i)=>(
              <div key={i} className={`bg-white rounded-2xl p-6 border shadow-sm flex gap-5 items-start ${r.s==='warn'?'border-amber-200 bg-amber-50/30':r.s==='ok'?'border-green-200':'border-blue-200 bg-blue-50/30'}`}>
                <div className={`p-3 rounded-xl shrink-0 ${r.s==='warn'?'bg-amber-100':r.s==='ok'?'bg-green-100':'bg-blue-100'}`}>{r.icon}</div>
                <div><h3 className="font-black text-gray-900 text-lg mb-1">{r.title}</h3><p className="text-gray-600 text-sm">{r.desc}</p></div>
                <CheckCircle className={`w-6 h-6 ml-auto shrink-0 mt-1 ${r.s==='ok'?'text-green-500':'text-gray-300'}`}/>
              </div>
            ))}
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl p-8 text-white text-center">
              <h3 className="text-2xl font-black mb-2">Generate Full AI Soil Report</h3>
              <p className="text-green-100 mb-6">Detailed 10-page PDF with crop-specific fertilizer schedules and soil maps.</p>
              <button className="px-8 py-3 bg-white text-green-800 rounded-xl font-black hover:bg-green-50 transition-colors shadow-xl">Download Report</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
