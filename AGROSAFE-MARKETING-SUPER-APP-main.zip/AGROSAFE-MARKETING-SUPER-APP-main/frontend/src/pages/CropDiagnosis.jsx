import React, { useState, useRef } from 'react';
import { Camera, Upload, CheckCircle, RefreshCcw, Sparkles, Volume2, Cpu, Leaf, Droplet, Stethoscope, Hexagon, ShoppingCart, AlertCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function CropDiagnosis() {
  const { t, i18n } = useTranslation();
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const fileInputRef = useRef(null);

  // Sensor & Form Inputs
  const [description, setDescription] = useState("");
  const [soilpH, setSoilpH] = useState("6.5");
  const [moisture, setMoisture] = useState("45");
  const [nitrogen, setNitrogen] = useState("Medium");

  const [activeDimension, setActiveDimension] = useState("AI Action Plan");

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
    }
  };

  const runQuantumDiagnosis = async () => {
    if (!image) {
      alert("Please upload a leaf/fruit image first.");
      return;
    }
    setIsScanning(true);
    setResult(null);
    setScanProgress(10);

    // Simulate Hybrid Quantum Pipeline
    setTimeout(() => setScanProgress(30), 1000); // Classical Preprocessing
    setTimeout(() => setScanProgress(60), 2500); // Quantum SVM
    setTimeout(() => setScanProgress(90), 4000); // Post-processing
    
    setTimeout(async () => {
      try {
        const fileRes = await fetch(image);
        const blob = await fileRes.blob();
        const formData = new FormData();
        formData.append("file", blob, "crop_image.jpg");

        const res = await fetch(`http://localhost:8000/api/diagnose_crop?lang=${i18n.language}`, {
          method: "POST",
          body: formData
        });
        const data = await res.json();

        setResult({
          disease: data.disease || "Unknown Issue",
          confidence: data.confidence || 0.90,
          confidence_pct: data.confidence_pct || "90%",
          severity: data.severity || "Moderate",
          model: data.model || "AgroSafe Quantum AI",
          dimensions: {
            "Organic": { icon: <Leaf />, title: "Organic & Sustainable", text: data.remedy_organic || "No organic data." },
            "Chemical": { icon: <Hexagon />, title: "Chemical Guidelines", text: data.remedy_chemical || "No chemical data." },
            "Technology": { icon: <Cpu />, title: "Modern Tech / IoT", text: data.remedy_tech || "No tech data." },
            "Ancient": { icon: <Sparkles />, title: "Ancient Wisdom", text: data.remedy_ancient || "No ancient data." },
            "Futuristic": { icon: <Volume2 />, title: "Quantum & Biotech", text: data.remedy_future || "No future data." }
          }
        });
        setActiveDimension("Organic");
      } catch (err) {
        console.error(err);
        setResult({
          disease: "Network Error",
          confidence_pct: "0%",
          severity: "Unknown",
          model: "Offline",
          dimensions: {
            "Error": { icon: <AlertCircle />, title: "Connection Failed", text: "Ensure the backend is running at localhost:8000." }
          }
        });
        setActiveDimension("Error");
      }
      setScanProgress(100);
      setTimeout(() => setIsScanning(false), 500);
    }, 4500);
  };

  const speak = (text) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = i18n.language === 'hi' ? 'hi-IN' : i18n.language === 'te' ? 'te-IN' : 'en-IN';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 font-sans">
      {/* Header Section */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-nature-950 text-nature-400 rounded-full text-sm font-bold mb-4 shadow-lg">
          <Cpu className="w-4 h-4 text-cyan-400" /> {t('crop_diag.tag', 'Quantum-Enhanced Pipeline Active')}
        </div>
        <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">{t('crop_diag.title', 'Multi-Dimensional Crop Diagnosis')}</h2>
        <p className="text-gray-500 max-w-3xl mx-auto text-lg leading-relaxed">
          {t('crop_diag.subtitle', 'Input your sensor data, describe the issue, and upload an image. Our Hybrid Quantum ML Engine (QSVM) will analyze the crop and provide optimal remedies across 5 dimensions.')}
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        {/* Left Column: Inputs & Upload */}
        <div className={`xl:col-span-5 flex flex-col gap-6 ${isScanning || result ? 'opacity-50 pointer-events-none' : ''} transition-opacity`}>
          
          {/* Data Inputs */}
          <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-8">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-6">
              <Droplet className="text-blue-500"/> {t('crop_diag.sensor_title', 'Sensor & Field Data')}
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">{t('crop_diag.soil_ph', 'Soil pH')}</label>
                <input type="number" step="0.1" value={soilpH} onChange={e=>setSoilpH(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-medium outline-none focus:border-nature-500" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">{t('crop_diag.moisture', 'Moisture (%)')}</label>
                <input type="number" value={moisture} onChange={e=>setMoisture(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-medium outline-none focus:border-nature-500" />
              </div>
            </div>
            <div className="mb-6">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">{t('crop_diag.nitrogen', 'Nitrogen Level')}</label>
              <select value={nitrogen} onChange={e=>setNitrogen(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-medium outline-none focus:border-nature-500">
                <option>{t('crop_diag.low', 'Low')}</option>
                <option>{t('crop_diag.medium', 'Medium')}</option>
                <option>{t('crop_diag.high', 'High')}</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">{t('crop_diag.desc_label', "Farmer's Description (NLP Input)")}</label>
              <textarea 
                rows="3" 
                placeholder={t('crop_diag.desc_placeholder', "E.g., Leaves are turning yellow at the edges and dropping early...")}
                value={description} onChange={e=>setDescription(e.target.value)} 
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-medium outline-none focus:border-nature-500 resize-none"
              />
            </div>
          </div>

          {/* Image Upload */}
          <div 
            className="bg-white border-2 border-dashed border-gray-300 rounded-3xl p-8 text-center hover:border-nature-500 transition-all cursor-pointer shadow-lg"
            onClick={() => !image && fileInputRef.current?.click()}
          >
            {!image ? (
              <>
                <div className="bg-nature-50 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-10 h-10 text-nature-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">{t('crop_diag.upload_title', 'Upload Leaf/Fruit Image')}</h3>
                <p className="text-gray-400 text-sm mt-2 mb-6">{t('crop_diag.upload_subtitle', 'Classical CNN preprocessing step')}</p>
                <button className="px-6 py-2 bg-nature-600 text-white font-bold rounded-xl hover:bg-nature-700 shadow-md transition-all">
                  {t('crop_diag.browse', 'Browse Files')}
                </button>
              </>
            ) : (
              <div className="relative group">
                <img src={image} alt="Crop Preview" className="w-full h-64 object-cover rounded-2xl" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl flex items-center justify-center">
                  <button onClick={(e) => { e.stopPropagation(); setImage(null); }} className="px-4 py-2 bg-white text-gray-900 font-bold rounded-xl">{t('crop_diag.change_image', 'Change Image')}</button>
                </div>
              </div>
            )}
            <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
          </div>

          <button 
            onClick={runQuantumDiagnosis}
            disabled={!image}
            className={`w-full py-5 rounded-3xl font-black text-xl shadow-xl flex items-center justify-center gap-3 transition-all ${image ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white hover:scale-[1.02]' : 'bg-gray-100 text-gray-400'}`}
          >
            <Sparkles /> {t('crop_diag.init_quantum', 'Initialize Quantum Classifier')}
          </button>
        </div>

        {/* Right Column: Processing & Results */}
        <div className="xl:col-span-7">
          {!isScanning && !result && (
            <div className="h-full min-h-[500px] flex flex-col items-center justify-center bg-gray-50 border-2 border-dashed border-gray-200 rounded-[2.5rem]">
              <Hexagon className="w-16 h-16 text-gray-300 mb-4" />
              <p className="text-gray-400 font-bold text-lg">{t('crop_diag.awaiting', 'Awaiting Quantum Input Data...')}</p>
            </div>
          )}

          {isScanning && (
            <div className="h-full min-h-[500px] flex flex-col items-center justify-center bg-black rounded-[2.5rem] relative overflow-hidden text-white border border-gray-800 shadow-2xl">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-black to-black" />
              <div className="relative w-32 h-32 mb-8">
                <RefreshCcw className="w-32 h-32 animate-spin text-cyan-500 opacity-20" />
                <Cpu className="absolute inset-0 m-auto w-12 h-12 text-cyan-400 animate-pulse" />
              </div>
              <p className="text-xl font-black tracking-[0.3em] mb-3 text-cyan-400">HYBRID QSVM PROCESSING</p>
              <p className="text-gray-400 text-sm font-mono tracking-wider mb-8">
                {scanProgress < 40 ? "Classical CNN Feature Extraction..." : 
                 scanProgress < 80 ? "Quantum Neural Network Entanglement..." : 
                 "Decoding Post-measurement States..."}
              </p>
              
              <div className="w-full max-w-sm h-1 bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-400 transition-all duration-[1500ms] ease-out shadow-[0_0_10px_#22d3ee]" style={{ width: `${scanProgress}%` }} />
              </div>
            </div>
          )}

          {!isScanning && result && (
            <div className="bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 p-8 md:p-12 animate-in slide-in-from-right duration-500">
              {/* Result Header */}
              <div className="flex flex-wrap items-center justify-between gap-4 mb-8 border-b border-gray-100 pb-8">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-black uppercase tracking-widest mb-3">
                    <Cpu className="w-3 h-3"/> {result.model}
                  </div>
                  <h3 className="text-3xl md:text-4xl font-black text-gray-900 leading-tight">{result.disease}</h3>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">{t('crop_diag.confidence', 'Quantum Confidence')}</span>
                  <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                    {result.confidence_pct}
                  </span>
                </div>
              </div>

              {/* 5-Dimensional Solutions */}
              <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Multi-Dimensional Solutions</h4>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {Object.keys(result.dimensions).map(dim => (
                  <button 
                    key={dim}
                    onClick={() => setActiveDimension(dim)}
                    className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
                      activeDimension === dim 
                        ? 'bg-gray-900 text-white shadow-lg' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    <span className={activeDimension === dim ? 'text-blue-400' : 'text-gray-400'}>
                      {result.dimensions[dim].icon}
                    </span>
                    {dim}
                  </button>
                ))}
              </div>

              {/* Active Dimension Content */}
              <div className="bg-slate-50 border border-slate-200 rounded-3xl p-8 mb-8 relative min-h-[160px]">
                <h5 className="text-xl font-bold text-gray-900 mb-3">{result.dimensions[activeDimension].title}</h5>
                <p className="text-slate-700 text-lg leading-relaxed">
                  {result.dimensions[activeDimension].text}
                </p>
                <div className="absolute top-4 right-6 opacity-10">
                  {result.dimensions[activeDimension].icon}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <button 
                  className="flex-1 px-6 py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-black transition-all flex items-center justify-center gap-2"
                  onClick={() => speak(result.dimensions[activeDimension].text)}
                >
                  <Volume2 className="w-5 h-5" /> {t('crop_diag.listen', 'Listen to Solution')}
                </button>
                <button 
                  className="flex-1 px-6 py-4 bg-nature-600 text-white font-bold rounded-2xl hover:bg-nature-700 shadow-lg shadow-nature-200 transition-all flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="w-5 h-5" /> {t('crop_diag.buy', 'Buy on AgroSafe Market')}
                </button>
              </div>

              <button 
                onClick={() => { setImage(null); setResult(null); setIsScanning(false); }} 
                className="w-full mt-4 py-3 text-sm font-bold text-gray-400 hover:text-gray-600 uppercase tracking-widest flex items-center justify-center gap-2"
              >
                <RefreshCcw className="w-4 h-4" /> {t('crop_diag.reset', 'Reset Analysis')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
