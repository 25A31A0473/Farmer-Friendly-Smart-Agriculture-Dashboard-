import React, { useState, useRef, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, Flame, PhoneCall, Camera, Upload, MapPin, Activity, BellRing, FileDigit, Cpu, ChevronRight, X, TriangleAlert } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function SecurityCenter() {
  const { t } = useTranslation();
  
  // SOS State
  const [sosActive, setSosActive] = useState(false);
  const [sosCountdown, setSosCountdown] = useState(3);
  
  // Crime Reporting State
  const [reportType, setReportType] = useState('Theft');
  const [reportDesc, setReportDesc] = useState('');
  const [evidence, setEvidence] = useState(null);
  const fileInputRef = useRef(null);
  const [reportSubmitted, setReportSubmitted] = useState(false);

  // IoT Gas Leak Simulation
  const [gasLevel, setGasLevel] = useState(12); // Safe is < 20% LEL
  const [leakDetected, setLeakDetected] = useState(false);

  useEffect(() => {
    // IoT Gas Level Simulation
    const interval = setInterval(() => {
      setGasLevel(prev => {
        const fluctuation = Math.random() > 0.8 ? (Math.random() * 15) : (Math.random() * 2 - 1);
        const newLevel = Math.max(0, Math.min(100, prev + fluctuation));
        if (newLevel > 25 && !leakDetected) setLeakDetected(true);
        if (newLevel < 20 && leakDetected) setLeakDetected(false);
        return Number(newLevel.toFixed(1));
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [leakDetected]);

  const handleSOS = () => {
    if (sosActive) {
      setSosActive(false);
      setSosCountdown(3);
      return;
    }
    setSosActive(true);
    let counter = 3;
    const sosTimer = setInterval(() => {
      counter -= 1;
      setSosCountdown(counter);
      if (counter <= 0) {
        clearInterval(sosTimer);
        alert(t('security.sos_sent', 'SOS SENT! GPS Location broadcasted to nearest hospital, police, and emergency contacts.'));
      }
    }, 1000);
  };

  const handleEvidenceUpload = (e) => {
    if (e.target.files[0]) setEvidence(URL.createObjectURL(e.target.files[0]));
  };

  const submitCrimeReport = (e) => {
    e.preventDefault();
    if (!reportDesc) return;
    setReportSubmitted(true);
    setTimeout(() => {
      setReportSubmitted(false);
      setReportDesc('');
      setEvidence(null);
      alert(t('security.report_success', 'Crime report submitted successfully to local authorities with GPS and evidence. Case tracking ID generated.'));
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 pb-20 font-sans selection:bg-red-500/30">
      
      {/* Header */}
      <div className="relative border-b border-red-900/50 bg-slate-950 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-red-900/20 via-slate-900 to-slate-950"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-red-500/10 p-3 rounded-2xl border border-red-500/20 shadow-[0_0_30px_rgba(239,68,68,0.2)]">
                <ShieldCheck className="w-8 h-8 text-red-500" />
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight">{t('security.title', 'Emergency & Citizen Safety')}</h1>
            </div>
            <p className="text-slate-400 max-w-xl text-lg font-medium">{t('security.subtitle', 'Immediate SOS response, crime reporting, and real-time IoT hazard detection for rural and urban safety.')}</p>
          </div>
          
          <div className="flex gap-4">
            <button 
              onClick={handleSOS}
              className={`relative overflow-hidden rounded-[2rem] p-8 border-2 transition-all duration-300 shadow-2xl active:scale-95 ${sosActive && sosCountdown > 0 ? 'bg-red-600 border-red-500 text-white animate-pulse' : sosActive && sosCountdown <= 0 ? 'bg-black border-red-600 text-red-500' : 'bg-gradient-to-br from-red-600 to-red-800 border-red-500 text-white shadow-[0_0_40px_rgba(239,68,68,0.4)] hover:shadow-[0_0_60px_rgba(239,68,68,0.6)]'}`}
            >
              <div className="flex flex-col items-center justify-center min-w-[120px]">
                <TriangleAlert className={`w-12 h-12 mb-3 ${sosActive && sosCountdown > 0 ? 'animate-bounce' : ''}`} />
                <div className="text-3xl font-black uppercase tracking-widest">{sosActive && sosCountdown > 0 ? sosCountdown : sosActive && sosCountdown <= 0 ? 'SENT' : 'SOS'}</div>
                <div className="text-[10px] uppercase tracking-widest font-bold mt-2 opacity-80">{sosActive ? 'Tap to Cancel' : 'Hold to Alert'}</div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Hazard Alerts Banner */}
      <div className="max-w-7xl mx-auto px-4 mt-8">
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between shadow-[0_0_15px_rgba(245,158,11,0.1)]">
           <div className="flex items-center gap-3 mb-2 sm:mb-0">
              <Flame className="w-6 h-6 text-amber-500 animate-pulse" />
              <div>
                 <h3 className="text-amber-500 font-bold">{t('security.hazard_alert', 'Preventive Alert: High Fire Risk in Region')}</h3>
                 <p className="text-amber-500/70 text-sm font-medium">{t('security.hazard_desc', 'Dry weather detected. Avoid stubble burning today.')}</p>
              </div>
           </div>
           <button className="px-4 py-2 bg-amber-500/20 text-amber-500 rounded-lg text-sm font-bold hover:bg-amber-500/30 transition-colors">{t('security.view_map', 'View Hazard Map')}</button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Crime Reporting Portal */}
        <div className="bg-slate-800/50 backdrop-blur-xl rounded-[2.5rem] p-8 border border-slate-700 shadow-2xl relative overflow-hidden group">
          <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-3 relative z-10">
            <ShieldCheck className="text-blue-400" /> {t('security.crime_report', 'Crime Reporting System')}
          </h2>
          <p className="text-slate-400 mb-8 relative z-10">{t('security.crime_desc', 'Securely report farm theft, equipment damage, or suspicious activity to local authorities.')}</p>

          <form onSubmit={submitCrimeReport} className="relative z-10 space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 block">{t('security.incident_type', 'Incident Type')}</label>
                <select value={reportType} onChange={e=>setReportType(e.target.value)} className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 px-4 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none font-medium">
                  <option>Crop Theft</option>
                  <option>Equipment Vandalism</option>
                  <option>Fraud/Scam</option>
                  <option>Livestock Missing</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 block">{t('security.location', 'Location')}</label>
                <div className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 px-4 text-slate-400 font-mono text-sm flex items-center gap-2 cursor-not-allowed">
                  <MapPin className="w-4 h-4 text-blue-500"/> GPS Auto-Tagged
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 block">{t('security.description', 'Description')}</label>
              <textarea 
                rows="3" 
                value={reportDesc}
                onChange={e=>setReportDesc(e.target.value)}
                placeholder="Details of the incident..." 
                className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 px-4 text-white focus:border-blue-500 outline-none resize-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2 block">{t('security.evidence', 'Upload Evidence (Photo/Video)')}</label>
              <input type="file" accept="image/*,video/*" className="hidden" ref={fileInputRef} onChange={handleEvidenceUpload} />
              
              {!evidence ? (
                <button type="button" onClick={() => fileInputRef.current?.click()} className="w-full py-6 bg-slate-900/50 border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-xl text-slate-400 flex flex-col items-center justify-center transition-colors">
                  <Camera className="w-8 h-8 mb-2 opacity-50" />
                  <span className="font-bold text-sm">Tap to Attach Media</span>
                </button>
              ) : (
                <div className="relative rounded-xl overflow-hidden h-32 border border-slate-700">
                  <img src={evidence} alt="Evidence" className="w-full h-full object-cover opacity-70" />
                  <button type="button" onClick={() => setEvidence(null)} className="absolute top-2 right-2 bg-black/50 p-1.5 rounded-full hover:bg-black text-white backdrop-blur"><X className="w-4 h-4"/></button>
                </div>
              )}
            </div>
            
            <button 
              type="submit" 
              disabled={reportSubmitted || !reportDesc}
              className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl font-black transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)] flex justify-center items-center gap-2"
            >
              {reportSubmitted ? <Activity className="w-5 h-5 animate-spin"/> : <Upload className="w-5 h-5"/>}
              {reportSubmitted ? t('security.submitting', 'Filing Report...') : t('security.submit_report', 'Submit Secure Report')}
            </button>
          </form>
        </div>

        {/* IoT Gas Leak Simulation */}
        <div className="bg-slate-800/50 backdrop-blur-xl rounded-[2.5rem] p-8 border border-slate-700 shadow-2xl relative overflow-hidden group flex flex-col">
          <div className="flex justify-between items-center mb-2 relative z-10">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <Cpu className="text-teal-400" /> {t('security.iot_monitor', 'IoT Sensor Network')}
            </h2>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${leakDetected ? 'bg-red-500' : 'bg-teal-400'} animate-pulse`}></span>
              <span className={`text-[10px] font-black tracking-widest uppercase ${leakDetected ? 'text-red-500' : 'text-teal-400'}`}>Live</span>
            </div>
          </div>
          <p className="text-slate-400 mb-8 relative z-10 text-sm">Real-time telemetry from connected LPG, Smoke, and Environment sensors in your facility.</p>

          <div className="flex-1 flex flex-col items-center justify-center relative z-10 py-10">
            {/* Gas Level Dial */}
            <div className="relative w-48 h-48 mb-6 flex items-center justify-center">
              <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                <circle cx="96" cy="96" r="80" stroke="rgba(255,255,255,0.05)" strokeWidth="16" fill="none" />
                <circle 
                  cx="96" cy="96" r="80" 
                  stroke={leakDetected ? '#ef4444' : '#2dd4bf'} 
                  strokeWidth="16" 
                  fill="none" 
                  strokeDasharray="502" 
                  strokeDashoffset={502 - (502 * gasLevel) / 100}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="text-center">
                <div className={`text-5xl font-black ${leakDetected ? 'text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]' : 'text-white'}`}>{gasLevel}%</div>
                <div className="text-xs uppercase tracking-widest font-bold text-slate-500 mt-1">LEL Gas</div>
              </div>
            </div>

            {leakDetected ? (
              <div className="bg-red-500/10 border border-red-500 text-red-500 px-6 py-4 rounded-xl text-center shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-pulse w-full max-w-sm">
                <h3 className="font-black text-lg flex justify-center items-center gap-2 mb-1"><BellRing className="w-5 h-5"/> GAS LEAK DETECTED</h3>
                <p className="text-sm font-medium">Ventilation activated. Fire department alerted via API.</p>
              </div>
            ) : (
              <div className="bg-teal-500/10 border border-teal-500/30 text-teal-400 px-6 py-4 rounded-xl text-center w-full max-w-sm">
                <h3 className="font-bold flex justify-center items-center gap-2 mb-1"><ShieldCheck className="w-5 h-5"/> Environment Safe</h3>
                <p className="text-sm text-teal-400/70 font-medium">All sensor parameters nominal.</p>
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-auto relative z-10 pt-6 border-t border-slate-700">
            <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-widest mb-1">CO2 Level</div>
              <div className="text-lg font-black text-white">412 ppm</div>
            </div>
            <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-widest mb-1">Temp</div>
              <div className="text-lg font-black text-white">24.5°C</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
