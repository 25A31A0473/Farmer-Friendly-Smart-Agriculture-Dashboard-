// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC_Mi1IDmpCFX6zAh8LugmF_GgJNglyd-A",
  authDomain: "agrosafe-new.firebaseapp.com",
  projectId: "agrosafe-new",
  storageBucket: "agrosafe-new.firebasestorage.app",
  messagingSenderId: "512914260415",
  appId: "1:512914260415:web:c421d6482b2ef9a6dea10a",
  measurementId: "G-JYRHLV3ESP"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
// Analytics can throw on localhost — guard it
let analytics = null;
try { analytics = getAnalytics(app); } catch (_) {}
export { analytics };

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);
