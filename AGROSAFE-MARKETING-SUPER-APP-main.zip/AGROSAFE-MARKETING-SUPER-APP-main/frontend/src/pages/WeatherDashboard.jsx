import React, { useState, useEffect, useCallback } from 'react';
import {
  Cloud, CloudRain, CloudSnow, CloudLightning, Sun, Wind,
  Droplets, MapPin, Thermometer, Eye, Gauge, Umbrella,
  Sunrise, Sunset, Leaf, AlertTriangle, RefreshCw, Volume2
} from 'lucide-react';

// --- Open-Meteo WMO code → label & icon ---
function interpretWMO(code) {
  if (code === 0) return { label: 'Clear Sky',        Icon: Sun };
  if (code <= 2)  return { label: 'Partly Cloudy',    Icon: Cloud };
  if (code === 3) return { label: 'Overcast',         Icon: Cloud };
  if (code <= 49) return { label: 'Foggy',            Icon: Cloud };
  if (code <= 59) return { label: 'Drizzle',          Icon: CloudRain };
  if (code <= 69) return { label: 'Rain',             Icon: CloudRain };
  if (code <= 79) return { label: 'Snow',             Icon: CloudSnow };
  if (code <= 84) return { label: 'Rain Showers',     Icon: CloudRain };
  if (code <= 94) return { label: 'Snow Showers',     Icon: CloudSnow };
  return { label: 'Thunderstorm', Icon: CloudLightning };
}

// --- Generate AI Farming tip from real weather ---
function generateFarmingTip(current, daily) {
  const { temp, humidity, windspeed, wmo_code, precipitation } = current;
  const tips = [];

  if (wmo_code >= 60 && wmo_code <= 69)
    tips.push('Heavy rain expected — delay pesticide / fertiliser spraying to avoid run-off.');
  if (wmo_code >= 95)
    tips.push('Thunderstorm warning — secure equipment and stay indoors. Postpone field work.');
  if (temp > 35)
    tips.push('Extreme heat alert! Water crops early morning or after sunset to minimise evaporation.');
  else if (temp > 28)
    tips.push('High temperatures — schedule irrigation for early morning for best absorption.');
  if (humidity < 30)
    tips.push('Very low humidity — increase irrigation frequency to prevent crop moisture stress.');
  if (humidity > 80)
    tips.push('High humidity increases fungal disease risk. Consider a preventive fungicide application.');
  if (windspeed > 30)
    tips.push('Strong winds today — avoid spraying chemicals as drift can damage adjacent crops.');
  if (precipitation < 1 && temp > 25)
    tips.push('No rain forecast — ensure drip or sprinkler irrigation is scheduled to maintain soil moisture.');
  if (daily?.temperature_2m_max?.[0] < 15)
    tips.push('Cool temperatures ahead — protect sensitive seedlings with mulching or row covers.');

  if (tips.length === 0)
    tips.push('Weather conditions look favourable! Great day to inspect crops or apply scheduled treatments.');

  return tips.join(' ');
}

// --- Sky gradient based on weather & hour ---
function getSkyStyle(wmo_code, isDay) {
  if (!isDay) return 'from-indigo-900 via-blue-950 to-slate-900';
  if (wmo_code === 0) return 'from-sky-400 via-blue-500 to-indigo-500';
  if (wmo_code <= 2)  return 'from-sky-300 via-blue-400 to-slate-500';
  if (wmo_code <= 49) return 'from-slate-400 via-gray-500 to-gray-600';
  if (wmo_code <= 69) return 'from-slate-500 via-blue-700 to-indigo-700';
  if (wmo_code >= 95) return 'from-gray-700 via-slate-800 to-zinc-900';
  return 'from-slate-400 via-blue-600 to-indigo-600';
}

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function WeatherDashboard() {
  const [weather, setWeather]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [locName, setLocName]   = useState('Your Location');
  const [coords, setCoords]     = useState(null);
  const [unit, setUnit]         = useState('C'); // 'C' or 'F'

  const toF = (c) => Math.round(c * 9 / 5 + 32);
  const displayTemp = (c) => unit === 'C' ? `${Math.round(c)}°C` : `${toF(c)}°F`;

  // --- Fetch real weather from Open-Meteo (no API key needed) ---
  const fetchWeather = useCallback(async (lat, lon) => {
    setLoading(true);
    setError(null);
    try {
      const url =
        `https://api.open-meteo.com/v1/forecast?` +
        `latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,apparent_temperature,relative_humidity_2m,` +
        `precipitation,weather_code,wind_speed_10m,wind_direction_10m,` +
        `surface_pressure,visibility,is_day` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,` +
        `precipitation_sum,uv_index_max,sunrise,sunset` +
        `&timezone=auto&forecast_days=7`;

      const res  = await fetch(url);
      if (!res.ok) throw new Error('Weather service unavailable');
      const data = await res.json();
      setWeather(data);

      // Reverse-geocode city name (free Nominatim)
      try {
        const geo = await fetch(
          `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`
        );
        const gd = await geo.json();
        const city = gd.address?.city || gd.address?.town || gd.address?.village || gd.address?.county || 'Your Location';
        const state = gd.address?.state || '';
        setLocName(state ? `${city}, ${state}` : city);
      } catch (_) { /* silently ignore reverse-geocode failure */ }
    } catch (e) {
      setError(e.message || 'Failed to fetch weather data.');
    } finally {
      setLoading(false);
    }
  }, []);

  // --- Geolocation on mount ---
  useEffect(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lon } = pos.coords;
        setCoords({ lat, lon });
        fetchWeather(lat, lon);
      },
      (err) => {
        console.warn('Geolocation denied, falling back to Hyderabad.', err);
        const lat = 17.385, lon = 78.4867;
        setCoords({ lat, lon });
        setLocName('Hyderabad, Telangana');
        fetchWeather(lat, lon);
      },
      { timeout: 8000 }
    );
  }, [fetchWeather]);

  // --- TTS ---
  const speak = (text) => {
    const u = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  /* ====================== LOADING ====================== */
  if (loading) return (
    <div className="weather-loading">
      <div className="weather-loader-ring" />
      <p>Fetching real-time local forecast…</p>
    </div>
  );

  /* ====================== ERROR ====================== */
  if (error || !weather) return (
    <div className="weather-error-box">
      <AlertTriangle size={40} style={{ color: '#f59e0b', marginBottom: 12 }} />
      <p style={{ color: '#b45309', fontWeight: 600, marginBottom: 8 }}>{error || 'Unknown error'}</p>
      <button className="weather-retry-btn" onClick={() => coords && fetchWeather(coords.lat, coords.lon)}>
        <RefreshCw size={14} /> Try Again
      </button>
    </div>
  );

  /* ======================== DATA ======================== */
  const cur     = weather.current;
  const daily   = weather.daily;
  const isDay   = cur.is_day === 1;
  const { label: condition, Icon: CondIcon } = interpretWMO(cur.weather_code);
  const skyGrad = getSkyStyle(cur.weather_code, isDay);
  const tip     = generateFarmingTip({
    temp: cur.temperature_2m,
    humidity: cur.relative_humidity_2m,
    windspeed: cur.wind_speed_10m,
    wmo_code: cur.weather_code,
    precipitation: cur.precipitation,
  }, daily);

  const uvMax = daily?.uv_index_max?.[0] ?? null;
  const uvLabel = uvMax === null ? '—' : uvMax <= 2 ? 'Low' : uvMax <= 5 ? 'Moderate' : uvMax <= 7 ? 'High' : uvMax <= 10 ? 'Very High' : 'Extreme';
  const uvColor = uvMax === null ? '#6b7280' : uvMax <= 2 ? '#22c55e' : uvMax <= 5 ? '#eab308' : uvMax <= 7 ? '#f97316' : '#ef4444';

  const sunriseRaw = daily?.sunrise?.[0];
  const sunsetRaw  = daily?.sunset?.[0];
  const fmt = (iso) => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="wd-root">
      {/* ===== Hero / Current Weather ===== */}
      <div className={`wd-hero bg-gradient-to-br ${skyGrad}`}>
        {/* floating blobs */}
        <div className="wd-blob blob1" />
        <div className="wd-blob blob2" />

        <div className="wd-hero-inner">
          {/* Location + controls row */}
          <div className="wd-top-bar">
            <div className="wd-location-pill">
              <MapPin size={14} />
              <span>{locName}</span>
            </div>
            <div className="wd-controls">
              <button
                className="wd-unit-toggle"
                onClick={() => setUnit(u => u === 'C' ? 'F' : 'C')}
              >
                °{unit === 'C' ? 'F' : 'C'}
              </button>
              <button
                className="wd-refresh-btn"
                onClick={() => coords && fetchWeather(coords.lat, coords.lon)}
                title="Refresh"
              >
                <RefreshCw size={14} />
              </button>
            </div>
          </div>

          {/* Main temp display */}
          <div className="wd-main-temp">
            <CondIcon size={80} strokeWidth={1.2} className="wd-cond-icon" />
            <div>
              <div className="wd-temp-big">{displayTemp(cur.temperature_2m)}</div>
              <div className="wd-condition-label">{condition}</div>
              <div className="wd-feels-like">
                Feels like {displayTemp(cur.apparent_temperature)}
              </div>
            </div>
          </div>

          {/* Quick stats */}
          <div className="wd-quick-stats">
            <StatBadge icon={<Droplets size={16} />} label="Humidity"   value={`${cur.relative_humidity_2m}%`} />
            <StatBadge icon={<Wind size={16} />}     label="Wind"       value={`${Math.round(cur.wind_speed_10m)} km/h`} />
            <StatBadge icon={<Gauge size={16} />}    label="Pressure"   value={`${Math.round(cur.surface_pressure)} hPa`} />
            <StatBadge icon={<Umbrella size={16} />} label="Precip."    value={`${cur.precipitation} mm`} />
          </div>
        </div>
      </div>

      {/* ===== Content Below Hero ===== */}
      <div className="wd-body">

        {/* ---- Detail Cards Row ---- */}
        <div className="wd-cards-grid">
          <DetailCard icon={<Eye size={22} />} title="Visibility">
            <span className="wd-detail-value">{cur.visibility ? (cur.visibility / 1000).toFixed(1) : '—'} <small>km</small></span>
          </DetailCard>

          <DetailCard icon={<Sun size={22} style={{ color: uvColor }} />} title="UV Index">
            <span className="wd-detail-value" style={{ color: uvColor }}>{uvMax ?? '—'}</span>
            <span className="wd-detail-sub">{uvLabel}</span>
          </DetailCard>

          <DetailCard icon={<Sunrise size={22} style={{ color: '#f59e0b' }} />} title="Sunrise">
            <span className="wd-detail-value">{fmt(sunriseRaw)}</span>
          </DetailCard>

          <DetailCard icon={<Sunset size={22} style={{ color: '#f97316' }} />} title="Sunset">
            <span className="wd-detail-value">{fmt(sunsetRaw)}</span>
          </DetailCard>

          <DetailCard icon={<Thermometer size={22} />} title="Today Hi / Lo">
            <span className="wd-detail-value">
              {displayTemp(daily?.temperature_2m_max?.[0] ?? 0)}
              <span style={{ color:'#94a3b8', margin:'0 4px' }}>/</span>
              {displayTemp(daily?.temperature_2m_min?.[0] ?? 0)}
            </span>
          </DetailCard>

          <DetailCard icon={<CloudRain size={22} />} title="Daily Precip.">
            <span className="wd-detail-value">{daily?.precipitation_sum?.[0] ?? 0} <small>mm</small></span>
          </DetailCard>
        </div>

        {/* ---- 7-Day Forecast ---- */}
        <section className="wd-section">
          <h2 className="wd-section-title">7-Day Forecast</h2>
          <div className="wd-forecast-row">
            {daily?.time?.map((dateStr, i) => {
              const d    = new Date(dateStr);
              const name = i === 0 ? 'Today' : DAY_NAMES[d.getDay()];
              const { label: fl, Icon: FIcon } = interpretWMO(daily.weather_code[i]);
              const max  = daily.temperature_2m_max[i];
              const min  = daily.temperature_2m_min[i];
              const prec = daily.precipitation_sum[i];
              return (
                <div key={dateStr} className={`wd-forecast-card ${i === 0 ? 'wd-forecast-today' : ''}`}>
                  <span className="wd-fc-day">{name}</span>
                  <FIcon size={26} className="wd-fc-icon" />
                  <span className="wd-fc-cond">{fl}</span>
                  <div className="wd-fc-temps">
                    <span className="wd-fc-hi">{displayTemp(max)}</span>
                    <span className="wd-fc-lo">{displayTemp(min)}</span>
                  </div>
                  {prec > 0 && (
                    <div className="wd-fc-prec">
                      <Droplets size={10} /> {prec}mm
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ---- AI Farming Advisor ---- */}
        <section className="wd-section">
          <h2 className="wd-section-title">
            <Leaf size={20} style={{ color:'#16a34a' }} /> AI Farming Advisor
          </h2>
          <div className="wd-tip-card">
            <div className="wd-tip-icon-wrap">
              <Leaf size={28} />
            </div>
            <div className="wd-tip-body">
              <p className="wd-tip-label">Smart Farming Tip for Today</p>
              <p className="wd-tip-text">"{tip}"</p>
              <button
                className="wd-tts-btn"
                onClick={() => speak(tip)}
              >
                <Volume2 size={14} /> Listen
              </button>
            </div>
          </div>
        </section>

        {/* ---- Wind Compass ---- */}
        <section className="wd-section">
          <h2 className="wd-section-title">
            <Wind size={20} /> Wind Details
          </h2>
          <div className="wd-wind-card">
            <div className="wd-compass">
              <div
                className="wd-compass-arrow"
                style={{ transform: `rotate(${cur.wind_direction_10m ?? 0}deg)` }}
              />
              <span className="wd-compass-n">N</span>
              <span className="wd-compass-s">S</span>
              <span className="wd-compass-e">E</span>
              <span className="wd-compass-w">W</span>
            </div>
            <div className="wd-wind-info">
              <div className="wd-wind-speed">{Math.round(cur.wind_speed_10m)} <small>km/h</small></div>
              <div className="wd-wind-dir-lbl">Direction: {cur.wind_direction_10m ?? 0}°</div>
            </div>
          </div>
        </section>

      </div>

      {/* ===== Inline Styles (scoped) ===== */}
      <style>{`
        /* ---- Root ---- */
        .wd-root {
          min-height: 100vh;
          background: #f0f4f8;
          font-family: 'Inter', sans-serif;
        }

        /* ---- Loading ---- */
        .weather-loading {
          display: flex; flex-direction: column; align-items: center;
          justify-content: center; min-height: 60vh; gap: 16px;
          color: #64748b; font-weight: 500;
        }
        .weather-loader-ring {
          width: 52px; height: 52px; border-radius: 50%;
          border: 4px solid #e2e8f0;
          border-top-color: #16a34a;
          animation: spin 0.9s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* ---- Error ---- */
        .weather-error-box {
          display: flex; flex-direction: column; align-items: center;
          justify-content: center; min-height: 50vh; gap: 8px; text-align: center;
        }
        .weather-retry-btn {
          display: flex; align-items: center; gap: 6px;
          padding: 8px 20px; border-radius: 999px;
          background: #16a34a; color: #fff; border: none;
          font-weight: 600; cursor: pointer; margin-top: 8px;
        }

        /* ---- Hero ---- */
        .wd-hero {
          position: relative; overflow: hidden;
          padding: 40px 24px 56px;
          color: #fff;
        }
        .wd-blob {
          position: absolute; border-radius: 50%;
          background: rgba(255,255,255,0.08);
          animation: float 8s ease-in-out infinite;
          pointer-events: none;
        }
        .blob1 { width: 300px; height: 300px; top: -80px; right: -60px; animation-delay: 0s; }
        .blob2 { width: 200px; height: 200px; bottom: -60px; left: -40px; animation-delay: 3s; }
        @keyframes float {
          0%,100% { transform: translateY(0); }
          50%      { transform: translateY(-18px); }
        }
        .wd-hero-inner { max-width: 960px; margin: 0 auto; position: relative; z-index: 2; }

        /* ---- Top Bar ---- */
        .wd-top-bar {
          display: flex; align-items: center; justify-content: space-between;
          margin-bottom: 36px;
        }
        .wd-location-pill {
          display: flex; align-items: center; gap: 6px;
          background: rgba(255,255,255,0.2); backdrop-filter: blur(8px);
          border: 1px solid rgba(255,255,255,0.3);
          padding: 6px 14px; border-radius: 999px; font-size: 14px; font-weight: 500;
        }
        .wd-controls { display: flex; align-items: center; gap: 8px; }
        .wd-unit-toggle, .wd-refresh-btn {
          display: flex; align-items: center; gap: 4px;
          background: rgba(255,255,255,0.2); backdrop-filter: blur(8px);
          border: 1px solid rgba(255,255,255,0.3);
          color: #fff; padding: 6px 14px; border-radius: 999px;
          cursor: pointer; font-size: 14px; font-weight: 600; transition: background 0.2s;
        }
        .wd-unit-toggle:hover, .wd-refresh-btn:hover { background: rgba(255,255,255,0.3); }

        /* ---- Main temp display ---- */
        .wd-main-temp {
          display: flex; align-items: center; gap: 32px;
          margin-bottom: 40px; flex-wrap: wrap;
        }
        .wd-cond-icon { opacity: 0.92; flex-shrink: 0; }
        .wd-temp-big {
          font-size: clamp(64px, 12vw, 100px); font-weight: 800;
          line-height: 1; letter-spacing: -4px;
        }
        .wd-condition-label { font-size: 24px; font-weight: 600; margin-top: 4px; opacity: 0.9; }
        .wd-feels-like { font-size: 15px; opacity: 0.75; margin-top: 4px; }

        /* ---- Quick Stats ---- */
        .wd-quick-stats {
          display: flex; gap: 12px; flex-wrap: wrap;
        }
        .wd-stat-badge {
          display: flex; align-items: center; gap: 8px;
          background: rgba(255,255,255,0.18); backdrop-filter: blur(10px);
          border: 1px solid rgba(255,255,255,0.25); border-radius: 16px;
          padding: 10px 16px; font-size: 14px; font-weight: 500;
          transition: background 0.2s;
        }
        .wd-stat-badge:hover { background: rgba(255,255,255,0.28); }
        .wd-sb-label { opacity: 0.75; margin-right: 4px; }
        .wd-sb-value { font-weight: 700; }

        /* ---- Body ---- */
        .wd-body { max-width: 960px; margin: -24px auto 0; padding: 0 20px 60px; }

        /* ---- Detail cards ---- */
        .wd-cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
          gap: 14px; margin-bottom: 36px;
        }
        .wd-detail-card {
          background: #fff; border-radius: 20px;
          padding: 20px 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.06);
          border: 1px solid #e2e8f0;
          display: flex; flex-direction: column; align-items: center;
          text-align: center; gap: 6px;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .wd-detail-card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); }
        .wd-dc-title { font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        .wd-detail-value { font-size: 22px; font-weight: 700; color: #1e293b; }
        .wd-detail-value small { font-size: 13px; font-weight: 500; color: #64748b; }
        .wd-detail-sub { font-size: 12px; font-weight: 600; }

        /* ---- Section ---- */
        .wd-section { margin-bottom: 40px; }
        .wd-section-title {
          display: flex; align-items: center; gap: 8px;
          font-size: 20px; font-weight: 700; color: #1e293b;
          margin-bottom: 16px;
        }

        /* ---- 7-Day Forecast ---- */
        .wd-forecast-row {
          display: flex; gap: 10px; overflow-x: auto; padding-bottom: 6px;
        }
        .wd-forecast-row::-webkit-scrollbar { height: 4px; }
        .wd-forecast-row::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        .wd-forecast-card {
          display: flex; flex-direction: column; align-items: center; gap: 6px;
          background: #fff; border-radius: 20px; padding: 16px 14px;
          min-width: 110px; flex-shrink: 0;
          box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e2e8f0;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .wd-forecast-card:hover { transform: translateY(-3px); box-shadow: 0 8px 22px rgba(0,0,0,0.1); }
        .wd-forecast-today {
          border-color: #16a34a; background: #f0fdf4;
        }
        .wd-fc-day { font-size: 13px; font-weight: 700; color: #475569; }
        .wd-fc-icon { color: #4b82f0; }
        .wd-forecast-today .wd-fc-icon { color: #16a34a; }
        .wd-fc-cond { font-size: 11px; color: #64748b; text-align: center; }
        .wd-fc-temps { display: flex; gap: 6px; align-items: center; }
        .wd-fc-hi { font-size: 16px; font-weight: 700; color: #1e293b; }
        .wd-fc-lo { font-size: 13px; color: #94a3b8; }
        .wd-fc-prec { display: flex; align-items: center; gap: 3px; font-size: 11px; color: #3b82f6; font-weight: 600; }

        /* ---- AI Tip Card ---- */
        .wd-tip-card {
          display: flex; gap: 20px; align-items: flex-start;
          background: linear-gradient(135deg, #f0fdf4, #dcfce7);
          border: 1px solid #bbf7d0; border-radius: 24px; padding: 28px;
          box-shadow: 0 4px 20px rgba(22,163,74,0.1);
        }
        .wd-tip-icon-wrap {
          background: #16a34a; color: #fff; padding: 14px; border-radius: 16px;
          flex-shrink: 0; box-shadow: 0 4px 12px rgba(22,163,74,0.4);
        }
        .wd-tip-body { flex: 1; }
        .wd-tip-label { font-size: 12px; font-weight: 700; color: #16a34a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .wd-tip-text { font-size: 16px; color: #14532d; font-weight: 500; line-height: 1.6; margin-bottom: 16px; }
        .wd-tts-btn {
          display: inline-flex; align-items: center; gap: 6px;
          background: #16a34a; color: #fff; border: none;
          padding: 8px 18px; border-radius: 999px; font-size: 13px; font-weight: 600;
          cursor: pointer; transition: background 0.2s, transform 0.1s;
        }
        .wd-tts-btn:hover { background: #15803d; transform: scale(1.03); }

        /* ---- Wind Card ---- */
        .wd-wind-card {
          background: #fff; border-radius: 24px; padding: 28px;
          border: 1px solid #e2e8f0; box-shadow: 0 2px 12px rgba(0,0,0,0.06);
          display: flex; align-items: center; gap: 36px; flex-wrap: wrap;
        }
        .wd-compass {
          position: relative; width: 100px; height: 100px;
          border: 3px solid #e2e8f0; border-radius: 50%;
          background: #f8fafc; flex-shrink: 0;
        }
        .wd-compass-arrow {
          position: absolute; top: 50%; left: 50%;
          width: 4px; height: 40px;
          background: linear-gradient(to bottom, #ef4444 50%, #94a3b8 50%);
          border-radius: 2px;
          transform-origin: 50% 100%;
          transform: translateX(-50%) translateY(-100%) rotate(0deg);
          transition: transform 1s ease;
        }
        .wd-compass-n, .wd-compass-s, .wd-compass-e, .wd-compass-w {
          position: absolute; font-size: 11px; font-weight: 700; color: #475569;
        }
        .wd-compass-n { top: 2px; left: 50%; transform: translateX(-50%); }
        .wd-compass-s { bottom: 2px; left: 50%; transform: translateX(-50%); }
        .wd-compass-e { right: 4px; top: 50%; transform: translateY(-50%); }
        .wd-compass-w { left: 4px; top: 50%; transform: translateY(-50%); }
        .wd-wind-speed { font-size: 48px; font-weight: 800; color: #1e293b; line-height: 1; }
        .wd-wind-speed small { font-size: 20px; font-weight: 500; color: #64748b; }
        .wd-wind-dir-lbl { font-size: 14px; color: #64748b; margin-top: 6px; }
      `}</style>
    </div>
  );
}

/* ====================== Sub-components ====================== */
function StatBadge({ icon, label, value }) {
  return (
    <div className="wd-stat-badge">
      {icon}
      <span className="wd-sb-label">{label}</span>
      <span className="wd-sb-value">{value}</span>
    </div>
  );
}

function DetailCard({ icon, title, children }) {
  return (
    <div className="wd-detail-card">
      <div style={{ color: '#4b82f0' }}>{icon}</div>
      <div className="wd-dc-title">{title}</div>
      {children}
    </div>
  );
}
