import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection, addDoc, query, where, orderBy, getDocs, serverTimestamp
} from 'firebase/firestore';
import {
  Calendar, Droplets, Leaf, Bug, Scissors, Sun, Clock,
  ChevronDown, ChevronUp, Volume2, PlusCircle, History, Loader
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

/* ============================================================
   CROP DATABASE — rule-based schedule generation
   ============================================================ */
const CROP_DB = {
  rice:    { name:'Rice (Paddy)',    season:120, icon:'🌾' },
  wheat:   { name:'Wheat',          season:120, icon:'🌾' },
  cotton:  { name:'Cotton',         season:150, icon:'🌿' },
  tomato:  { name:'Tomato',         season:90,  icon:'🍅' },
  chilli:  { name:'Chilli',         season:120, icon:'🌶️' },
  maize:   { name:'Maize/Corn',     season:100, icon:'🌽' },
  soybean: { name:'Soybean',        season:100, icon:'🫘' },
  sugarcane:{ name:'Sugarcane',     season:360, icon:'🎋' },
  onion:   { name:'Onion',          season:120, icon:'🧅' },
  groundnut:{ name:'Groundnut',     season:110, icon:'🥜' },
};

function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

function generateSchedule(cropKey, sowingDate) {
  const crop = CROP_DB[cropKey];
  if (!crop || !sowingDate) return [];

  const schedules = {
    rice: [
      { phase:'Soil Preparation',    daysFromSow:-14, icon:'🌱', color:'#78350f', bg:'#fef3c7',
        tasks:['Deep plough 3–4 weeks before sowing','Add 10 tons/acre farmyard manure','Level field for uniform water distribution','Check and repair bunds to hold water'] },
      { phase:'Nursery & Sowing',     daysFromSow:0,   icon:'🌾', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Soak seeds in water 24 hrs before sowing','Sow in nursery @ 30 kg seed/acre','Maintain nursery waterlogging 2 cm','Apply carbendazim seed treatment'] },
      { phase:'Transplanting',        daysFromSow:25,  icon:'🔄', color:'#0284c7', bg:'#f0f9ff',
        tasks:['Transplant 25-day-old seedlings','Spacing: 20×15 cm','Maintain 2–3 cm water depth after transplanting','Apply basal fertiliser: N 25kg + P 40kg + K 40kg/acre'] },
      { phase:'Irrigation Phase',     daysFromSow:40,  icon:'💧', color:'#0369a1', bg:'#e0f2fe',
        tasks:['Maintain 5 cm water depth during tillering','Drain field before panicle initiation','Apply split doses of nitrogen (40 kg/acre at 30 & 55 days)','Ensure no water stress during flowering'] },
      { phase:'Fertiliser & Pest',    daysFromSow:55,  icon:'🧪', color:'#7c3aed', bg:'#f5f3ff',
        tasks:['Top dress urea 15 kg/acre at panicle initiation','Monitor for Brown Plant Hopper — spray Buprofezin if needed','Spray fungicide for blast (Tricyclazole 0.6 g/L) if noticed','Control weeds at 20–25 days after transplanting'] },
      { phase:'Grain Filling',        daysFromSow:80,  icon:'🌾', color:'#ca8a04', bg:'#fefce8',
        tasks:['Maintain shallow water (2 cm) during grain filling','Avoid N top-dress after flowering','Monitor for Sheath Blight','Keep birds away during ripening'] },
      { phase:'Harvest',              daysFromSow:110, icon:'✂️', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Drain field 10 days before harvest','Harvest when 80% grains are golden-yellow','Thresh within 2 days to prevent quality loss','Dry grain to 14% moisture before storage'] },
    ],
    wheat: [
      { phase:'Soil Preparation',    daysFromSow:-10, icon:'🌱', color:'#78350f', bg:'#fef3c7',
        tasks:['Fine tillage for good seedbed','Apply 10 t/ha FYM and incorporate','Ensure pH between 6.5–7.5','Planking to conserve moisture'] },
      { phase:'Sowing',              daysFromSow:0,   icon:'🌾', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Sow treated seeds @ 100 kg/ha','Row spacing: 22.5 cm','Drill sow to 5–6 cm depth','Basal dose: N 60 + P 60 + K 40 kg/ha'] },
      { phase:'Crown Root Irrigation',daysFromSow:21, icon:'💧', color:'#0284c7', bg:'#f0f9ff',
        tasks:['First critical irrigation at CRI stage (21 DAS)','Light irrigation to avoid waterlogging','Apply 1st N split: 60 kg urea/ha'] },
      { phase:'Tillering',           daysFromSow:45,  icon:'🌿', color:'#15803d', bg:'#f0fdf4',
        tasks:['Irrigation at tillering (45 DAS)','Apply 2nd N split','Control narrow-leaf weeds with Isoproturon','Monitor for Yellow Rust'] },
      { phase:'Jointing & Booting', daysFromSow:65,  icon:'🌾', color:'#ca8a04', bg:'#fefce8',
        tasks:['Irrigation at jointing and booting stages','Spray Propiconazole for Rust if >5% incidence','Apply micro-nutrient foliar spray (Zinc 0.5%)'] },
      { phase:'Harvest',             daysFromSow:115, icon:'✂️', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Stop irrigation 3 weeks before harvest','Harvest mechanically at dough stage','Target grain moisture <14%','Store in dry, ventilated bins'] },
    ],
    tomato: [
      { phase:'Nursery',            daysFromSow:-30, icon:'🌱', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Sow in sterilised pro-trays','Use cocopeat + perlite mix','Spray copper hydroxide at cotyledon stage','Harden seedlings before transplant'] },
      { phase:'Transplanting',      daysFromSow:0,   icon:'🍅', color:'#dc2626', bg:'#fef2f2',
        tasks:['Transplant 30-day seedlings in evening','Spacing: 60×45 cm','Apply 25 t/ha FYM + Basal fertiliser','Drip irrigation preferred'] },
      { phase:'Vegetative Growth',  daysFromSow:20,  icon:'🌿', color:'#15803d', bg:'#f0fdf4',
        tasks:['Install stake/trellis support','Sucker removal at 4–6 leaf stage','Drip every 2 days; adjust for season','Apply water-soluble fertiliser weekly'] },
      { phase:'Flowering',          daysFromSow:45,  icon:'🌸', color:'#db2777', bg:'#fdf2f8',
        tasks:['Ensure adequate Calcium + Boron for fruit set','Spray Imidacloprid for thrips control','Avoid water stress — critical for fruit set','Apply potassium 60 kg/ha'] },
      { phase:'Fruiting',           daysFromSow:65,  icon:'🍅', color:'#f97316', bg:'#fff7ed',
        tasks:['Monitor for early/late blight — spray Mancozeb','Spray neem oil for whitefly','Increase drip intervals slightly','Apply foliar potassium 1% for colour'] },
      { phase:'Harvest',            daysFromSow:80,  icon:'✂️', color:'#16a34a', bg:'#f0fdf4',
        tasks:['Harvest at pink to red stage for market','Early morning harvest preferred','Grading: Grade A (>70mm), B (55–70mm)','Cold storage at 12°C if not sold immediately'] },
    ],
  };

  // Default fallback for unlisted crops
  const fallback = [
    { phase:'Land Preparation', daysFromSow:-10, icon:'🌱', color:'#78350f', bg:'#fef3c7',
      tasks:['Deep till the field and remove weeds','Add organic compost','Ensure proper drainage','Check soil pH 6.0–7.0'] },
    { phase:'Sowing',           daysFromSow:0,   icon:'🌾', color:'#16a34a', bg:'#f0fdf4',
      tasks:['Sow treated seeds at recommended spacing','Apply basal NPK dose','Ensure adequate soil moisture at sowing'] },
    { phase:'Irrigation',       daysFromSow:20,  icon:'💧', color:'#0284c7', bg:'#f0f9ff',
      tasks:['First light irrigation 5–7 days after sowing','Avoid waterlogging','Monitor soil moisture regularly'] },
    { phase:'Fertiliser Top-Dress',daysFromSow:40,icon:'🧪',color:'#7c3aed',bg:'#f5f3ff',
      tasks:['Apply top-dress nitrogen','Spray micronutrients if deficiency visible','Control pests and diseases'] },
    { phase:'Pre-Harvest',      daysFromSow: crop.season - 15, icon:'🌾', color:'#ca8a04', bg:'#fefce8',
      tasks:['Stop irrigation 2 weeks before harvest','Monitor for final pest incidence','Arrange harvesting equipment'] },
    { phase:'Harvest',          daysFromSow: crop.season, icon:'✂️', color:'#16a34a', bg:'#f0fdf4',
      tasks:['Harvest at maturity','Dry and store properly','Market or store at optimal moisture'] },
  ];

  const phases = schedules[cropKey] || fallback;
  return phases.map(p => ({
    ...p,
    date: addDays(sowingDate, p.daysFromSow),
    dueDateRaw: new Date(sowingDate).getTime() + p.daysFromSow * 86400000,
  })).sort((a,b) => a.dueDateRaw - b.dueDateRaw);
}

function buildGrowthCurve(crop, sowDate) {
  if (!crop || !sowDate) return [];
  const s = crop.season;
  return [0, 0.1, 0.2, 0.35, 0.5, 0.65, 0.78, 0.88, 0.95, 1.0].map((pct, i) => ({
    day:    Math.round(pct * s),
    growth: Math.round(pct * 100),
    date:   addDays(sowDate, Math.round(pct * s)),
  }));
}

const LANGS = {
  en: { planner:'Crop Schedule Planner', selectCrop:'Select Crop', sowDate:'Sowing Date',
        generate:'Generate Schedule', history:'My Saved Schedules', save:'Save to Cloud',
        saved:'Schedule saved!', phase:'Phase', date:'Date', tasks:'Tasks' },
  hi: { planner:'फसल कार्यक्रम योजनाकार', selectCrop:'फसल चुनें', sowDate:'बुवाई तिथि',
        generate:'कार्यक्रम बनाएं', history:'मेरे सहेजे गए कार्यक्रम', save:'क्लाउड में सहेजें',
        saved:'सहेजा गया!', phase:'चरण', date:'तारीख', tasks:'कार्य' },
  te: { planner:'పంట షెడ్యూల్ ప్లానర్', selectCrop:'పంటను ఎంచుకోండి', sowDate:'విత్తన తేదీ',
        generate:'షెడ్యూల్ రూపొందించండి', history:'నా సేవ్ చేసిన షెడ్యూల్‌లు', save:'క్లౌడ్‌లో సేవ్ చేయండి',
        saved:'సేవ్ చేయబడింది!', phase:'దశ', date:'తేదీ', tasks:'పనులు' },
};

export default function CropPlanner() {
  const [cropKey, setCropKey]     = useState('');
  const [sowDate, setSowDate]     = useState('');
  const [schedule, setSchedule]   = useState([]);
  const [loading, setLoading]     = useState(false);
  const [saved, setSaved]         = useState(false);
  const [history, setHistory]     = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [expanded, setExpanded]   = useState({});
  const [lang, setLang]           = useState('en');
  const [user] = useState(null); // For demo, no auth guard here
  const T = LANGS[lang];

  const handleGenerate = async () => {
    if (!cropKey || !sowDate) return;
    setLoading(true);
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/crop_schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ crop: cropKey, sowing_date: sowDate, lang }),
      });
      if (res.ok) {
        const data = await res.json();
        // The backend returns a slightly different format (tasks as simple list)
        // We'll map it to the frontend's expected format with icons etc.
        const mapped = data.phases.map((p, i) => ({
          phase: p.phase,
          date: p.date,
          daysFromSow: p.day_offset,
          tasks: p.tasks,
          icon: i === 0 ? '🌱' : i === data.phases.length - 1 ? '✂️' : '🌿',
          color: i === 0 ? '#78350f' : i === data.phases.length -1 ? '#16a34a' : '#0284c7',
          bg: i === 0 ? '#fef3c7' : i === data.phases.length -1 ? '#f0fdf4' : '#f0f9ff',
          dueDateRaw: new Date(sowDate).getTime() + p.day_offset * 86400000,
        }));
        setSchedule(mapped);
      } else {
        setSchedule(generateSchedule(cropKey, sowDate));
      }
    } catch (e) {
      console.warn("Backend planner offline, falling back to local generator", e);
      setSchedule(generateSchedule(cropKey, sowDate));
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!schedule.length) return;
    try {
      await addDoc(collection(db, 'cropSchedules'), {
        crop: cropKey,
        cropName: CROP_DB[cropKey]?.name || cropKey,
        sowingDate: sowDate,
        schedule,
        lang,
        createdAt: serverTimestamp(),
        userId: 'demo_user',
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e) { console.error(e); }
  };

  const loadHistory = async () => {
    setShowHistory(s => !s);
    if (!showHistory) {
      try {
        const q = query(
          collection(db, 'cropSchedules'),
          where('userId', '==', 'demo_user'),
          orderBy('createdAt', 'desc')
        );
        const snap = await getDocs(q);
        setHistory(snap.docs.map(d => ({ id:d.id, ...d.data() })));
      } catch (e) { console.error(e); setHistory([]); }
    }
  };

  const speak = (text) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'hi' ? 'hi-IN' : lang === 'te' ? 'te-IN' : 'en-IN';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  const growthCurve = buildGrowthCurve(CROP_DB[cropKey], sowDate);
  const crop = CROP_DB[cropKey];
  const today = new Date().toISOString().split('T')[0];

  // Find the next upcoming phase
  const nextPhase = schedule.find(p => p.dueDateRaw >= Date.now());

  return (
    <div className="cp-root">
      {/* ===== Header ===== */}
      <div className="cp-header">
        <div className="cp-header-inner">
          <div className="cp-header-left">
            <div className="cp-lang-row">
              {['en','hi','te'].map(l => (
                <button key={l} className={`cp-lang-btn ${lang===l?'cp-lang-active':''}`}
                  onClick={() => setLang(l)}>
                  {l==='en'?'EN':l==='hi'?'हि':'తె'}
                </button>
              ))}
            </div>
            <h1 className="cp-title">{T.planner}</h1>
            <p className="cp-subtitle">AI-generated growth plans for Indian crops — sowing to harvest</p>
          </div>
          <div className="cp-header-right">
            <select className="cp-select" value={cropKey} onChange={e=>setCropKey(e.target.value)}>
              <option value="">{T.selectCrop}…</option>
              {Object.entries(CROP_DB).map(([k,v]) => (
                <option key={k} value={k}>{v.icon} {v.name}</option>
              ))}
            </select>
            <input className="cp-date-input" type="date" max={today}
              value={sowDate} onChange={e=>setSowDate(e.target.value)}
              placeholder={T.sowDate} />
            <button className="cp-generate-btn" onClick={handleGenerate}
              disabled={!cropKey || !sowDate || loading}>
              {loading ? <><Loader size={16} className="cp-spin"/> Generating…</>
                       : <><PlusCircle size={16}/> {T.generate}</>}
            </button>
          </div>
        </div>
      </div>

      <div className="cp-body">

        {/* ===== Empty state ===== */}
        {!schedule.length && !loading && (
          <div className="cp-empty">
            <div className="cp-empty-icon">🌾</div>
            <h3>Select a crop and sowing date to generate your complete farming schedule</h3>
            <p>Get soil prep, irrigation, fertiliser, pest management, and harvest timelines — all in one place.</p>
          </div>
        )}

        {/* ===== Schedule ===== */}
        {schedule.length > 0 && (
          <>
            {/* Crop Summary Card */}
            <div className="cp-summary-card">
              <div className="cp-summary-left">
                <div className="cp-crop-icon">{crop?.icon}</div>
                <div>
                  <div className="cp-crop-name">{crop?.name}</div>
                  <div className="cp-crop-duration">
                    <Clock size={14}/> {crop?.season}-day growing cycle
                  </div>
                  <div className="cp-sow-date">
                    <Calendar size={14}/> Sown: {addDays(sowDate, 0)} → Harvest: ~{addDays(sowDate, crop?.season)}
                  </div>
                </div>
              </div>
              {nextPhase && (
                <div className="cp-next-phase">
                  <div className="cp-next-label">Next upcoming phase</div>
                  <div className="cp-next-name">{nextPhase.icon} {nextPhase.phase}</div>
                  <div className="cp-next-date">{nextPhase.date}</div>
                </div>
              )}
              <div className="cp-summary-actions">
                <button className="cp-save-btn" onClick={handleSave}>
                  {saved ? '✅ Saved!' : <><span>☁️</span> {T.save}</>}
                </button>
                <button className="cp-speak-btn"
                  onClick={() => speak(`Your ${crop?.name} schedule has ${schedule.length} phases. Next phase: ${nextPhase?.phase} on ${nextPhase?.date}.`)}>
                  <Volume2 size={14}/> Listen
                </button>
              </div>
            </div>

            {/* Growth Curve Chart */}
            {growthCurve.length > 0 && (
              <div className="cp-chart-card">
                <h3 className="cp-chart-title"><TrendingUp size={18}/> Expected Growth Curve</h3>
                <ResponsiveContainer width="100%" height={180}>
                  <AreaChart data={growthCurve} margin={{ top:10, right:10, left:-20, bottom:0 }}>
                    <defs>
                      <linearGradient id="growth" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%"  stopColor="#16a34a" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#16a34a" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                    <XAxis dataKey="day" name="Day" tick={{ fontSize:11, fill:'#64748b' }} label={{ value:'Days', position:'insideBottom', offset:-2, fontSize:11 }}/>
                    <YAxis tick={{ fontSize:11, fill:'#64748b' }} unit="%"/>
                    <Tooltip contentStyle={{ borderRadius:12, fontSize:12 }}
                      formatter={(v,_,p) => [`${v}%`, 'Growth']}
                      labelFormatter={v => `Day ${v}`}/>
                    <Area type="monotone" dataKey="growth" stroke="#16a34a" fill="url(#growth)" strokeWidth={2}/>
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Phase Timeline */}
            <div className="cp-timeline">
              {schedule.map((phase, i) => {
                const isExp = expanded[i];
                const isPast = phase.dueDateRaw < Date.now();
                const isNext = nextPhase && phase.phase === nextPhase.phase;
                return (
                  <div key={i} className={`cp-phase-card ${isNext?'cp-phase-next':''} ${isPast?'cp-phase-past':''}`}
                    style={{ borderLeftColor: phase.color }}>
                    <div className="cp-phase-header" onClick={() => setExpanded(e=>({ ...e, [i]:!e[i] }))}>
                      <div className="cp-phase-left">
                        <div className="cp-phase-icon-wrap" style={{ background: phase.bg, color: phase.color }}>
                          <span>{phase.icon}</span>
                        </div>
                        <div>
                          <div className="cp-phase-name" style={{ color: phase.color }}>
                            {T.phase} {i+1}: {phase.phase}
                          </div>
                          <div className="cp-phase-date"><Calendar size={12}/> {phase.date}</div>
                        </div>
                      </div>
                      <div className="cp-phase-right">
                        {isNext && <span className="cp-upcoming-badge">⏰ Upcoming</span>}
                        {isPast && !isNext && <span className="cp-done-badge">✅ Done</span>}
                        <button className="cp-expand-btn">
                          {isExp ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}
                        </button>
                      </div>
                    </div>
                    {isExp && (
                      <div className="cp-phase-tasks">
                        {phase.tasks.map((task, ti) => (
                          <div key={ti} className="cp-task-row">
                            <span className="cp-task-dot" style={{ background: phase.color }}/>
                            <span className="cp-task-text">{task}</span>
                            <button className="cp-task-speak"
                              onClick={() => speak(task)} title="Listen">
                              <Volume2 size={12}/>
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* ===== History ===== */}
        <div className="cp-history-section">
          <button className="cp-history-toggle" onClick={loadHistory}>
            <History size={16}/> {T.history}
            {showHistory ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}
          </button>
          {showHistory && (
            <div className="cp-history-list">
              {history.length === 0
                ? <p style={{ color:'#94a3b8', textAlign:'center', padding:24 }}>No saved schedules yet.</p>
                : history.map(h => (
                    <div key={h.id} className="cp-history-item"
                      onClick={() => { setCropKey(h.crop); setSowDate(h.sowingDate); setSchedule(h.schedule); }}>
                      <span className="cp-history-icon">{CROP_DB[h.crop]?.icon || '🌾'}</span>
                      <div>
                        <div className="cp-history-name">{h.cropName}</div>
                        <div className="cp-history-date">Sown: {h.sowingDate}</div>
                      </div>
                    </div>
                  ))
              }
            </div>
          )}
        </div>
      </div>

      {/* ===== STYLES ===== */}
      <style>{`
        .cp-root { min-height:100vh; background:#f0f4f8; font-family:'Inter',sans-serif; }

        /* Header */
        .cp-header { background:linear-gradient(135deg,#064e3b,#16a34a,#4ade80); color:#fff; padding:40px 24px 56px; }
        .cp-header-inner { max-width:1100px; margin:0 auto; display:flex; gap:24px; flex-wrap:wrap; align-items:flex-end; }
        .cp-header-left { flex:1; min-width:220px; }
        .cp-header-right { flex:1; min-width:280px; display:flex; flex-direction:column; gap:10px; }
        .cp-lang-row { display:flex; gap:8px; margin-bottom:12px; }
        .cp-lang-btn { background:rgba(255,255,255,.2); border:1px solid rgba(255,255,255,.3); color:#fff; padding:4px 12px; border-radius:999px; cursor:pointer; font-weight:600; font-size:13px; }
        .cp-lang-active { background:rgba(255,255,255,.45); }
        .cp-title { font-size:clamp(26px,5vw,40px); font-weight:800; letter-spacing:-1px; }
        .cp-subtitle { opacity:.8; margin-top:4px; font-size:15px; }
        .cp-select, .cp-date-input { width:100%; padding:10px 14px; border-radius:12px; border:1px solid rgba(255,255,255,.35); background:rgba(255,255,255,.15); backdrop-filter:blur(10px); color:#fff; font-size:14px; outline:none; }
        .cp-select option { background:#1e293b; }
        .cp-select::placeholder, .cp-date-input::placeholder { color:rgba(255,255,255,.6); }
        .cp-generate-btn { display:inline-flex; align-items:center; gap:8px; background:#fff; color:#16a34a; border:none; padding:12px 22px; border-radius:12px; font-size:15px; font-weight:700; cursor:pointer; transition:opacity .2s; }
        .cp-generate-btn:disabled { opacity:.5; cursor:not-allowed; }
        .cp-spin { animation:spin .6s linear infinite; }
        @keyframes spin { to { transform:rotate(360deg); } }

        /* Body */
        .cp-body { max-width:1100px; margin:-20px auto 0; padding:0 20px 60px; }

        /* Empty */
        .cp-empty { text-align:center; padding:80px 24px; color:#64748b; }
        .cp-empty-icon { font-size:72px; margin-bottom:16px; }
        .cp-empty h3 { font-size:20px; font-weight:700; color:#1e293b; max-width:500px; margin:0 auto 8px; }
        .cp-empty p { font-size:15px; max-width:400px; margin:0 auto; }

        /* Summary */
        .cp-summary-card { background:#fff; border-radius:24px; padding:24px; border:1px solid #e2e8f0; box-shadow:0 2px 12px rgba(0,0,0,.06); display:flex; gap:20px; flex-wrap:wrap; align-items:center; margin-bottom:20px; }
        .cp-summary-left { display:flex; align-items:center; gap:16px; flex:1; min-width:200px; }
        .cp-crop-icon { font-size:48px; }
        .cp-crop-name { font-size:22px; font-weight:800; color:#1e293b; }
        .cp-crop-duration { display:flex; align-items:center; gap:6px; font-size:13px; color:#64748b; margin-top:4px; }
        .cp-sow-date { display:flex; align-items:center; gap:6px; font-size:13px; color:#64748b; margin-top:2px; }
        .cp-next-phase { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:16px; padding:14px 18px; min-width:160px; }
        .cp-next-label { font-size:11px; font-weight:700; color:#16a34a; text-transform:uppercase; letter-spacing:.5px; }
        .cp-next-name { font-size:15px; font-weight:700; color:#14532d; margin-top:4px; }
        .cp-next-date { font-size:13px; color:#16a34a; margin-top:2px; }
        .cp-summary-actions { display:flex; gap:10px; flex-wrap:wrap; }
        .cp-save-btn { display:inline-flex; align-items:center; gap:6px; background:#16a34a; color:#fff; border:none; padding:10px 18px; border-radius:12px; font-size:14px; font-weight:600; cursor:pointer; }
        .cp-speak-btn { display:inline-flex; align-items:center; gap:6px; background:#f1f5f9; color:#475569; border:1px solid #e2e8f0; padding:10px 18px; border-radius:12px; font-size:14px; cursor:pointer; }

        /* Chart */
        .cp-chart-card { background:#fff; border-radius:20px; padding:20px; border:1px solid #e2e8f0; box-shadow:0 2px 10px rgba(0,0,0,.05); margin-bottom:24px; }
        .cp-chart-title { display:flex; align-items:center; gap:8px; font-size:16px; font-weight:700; color:#1e293b; margin-bottom:14px; }

        /* Timeline */
        .cp-timeline { display:flex; flex-direction:column; gap:12px; margin-bottom:36px; }
        .cp-phase-card { background:#fff; border-radius:18px; border:1px solid #e2e8f0; border-left:5px solid; box-shadow:0 2px 8px rgba(0,0,0,.05); overflow:hidden; transition:box-shadow .2s; }
        .cp-phase-card:hover { box-shadow:0 6px 20px rgba(0,0,0,.1); }
        .cp-phase-next { background:#fefce8; border-color:#fbbf24 !important; }
        .cp-phase-past { opacity:.7; }
        .cp-phase-header { display:flex; align-items:center; justify-content:space-between; padding:16px 18px; cursor:pointer; }
        .cp-phase-left { display:flex; align-items:center; gap:14px; }
        .cp-phase-icon-wrap { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0; }
        .cp-phase-name { font-size:15px; font-weight:700; }
        .cp-phase-date { display:flex; align-items:center; gap:5px; font-size:12px; color:#64748b; margin-top:3px; }
        .cp-phase-right { display:flex; align-items:center; gap:8px; }
        .cp-upcoming-badge { background:#fef3c7; color:#d97706; border:1px solid #fde68a; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; }
        .cp-done-badge { background:#f0fdf4; color:#16a34a; border:1px solid #bbf7d0; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; }
        .cp-expand-btn { background:#f1f5f9; border:none; color:#64748b; width:28px; height:28px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; }
        .cp-phase-tasks { padding:0 18px 16px 76px; display:flex; flex-direction:column; gap:8px; border-top:1px solid #f1f5f9; margin-top:0; padding-top:14px; }
        .cp-task-row { display:flex; align-items:flex-start; gap:10px; }
        .cp-task-dot { width:8px; height:8px; border-radius:50%; flex-shrink:0; margin-top:5px; }
        .cp-task-text { font-size:14px; color:#334155; line-height:1.5; flex:1; }
        .cp-task-speak { background:none; border:none; color:#94a3b8; cursor:pointer; padding:2px; flex-shrink:0; }
        .cp-task-speak:hover { color:#16a34a; }

        /* History */
        .cp-history-section { margin-top:16px; }
        .cp-history-toggle { display:flex; align-items:center; gap:8px; background:#fff; border:1px solid #e2e8f0; color:#475569; padding:12px 20px; border-radius:16px; font-size:14px; font-weight:600; cursor:pointer; width:100%; transition:background .2s; }
        .cp-history-toggle:hover { background:#f8fafc; }
        .cp-history-list { background:#fff; border:1px solid #e2e8f0; border-top:none; border-radius:0 0 16px 16px; padding:8px; }
        .cp-history-item { display:flex; align-items:center; gap:12px; padding:12px 14px; border-radius:12px; cursor:pointer; transition:background .15s; }
        .cp-history-item:hover { background:#f0fdf4; }
        .cp-history-icon { font-size:24px; }
        .cp-history-name { font-size:14px; font-weight:700; color:#1e293b; }
        .cp-history-date { font-size:12px; color:#64748b; }

        /* Reusable */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
      `}</style>
    </div>
  );
}

// Small alias for chart title icon
function TrendingUp({ size, ...props }) {
  return <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>;
}
