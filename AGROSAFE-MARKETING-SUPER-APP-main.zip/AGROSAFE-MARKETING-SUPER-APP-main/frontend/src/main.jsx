import React from 'react'
import ReactDOM from 'react-dom/client'
import './i18n'
import App from './App.jsx'
import './index.css'

class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(e) { return { error: e }; }
  componentDidCatch(error, info) {
    console.error('🔴 ErrorBoundary caught:', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{padding:'40px',fontFamily:'monospace',color:'red',background:'#fff1f0',minHeight:'100vh',overflow:'auto'}}>
          <h2 style={{color:'red'}}>⚠️ AgroSafe Error:</h2>
          <pre style={{whiteSpace:'pre-wrap',background:'#ffd7d7',padding:'16px',borderRadius:'8px'}}>{String(this.state.error)}</pre>
          <pre style={{whiteSpace:'pre-wrap',fontSize:'12px',marginTop:'16px'}}>{this.state.error?.stack}</pre>
        </div>
      );
    }
    return this.props.children;
  }
}

console.log('🟢 main.jsx: About to render App...');

ReactDOM.createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <React.Suspense fallback={
      <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',fontSize:'24px',fontWeight:'bold',fontFamily:'sans-serif',color:'#16a34a'}}>
        🌱 Loading AgroSafe…
      </div>
    }>
      <App />
    </React.Suspense>
  </ErrorBoundary>
)

console.log('🟢 main.jsx: render() dispatched');


