import React, { useState } from 'react';
import { Users, Video, BookOpen, MessageSquare, Award, ChevronRight, PlayCircle, Star, CheckCircle2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function CommunityHub() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('mentorship');

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-purple-900 via-fuchsia-800 to-pink-900 text-white py-16 px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
        <Users className="w-16 h-16 mx-auto mb-6 text-purple-300 opacity-90 relative z-10" />
        <h1 className="text-4xl md:text-5xl font-black mb-4 relative z-10">{t('Agro Community & Learning', 'Agro Community & Learning')}</h1>
        <p className="text-xl text-purple-100 max-w-2xl mx-auto opacity-90 font-medium relative z-10">
          {t('Connect with mentors, attend expert webinars, and upskill with AI learning paths.', 'Connect with mentors, attend expert webinars, and upskill with AI learning paths.')}
        </p>
        
        <div className="flex justify-center gap-4 mt-8 relative z-10">
          <button onClick={() => setActiveTab('mentorship')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'mentorship' ? 'bg-white text-purple-900' : 'bg-purple-900/50 text-white hover:bg-purple-700'}`}>
            {t('Mentorship', 'Mentorship')}
          </button>
          <button onClick={() => setActiveTab('webinars')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'webinars' ? 'bg-white text-purple-900' : 'bg-purple-900/50 text-white hover:bg-purple-700'}`}>
            {t('Live Webinars', 'Live Webinars')}
          </button>
          <button onClick={() => setActiveTab('learning')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'learning' ? 'bg-white text-purple-900' : 'bg-purple-900/50 text-white hover:bg-purple-700'}`}>
            {t('AI Learning Paths', 'AI Learning Paths')}
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {activeTab === 'mentorship' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('Top Regional Mentors', 'Top Regional Mentors')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: 'Ramesh Reddy', expert: 'Organic Cotton', exp: '15 Years', rating: 4.9, img: 'https://source.unsplash.com/100x100/?indian,farmer' },
                { name: 'Sunita Devi', expert: 'Drip Irrigation', exp: '10 Years', rating: 4.8, img: 'https://source.unsplash.com/100x100/?indian,woman,farmer' },
                { name: 'Balram Singh', expert: 'Soil Health', exp: '20 Years', rating: 5.0, img: 'https://source.unsplash.com/100x100/?indian,man,farmer' },
              ].map((mentor, i) => (
                <div key={i} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 text-center hover:shadow-lg transition-shadow">
                  <img src={mentor.img} alt={mentor.name} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-purple-50 object-cover" />
                  <h3 className="text-xl font-bold text-gray-900">{mentor.name}</h3>
                  <p className="text-purple-600 font-bold text-sm mb-2">{mentor.expert} Expert</p>
                  <div className="flex justify-center items-center gap-4 text-sm text-gray-500 mb-6">
                    <span>{mentor.exp} Exp</span>
                    <span className="flex items-center gap-1 text-amber-500 font-bold"><Star className="w-4 h-4 fill-current" /> {mentor.rating}</span>
                  </div>
                  <div className="flex gap-2">
                    <button className="flex-1 bg-purple-600 text-white py-2 rounded-xl font-bold hover:bg-purple-700 transition-colors">{t('Connect', 'Connect')}</button>
                    <button className="p-2 bg-purple-50 text-purple-600 rounded-xl hover:bg-purple-100 transition-colors"><MessageSquare className="w-5 h-5" /></button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-12 bg-purple-50 border border-purple-100 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between">
              <div>
                <h3 className="text-2xl font-black text-purple-900 mb-2">{t('Become a Mentor', 'Become a Mentor')}</h3>
                <p className="text-purple-700 max-w-xl">{t('Share your farming experience with the next generation. Earn community badges and exclusive govt subsidies.', 'Share your farming experience with the next generation. Earn community badges and exclusive govt subsidies.')}</p>
              </div>
              <button className="mt-6 md:mt-0 px-8 py-3 bg-purple-900 text-white rounded-xl font-bold shadow-xl shadow-purple-200">{t('Apply Now', 'Apply Now')}</button>
            </div>
          </div>
        )}

        {activeTab === 'webinars' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('Upcoming Sessions (Regional Languages)', 'Upcoming Sessions (Regional Languages)')}</h2>
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6 hover:shadow-md transition-shadow relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-red-500 text-white text-xs font-black px-4 py-1 rounded-bl-xl z-10 flex items-center gap-1 animate-pulse">{t('LIVE NOW', 'LIVE NOW')}</div>
              <div className="md:w-1/3 bg-gray-200 rounded-2xl relative overflow-hidden shrink-0 min-h-[160px]">
                <img src="https://source.unsplash.com/400x300/?tractor,farm" alt="Webinar" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <PlayCircle className="w-16 h-16 text-white/80" />
                </div>
              </div>
              <div className="flex-1 flex flex-col justify-center">
                <span className="text-xs font-bold text-purple-600 bg-purple-50 px-3 py-1 rounded-full w-max mb-3">{t('Telugu (తెలుగు)', 'Telugu (తెలుగు)')}</span>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Modern Pest Control Techniques for Cotton', 'Modern Pest Control Techniques for Cotton')}</h3>
                <p className="text-gray-500 text-sm mb-4">{t('Join Dr. V. Rao from the Agricultural University as he discusses AI-based pest prediction.', 'Join Dr. V. Rao from the Agricultural University as he discusses AI-based pest prediction.')}</p>
                <div className="flex items-center gap-4 text-sm font-medium">
                  <span className="flex items-center gap-1 text-gray-600"><Users className="w-4 h-4"/> {t('1.2k watching', '1.2k watching')}</span>
                  <button className="px-6 py-2 bg-red-500 text-white rounded-lg font-bold hover:bg-red-600">{t('Join Stream', 'Join Stream')}</button>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6 hover:shadow-md transition-shadow">
              <div className="md:w-1/3 bg-gray-200 rounded-2xl relative overflow-hidden shrink-0 min-h-[160px]">
                <img src="https://source.unsplash.com/400x300/?solar,pump" alt="Webinar" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-center">
                <span className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full w-max mb-3">{t('Hindi (हिंदी)', 'Hindi (हिंदी)')}</span>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Getting Subsidies for Solar Pumps', 'Getting Subsidies for Solar Pumps')}</h3>
                <p className="text-gray-500 text-sm mb-4">{t('Step-by-step guide on filling the PM-KUSUM application form online.', 'Step-by-step guide on filling the PM-KUSUM application form online.')}</p>
                <div className="flex items-center gap-4 text-sm font-medium">
                  <span className="text-gray-600">{t('Tomorrow • 5:00 PM', 'Tomorrow • 5:00 PM')}</span>
                  <button className="px-6 py-2 bg-purple-50 text-purple-700 rounded-lg font-bold hover:bg-purple-100">{t('Remind Me', 'Remind Me')}</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'learning' && (
          <div>
            <div className="flex justify-between items-end mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{t('AI-Curated Learning Paths', 'AI-Curated Learning Paths')}</h2>
                <p className="text-gray-500">{t('Based on your profile, we recommend these step-by-step courses.', 'Based on your profile, we recommend these step-by-step courses.')}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg transition-all group">
                <div className="h-40 bg-gradient-to-r from-emerald-400 to-teal-500 p-6 flex flex-col justify-end">
                  <span className="bg-white/20 text-white backdrop-blur text-xs font-bold px-3 py-1 rounded-full w-max mb-2">{t('Beginner', 'Beginner')}</span>
                  <h3 className="text-2xl font-black text-white">{t('Transition to Organic Farming', 'Transition to Organic Farming')}</h3>
                </div>
                <div className="p-6">
                  <div className="flex justify-between text-sm mb-2"><span className="font-bold text-gray-700">{t('Course Progress', 'Course Progress')}</span><span className="text-emerald-600 font-black">{t('40%', '40%')}</span></div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mb-6"><div className="bg-emerald-500 h-2 rounded-full" style={{width: '40%'}}></div></div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-3 text-sm text-gray-600 font-medium"><CheckCircle2 className="w-5 h-5 text-emerald-500"/> {t('Module 1: Soil Preparation (Completed)', 'Module 1: Soil Preparation (Completed)')}</li>
                    <li className="flex items-center gap-3 text-sm text-gray-900 font-bold"><PlayCircle className="w-5 h-5 text-purple-600"/> {t('Module 2: Natural Fertilizers (Current)', 'Module 2: Natural Fertilizers (Current)')}</li>
                    <li className="flex items-center gap-3 text-sm text-gray-400 font-medium"><BookOpen className="w-5 h-5"/> {t('Module 3: Pest Management', 'Module 3: Pest Management')}</li>
                  </ul>
                  <button className="w-full py-3 bg-emerald-50 text-emerald-700 rounded-xl font-bold hover:bg-emerald-100 transition-colors">{t('Continue Learning', 'Continue Learning')}</button>
                </div>
              </div>

              <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg transition-all group">
                <div className="h-40 bg-gradient-to-r from-blue-500 to-indigo-600 p-6 flex flex-col justify-end">
                  <span className="bg-white/20 text-white backdrop-blur text-xs font-bold px-3 py-1 rounded-full w-max mb-2">{t('Advanced', 'Advanced')}</span>
                  <h3 className="text-2xl font-black text-white">{t('Exporting Crops Internationally', 'Exporting Crops Internationally')}</h3>
                </div>
                <div className="p-6">
                  <div className="flex justify-between text-sm mb-2"><span className="font-bold text-gray-700">{t('Course Progress', 'Course Progress')}</span><span className="text-blue-600 font-black">{t('0%', '0%')}</span></div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mb-6"><div className="bg-blue-500 h-2 rounded-full" style={{width: '0%'}}></div></div>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-3 text-sm text-gray-900 font-bold"><PlayCircle className="w-5 h-5 text-purple-600"/> {t('Module 1: Global Quality Standards', 'Module 1: Global Quality Standards')}</li>
                    <li className="flex items-center gap-3 text-sm text-gray-400 font-medium"><BookOpen className="w-5 h-5"/> {t('Module 2: Certifications Needed', 'Module 2: Certifications Needed')}</li>
                    <li className="flex items-center gap-3 text-sm text-gray-400 font-medium"><BookOpen className="w-5 h-5"/> {t('Module 3: Finding Buyers', 'Module 3: Finding Buyers')}</li>
                  </ul>
                  <button className="w-full py-3 bg-blue-50 text-blue-700 rounded-xl font-bold hover:bg-blue-100 transition-colors">{t('Start Course', 'Start Course')}</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
