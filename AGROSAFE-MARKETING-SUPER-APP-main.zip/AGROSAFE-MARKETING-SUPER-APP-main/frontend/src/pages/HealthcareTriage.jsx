import React, { useState, useRef, useEffect } from 'react';
import { HeartPulse, Send, Mic, AlertCircle, Bot, User, Phone, Info, CheckCircle2, Navigation, Sparkles, ShieldAlert, Siren, Pill, Camera, Flame, Dumbbell, Users } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function HealthcareTriage() {
  const { t, i18n } = useTranslation();
  const [messages, setMessages] = useState([
    { id: 1, text: t('healthcare.welcome', "Healthcare Navigator Active. Describe your symptoms for AI diagnosis, or use the SOS button for critical emergencies."), sender: 'bot' }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [diagnosisState, setDiagnosisState] = useState(null);
  const [location, setLocation] = useState(null);
  const [activeTab, setActiveTab] = useState('triage');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
        (err) => console.warn("Location permission denied. SOS will use default/manual location.")
      );
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e) => {
    if (e) e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { id: Date.now(), text: input, sender: 'user' };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const response = await fetch("http://localhost:8000/api/healthcare_triage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symptoms: userMsg.text, lang: i18n.language })
      });
      const data = await response.json();
      
      const triage = data.triage || {};
      const cond = triage.cond || "Medical Condition Assessed";
      const rec = triage.rec || "Seek medical attention.";
      const level = triage.level || "Moderate";
      const warn = triage.warning || "AI Guidance only - consult a doctor.";
      
      let meds = ["General Care", "Hydration"];
      if (level === "Emergency") {
         meds = ["DO NOT SELF-MEDICATE", "Follow paramedic instructions"];
      }

      const botMsg = {
        id: Date.now(),
        text: `**${cond}**\n\n${rec}`,
        meta: level,
        medCategories: meds,
        warning: warn,
        sender: 'bot'
      };
      
      setDiagnosisState({ cond, rec, level, meds });
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.warn("API Error:", err);
      // Fallback
      const botMsg = { id: Date.now(), text: "Error connecting to AI triage. Please visit a local clinic.", sender: 'bot', meta: "Moderate" };
      setMessages(prev => [...prev, botMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const triggerSOS = () => {
    const confirmSOS = window.confirm(t('healthcare.sos_confirm', "⚠️ ARE YOU IN AN EMERGENCY? This will broadcast your location to the nearest hospitals and RMP doctors immediately."));
    if (!confirmSOS) return;

    if (navigator.vibrate) navigator.vibrate([100, 30, 100, 30, 100]);

    alert(t('healthcare.sos_success_prefix', `🚨 EMERGENCY SOS BROADCAST SUCCESSFUL! \n\nLocation: [${location?.lat || 17.385}, ${location?.lon || 78.4867}] \nAlert sent to Telemedicine Hub and 3 nearby hospitals. Help is on the way.`));
    window.location.href = 'tel:108';
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans">
      {/* Header & SOS Dashboard */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-40 px-4 md:px-8 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-5">
            <div className="relative">
              <div className="bg-rose-100 p-4 rounded-3xl">
                <HeartPulse className="h-9 w-9 text-rose-600" />
              </div>
              <div className="absolute -bottom-1 -right-1 bg-green-500 w-4 h-4 rounded-full border-4 border-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('healthcare.title', 'AI Healthcare Module')}</h1>
              <div className="flex items-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">
                <Sparkles className="w-3 h-3 text-rose-500" /> {t('healthcare.subtitle', 'Automated Triage System')}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <button 
              onClick={() => window.open('https://www.google.com/maps/search/hospital+near+me', '_blank')}
              className="flex-1 md:flex-none px-6 py-4 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-2xl transition-all flex items-center justify-center gap-2 border border-slate-200 shadow-sm"
            >
              <Navigation className="w-5 h-5 text-blue-500" /> {t('healthcare.find_hospital', 'Find Hospital')}
            </button>
            <button 
              onClick={triggerSOS}
              className="flex-1 md:flex-none px-10 py-4 bg-red-600 hover:bg-red-700 text-white font-black rounded-2xl shadow-xl shadow-red-200 transition-all active:scale-95 flex items-center justify-center gap-3 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              <Siren className="w-6 h-6 animate-ping" /> {t('healthcare.sos_btn', 'SOS EMERGENCY')}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-6">
        <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar">
          {[
            { id: 'triage', icon: <Bot className="w-5 h-5" />, label: 'AI Triage & Mental Health' },
            { id: 'crime', icon: <ShieldAlert className="w-5 h-5" />, label: 'Crime Reporting' },
            { id: 'sensors', icon: <Flame className="w-5 h-5" />, label: 'LPG Gas Monitor' },
            { id: 'forum', icon: <Users className="w-5 h-5" />, label: 'Community Forum' },
            { id: 'fitness', icon: <Dumbbell className="w-5 h-5" />, label: 'Fitness & Nutrition' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold whitespace-nowrap transition-all ${
                activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-6 grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Chat Interface / Active Tab Content */}
        <div className="lg:col-span-8 flex flex-col h-[700px] bg-white rounded-[2rem] shadow-xl border border-slate-100 overflow-hidden">
          {activeTab === 'triage' && (
            <>
          <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/50">
            {messages.map((m) => (
              <div key={m.id} className={`flex gap-5 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border ${
                  m.sender === 'user' ? 'bg-indigo-600 border-indigo-700' : 'bg-rose-100 border-rose-200'
                }`}>
                  {m.sender === 'user' ? <User className="w-6 h-6 text-white" /> : <Bot className="w-7 h-7 text-rose-600" />}
                </div>
                <div className={`max-w-[85%] flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`p-6 rounded-[2rem] transition-all duration-300 ${
                    m.sender === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none shadow-md' 
                    : 'bg-white text-slate-800 rounded-tl-none border border-slate-200 shadow-lg'
                  }`}>
                    {m.meta && (
                      <div className={`flex items-center gap-2 mb-3 ${
                        m.meta === 'Emergency' ? 'text-rose-600' : m.meta === 'Moderate' ? 'text-amber-600' : 'text-emerald-600'
                      }`}>
                         <ShieldAlert className="w-5 h-5" />
                         <span className="text-xs font-black uppercase tracking-widest">{m.meta} {t('healthcare.condition', 'Condition')}</span>
                      </div>
                    )}
                    <p className="text-base leading-relaxed font-medium whitespace-pre-wrap">{m.text}</p>
                    
                    {m.medCategories && (
                      <div className="mt-4 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                        <div className="flex items-center gap-2 text-blue-800 font-bold mb-2">
                           <Pill className="w-4 h-4" /> {t('healthcare.recommendations', 'Recommended Medication Categories:')}
                        </div>
                        <ul className="list-disc list-inside text-blue-900 text-sm font-medium">
                          {m.medCategories.map((med, idx) => <li key={idx}>{med}</li>)}
                        </ul>
                      </div>
                    )}

                    {m.warning && (
                      <div className="mt-4 pt-4 border-t border-slate-100 text-xs italic text-slate-500 font-medium">
                        ⚠️ **{t('healthcare.safety_disclaimer', 'Safety Disclaimer:**')} {m.warning}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-5 animate-pulse">
                 <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center">
                  <Bot className="w-7 h-7 text-rose-600" />
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-5 flex gap-2 items-center shadow-md">
                  <div className="w-2.5 h-2.5 bg-rose-400 rounded-full animate-bounce"></div>
                  <div className="w-2.5 h-2.5 bg-rose-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-2.5 h-2.5 bg-rose-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-6 bg-white border-t border-slate-200">
            <form onSubmit={handleSend} className="relative flex items-center">
              <button type="button" className="absolute left-4 text-slate-400 hover:text-indigo-600 transition p-3">
                <Mic className="w-6 h-6" />
              </button>
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('healthcare.input_placeholder', "Describe your symptoms (e.g., chest pain, fever)...")}
                className="w-full pl-16 pr-20 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-lg font-medium"
              />
              <button 
                type="submit" 
                disabled={!input.trim() || isTyping}
                className="absolute right-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-2xl p-3.5 transition shadow-lg shadow-indigo-200"
              >
                <Send className="w-6 h-6" />
              </button>
            </form>
          </div>
          </>)}

          {activeTab === 'crime' && (
            <div className="p-10 flex flex-col items-center justify-center h-full text-center">
              <Camera className="w-20 h-20 text-slate-300 mb-6" />
              <h2 className="text-2xl font-black text-slate-800 mb-2">Secure Crime Reporting</h2>
              <p className="text-slate-500 max-w-md mx-auto mb-8">Anonymously report crimes with photos/videos. Track case status and raise safety concerns locally.</p>
              <button className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-black transition flex items-center gap-2">
                 Submit New Report
              </button>
            </div>
          )}

          {activeTab === 'sensors' && (
            <div className="p-10 flex flex-col items-center justify-center h-full text-center bg-amber-50/50">
              <Flame className="w-20 h-20 text-amber-500 mb-6 animate-pulse" />
              <h2 className="text-2xl font-black text-slate-800 mb-2">Smart IoT LPG Detector</h2>
              <p className="text-slate-500 max-w-md mx-auto mb-8">Real-time simulation. The system monitors LPG sensor data and triggers emergency alarms via Twilio to prevent accidents.</p>
              <div className="flex gap-4">
                 <button className="px-6 py-3 bg-amber-500 text-white rounded-xl font-bold shadow-lg shadow-amber-200">Start Sensor Simulation</button>
              </div>
            </div>
          )}

          {activeTab === 'forum' && (
            <div className="p-10 flex flex-col h-full bg-slate-50">
              <h2 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-2"><Users /> Community Health Forum</h2>
              <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-6 overflow-y-auto">
                 <div className="p-4 bg-indigo-50 text-indigo-900 rounded-xl mb-4 font-medium">Preventive Alert: Vaccination Drive on Sunday at PHC Center!</div>
                 <div className="border-b border-slate-100 py-4">
                    <p className="font-bold text-slate-800">Has anyone used the new Dengue rapid kit?</p>
                    <p className="text-sm text-slate-500 mt-1">AI Moderator: The kit is 95% accurate. Use it within 2 days of fever onset.</p>
                 </div>
              </div>
            </div>
          )}

          {activeTab === 'fitness' && (
            <div className="p-10 flex flex-col h-full items-center justify-center text-center">
              <Dumbbell className="w-20 h-20 text-emerald-500 mb-6" />
              <h2 className="text-2xl font-black text-slate-800 mb-2">Fitness & Nutrition Center</h2>
              <p className="text-slate-500 max-w-md mx-auto mb-8">Get personalized diet plans, exercise routines, and wellness practices localized to rural farming conditions.</p>
              <button className="px-8 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 shadow-xl shadow-emerald-200">
                Generate Weekly Plan
              </button>
            </div>
          )}

        </div>

        {/* Sidebar Info */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* Active Diagnosis Card */}
          <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-10"><Bot className="w-24 h-24" /></div>
             <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-3">
               <ShieldAlert className="text-emerald-500" /> {t('healthcare.current_assessment', 'Current AI Assessment')}
             </h3>
             {diagnosisState ? (
               <div>
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest mb-4 ${
                    diagnosisState.level === 'Emergency' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {t('healthcare.severity_tag', 'Severity:')} {diagnosisState.level}
                  </div>
                  <h4 className="font-black text-2xl text-slate-900 mb-2">{diagnosisState.cond}</h4>
                  <p className="text-slate-600 font-medium mb-4">{diagnosisState.rec}</p>
                  
                  {diagnosisState.level === 'Emergency' && (
                    <button onClick={triggerSOS} className="w-full py-4 mt-2 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 flex justify-center items-center gap-2 animate-bounce">
                      <Siren className="w-5 h-5"/> {t('healthcare.contact_hospital', 'CONTACT HOSPITAL NOW')}
                    </button>
                  )}
               </div>
             ) : (
               <p className="text-slate-400 font-medium italic">{t('healthcare.empty_assessment', 'Speak or type your symptoms to receive a real-time medical assessment.')}</p>
             )}
          </div>

          {/* RMP Integration */}
          <div className="bg-slate-900 rounded-[2rem] p-8 text-white relative overflow-hidden shadow-2xl shadow-indigo-900/20">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-500/30 to-transparent" />
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2 relative z-10">
              <User size={24} className="text-indigo-400" /> {t('healthcare.rmp_title', 'RMP Telemedicine')}
            </h3>
            <p className="text-slate-300 text-sm mb-6 leading-relaxed relative z-10">
              {t('healthcare.rmp_desc', 'Seamlessly connect with local Registered Medical Practitioners or district hospitals if medication categories require prescription.')}
            </p>
            <div className="bg-white/10 rounded-2xl p-4 flex items-center justify-between backdrop-blur-md relative z-10">
               <div className="flex items-center gap-4">
                 <div className="bg-indigo-500 w-12 h-12 rounded-full flex items-center justify-center shadow-lg">
                    <Phone className="w-5 h-5" />
                 </div>
                 <div>
                    <p className="text-[10px] font-bold text-indigo-300 tracking-widest uppercase">On-Call Doctor</p>
                    <p className="font-black text-lg tracking-wide">Dr. Reddy (PHC)</p>
                 </div>
               </div>
               <a href="tel:+919876543210" className="px-4 py-2 bg-white text-slate-900 text-sm font-bold rounded-xl hover:bg-indigo-50 transition-colors">Call</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
