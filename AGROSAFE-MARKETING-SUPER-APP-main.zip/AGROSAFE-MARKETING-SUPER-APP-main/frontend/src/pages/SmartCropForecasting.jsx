import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { TrendingUp, CloudRain, Sun, Calendar, AlertTriangle, ArrowRight, Activity, Thermometer } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const priceData = [
  { month: 'Jan', current: 20, predicted: 22 },
  { month: 'Feb', current: 21, predicted: 24 },
  { month: 'Mar', current: 23, predicted: 26 },
  { month: 'Apr', current: 25, predicted: 28 },
  { month: 'May', current: 22, predicted: 25 },
  { month: 'Jun', current: 19, predicted: 21 },
];

const yieldData = [
  { year: '2021', yield: 4.2 },
  { year: '2022', yield: 4.5 },
  { year: '2023', yield: 4.1 },
  { year: '2024', yield: 4.8 },
  { year: '2025', yield: 5.0 },
  { year: '2026', yield: 5.4 }, // Predicted
];

export default function SmartCropForecasting() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-amber-900 via-orange-800 to-red-900 text-white py-16 px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
        <Activity className="w-16 h-16 mx-auto mb-6 text-amber-300 opacity-90 relative z-10" />
        <h1 className="text-4xl md:text-5xl font-black mb-4 relative z-10">{t('Smart AI Crop Forecasting', 'Smart AI Crop Forecasting')}</h1>
        <p className="text-xl text-amber-100 max-w-2xl mx-auto opacity-90 font-medium relative z-10">
          {t('Predict yield, track pricing trends, and get personalized sowing alerts.', 'Predict yield, track pricing trends, and get personalized sowing alerts.')}
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 space-y-8">
        {/* Market Pricing Trends */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><TrendingUp className="text-amber-500"/> {t('Market Price Forecast', 'Market Price Forecast')}</h2>
              <select className="bg-gray-50 border border-gray-200 text-gray-700 text-sm rounded-lg focus:ring-amber-500 focus:border-amber-500 block p-2.5">
                <option>{t('Wheat', 'Wheat')}</option>
                <option>{t('Rice', 'Rice')}</option>
                <option>{t('Tomato', 'Tomato')}</option>
              </select>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={priceData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#6B7280' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6B7280' }} tickFormatter={(val) => `₹${val}`} />
                  <RechartsTooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                  <Line type="monotone" dataKey="current" stroke="#9CA3AF" strokeWidth={3} dot={{ r: 4 }} name="Historical (₹)" />
                  <Line type="monotone" dataKey="predicted" stroke="#F59E0B" strokeWidth={4} dot={{ r: 6, fill: '#F59E0B' }} name="AI Forecast (₹)" />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">{t('AI Confidence:', 'AI Confidence:')} <span className="font-bold text-amber-600">{t('87%', '87%')}</span> {t('(Based on weather & global supply)', '(Based on weather & global supply)')}</p>
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><Activity className="text-emerald-500"/> {t('Yield Prediction', 'Yield Prediction')}</h2>
              <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full">{t('Tons / Hectare', 'Tons / Hectare')}</span>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={yieldData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="year" axisLine={false} tickLine={false} tick={{ fill: '#6B7280' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6B7280' }} />
                  <RechartsTooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                  <Area type="monotone" dataKey="yield" stroke="#10B981" fillOpacity={0.2} fill="#10B981" strokeWidth={3} name="Yield" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">{t('Expected yield increase of', 'Expected yield increase of')} <span className="font-bold text-emerald-600">{t('8%', '8%')}</span> {t('over last year.', 'over last year.')}</p>
          </div>
        </div>

        {/* Personalized Alerts */}
        <h2 className="text-2xl font-bold text-gray-900 mb-4 pt-4">{t('Actionable Farm Insights', 'Actionable Farm Insights')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100 relative overflow-hidden group hover:shadow-md transition-all">
            <CloudRain className="absolute -right-4 -bottom-4 w-24 h-24 text-blue-200 opacity-50 group-hover:scale-110 transition-transform" />
            <h3 className="font-bold text-blue-900 text-lg mb-2 relative z-10">{t('Optimal Sowing Window', 'Optimal Sowing Window')}</h3>
            <p className="text-blue-700 text-sm mb-4 relative z-10">{t('Heavy pre-monsoon showers expected in 5 days. Ideal time to sow Kharif crops is between', 'Heavy pre-monsoon showers expected in 5 days. Ideal time to sow Kharif crops is between')} <strong className="font-black">{t('12th - 15th June', '12th - 15th June')}</strong>.</p>
            <button className="text-sm font-bold bg-white text-blue-700 px-4 py-2 rounded-lg relative z-10 hover:bg-blue-100">{t('Set Reminder', 'Set Reminder')}</button>
          </div>
          <div className="bg-orange-50 p-6 rounded-3xl border border-orange-100 relative overflow-hidden group hover:shadow-md transition-all">
            <Sun className="absolute -right-4 -bottom-4 w-24 h-24 text-orange-200 opacity-50 group-hover:scale-110 transition-transform" />
            <h3 className="font-bold text-orange-900 text-lg mb-2 relative z-10">{t('Harvest Warning', 'Harvest Warning')}</h3>
            <p className="text-orange-700 text-sm mb-4 relative z-10">{t('Heatwave approaching next week. Accelerate tomato harvest by 3 days to prevent crop spoilage.', 'Heatwave approaching next week. Accelerate tomato harvest by 3 days to prevent crop spoilage.')}</p>
            <button className="text-sm font-bold bg-white text-orange-700 px-4 py-2 rounded-lg relative z-10 hover:bg-orange-100">{t('View Details', 'View Details')}</button>
          </div>
          <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 relative overflow-hidden group hover:shadow-md transition-all">
            <Thermometer className="absolute -right-4 -bottom-4 w-24 h-24 text-emerald-200 opacity-50 group-hover:scale-110 transition-transform" />
            <h3 className="font-bold text-emerald-900 text-lg mb-2 relative z-10">{t('Soil Moisture Optimal', 'Soil Moisture Optimal')}</h3>
            <p className="text-emerald-700 text-sm mb-4 relative z-10">{t('Current soil moisture is at 68%. Hold off on irrigation for the next 48 hours to save water and energy.', 'Current soil moisture is at 68%. Hold off on irrigation for the next 48 hours to save water and energy.')}</p>
            <button className="text-sm font-bold bg-white text-emerald-700 px-4 py-2 rounded-lg relative z-10 hover:bg-emerald-100">{t('Check Sensors', 'Check Sensors')}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
