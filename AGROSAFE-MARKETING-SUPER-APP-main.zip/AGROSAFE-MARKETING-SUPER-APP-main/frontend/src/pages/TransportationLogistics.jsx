import React, { useState } from 'react';
import { Truck, MapPin, Route, Package, Clock, CheckCircle, Star, Phone, IndianRupee } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const VEHICLES = [
  { id:1, type:'Tata 407 Mini Truck', driver:'Raju Kumar', rating:4.8, eta:'25 min', price:1200, status:'Available', plate:'TS09AB1234' },
  { id:2, type:'Mahindra Bolero Pickup', driver:'Suresh Rao', rating:4.6, eta:'12 min', price:800, status:'Available', plate:'AP12CD5678' },
  { id:3, type:'Large Container Lorry', driver:'Venkat Das', rating:4.9, eta:'45 min', price:3500, status:'Busy', plate:'KA01EF9012' },
];

const ROUTES = [
  { from:'Your Farm', to:'APMC Hyderabad Market', dist:'42 km', time:'1h 10m', saved:'₹340 fuel' },
  { from:'Your Farm', to:'Cold Storage Hub – Warangal', dist:'68 km', time:'1h 45m', saved:'₹520 fuel' },
  { from:'Your Farm', to:'Consumer Doorstep (Uppal)', dist:'28 km', time:'40 min', saved:'₹210 fuel' },
];

export default function TransportationLogistics() {
  const { t } = useTranslation();
  const [tab, setTab] = useState('vehicles');
  const [booked, setBooked] = useState(null);
  const [tracking, setTracking] = useState(false);
  const [progress, setProgress] = useState(0);

  const book = (v) => {
    setBooked(v);
    setTracking(true);
    setProgress(0);
    const iv = setInterval(() => {
      setProgress(p => { if(p>=100){clearInterval(iv);return 100;} return p+2; });
    }, 120);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-amber-900 via-orange-800 to-yellow-900 text-white py-12 px-4 sm:px-8">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="bg-white/10 p-4 rounded-2xl backdrop-blur">
              <Truck className="w-12 h-12 text-amber-300" />
            </div>
            <div>
              <p className="text-amber-300 text-xs font-black uppercase tracking-widest mb-1">Live GPS Fleet</p>
              <h1 className="text-4xl font-black">{t('transport.title','Transportation & Logistics')}</h1>
              <p className="text-amber-100 mt-1">{t('transport.subtitle','Book vehicles, track deliveries & optimise harvest routes.')}</p>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl px-6 py-4 text-center">
            <p className="text-3xl font-black">3</p>
            <p className="text-amber-200 text-sm font-bold">Vehicles Nearby</p>
          </div>
        </div>
        <div className="max-w-6xl mx-auto flex gap-3 mt-8">
          {['vehicles','routes','tracking'].map(t2=>(
            <button key={t2} onClick={()=>setTab(t2)} className={`px-5 py-2 rounded-full font-bold text-sm capitalize transition-all ${tab===t2?'bg-white text-amber-900':'bg-white/10 text-white hover:bg-white/20'}`}>{t2}</button>
          ))}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-8 mt-10 space-y-6">
        {tab==='vehicles' && (
          <>
            <h2 className="text-2xl font-black text-gray-900">Available Vehicles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {VEHICLES.map(v=>(
                <div key={v.id} className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm hover:shadow-xl transition-all flex flex-col gap-4">
                  <div className="flex justify-between items-start">
                    <div className="bg-amber-100 p-3 rounded-2xl"><Truck className="w-8 h-8 text-amber-600"/></div>
                    <span className={`text-xs font-black px-3 py-1 rounded-full ${v.status==='Available'?'bg-green-100 text-green-700':'bg-red-100 text-red-700'}`}>{v.status}</span>
                  </div>
                  <div>
                    <h3 className="font-black text-gray-900 text-lg">{v.type}</h3>
                    <p className="text-gray-500 text-sm">{v.plate} • {v.driver}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-gray-50 rounded-xl p-2"><Star className="w-4 h-4 text-amber-500 mx-auto mb-1"/><p className="text-sm font-black text-gray-900">{v.rating}</p></div>
                    <div className="bg-gray-50 rounded-xl p-2"><Clock className="w-4 h-4 text-blue-500 mx-auto mb-1"/><p className="text-sm font-black text-gray-900">{v.eta}</p></div>
                    <div className="bg-gray-50 rounded-xl p-2"><IndianRupee className="w-4 h-4 text-green-500 mx-auto mb-1"/><p className="text-sm font-black text-gray-900">{v.price}</p></div>
                  </div>
                  <div className="flex gap-2 mt-auto">
                    <button onClick={()=>book(v)} disabled={v.status!=='Available'} className="flex-1 py-2.5 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">Book Now</button>
                    <button className="p-2.5 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors"><Phone className="w-5 h-5"/></button>
                  </div>
                </div>
              ))}
            </div>
            {booked && (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-5 flex items-center gap-4">
                <CheckCircle className="w-8 h-8 text-green-600 shrink-0"/>
                <div><p className="font-black text-green-900">Booking Confirmed: {booked.type}</p><p className="text-green-700 text-sm">Driver {booked.driver} is on the way. ETA: {booked.eta}</p></div>
              </div>
            )}
          </>
        )}

        {tab==='routes' && (
          <>
            <h2 className="text-2xl font-black text-gray-900">AI-Optimised Routes</h2>
            <div className="space-y-4">
              {ROUTES.map((r,i)=>(
                <div key={i} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm flex flex-col md:flex-row items-start md:items-center gap-5">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <MapPin className="w-5 h-5 text-red-500"/><span className="font-bold text-gray-700">{r.from}</span>
                      <span className="text-gray-300">→</span>
                      <MapPin className="w-5 h-5 text-green-500"/><span className="font-bold text-gray-900">{r.to}</span>
                    </div>
                    <div className="flex gap-6 text-sm text-gray-500 font-medium">
                      <span><Route className="w-4 h-4 inline mr-1"/>{r.dist}</span>
                      <span><Clock className="w-4 h-4 inline mr-1"/>{r.time}</span>
                      <span className="text-green-600 font-black">Saves {r.saved}</span>
                    </div>
                  </div>
                  <button className="px-6 py-2.5 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-colors text-sm">Navigate</button>
                </div>
              ))}
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6">
              <h3 className="font-black text-amber-900 text-lg mb-2">How AI Route Optimisation Works</h3>
              <p className="text-amber-800 text-sm leading-relaxed">AgroSafe's AI analyses current traffic, road conditions, fuel costs, and market peak hours to recommend the cheapest and fastest delivery route for your harvest. Routes are updated every 15 minutes.</p>
            </div>
          </>
        )}

        {tab==='tracking' && (
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl font-black text-gray-900 mb-6">Live Fleet Tracker</h2>
            {tracking && booked ? (
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl text-center">
                <div className="w-24 h-24 mx-auto rounded-full bg-amber-100 flex items-center justify-center mb-6 relative">
                  <Truck className="w-12 h-12 text-amber-600"/>
                  {progress < 100 && <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse border-2 border-white"/>}
                </div>
                <h3 className="text-2xl font-black text-gray-900 mb-2">{booked.type}</h3>
                <p className="text-gray-500 mb-6">Driver: {booked.driver} • {booked.plate}</p>
                <div className="mb-4 text-left">
                  <div className="flex justify-between text-sm font-bold mb-2">
                    <span className="text-gray-600">Delivery Progress</span>
                    <span className="text-amber-600">{progress}%</span>
                  </div>
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-amber-400 to-amber-600 rounded-full transition-all duration-300" style={{width:`${progress}%`}}/>
                  </div>
                </div>
                <p className="text-gray-500 text-sm">{progress<100?'Vehicle is en route to pickup location...':'Vehicle has arrived at destination!'}</p>
                {progress>=100 && <div className="mt-4 flex items-center justify-center gap-2 text-green-600 font-black"><CheckCircle className="w-6 h-6"/>Delivery Complete!</div>}
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-12 border border-gray-100 shadow-sm text-center">
                <Package className="w-20 h-20 text-gray-200 mx-auto mb-6"/>
                <h3 className="text-xl font-bold text-gray-800 mb-2">No Active Delivery</h3>
                <p className="text-gray-500 mb-6">Book a vehicle from the Vehicles tab to see live tracking here.</p>
                <button onClick={()=>setTab('vehicles')} className="px-8 py-3 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-colors">Book a Vehicle</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
