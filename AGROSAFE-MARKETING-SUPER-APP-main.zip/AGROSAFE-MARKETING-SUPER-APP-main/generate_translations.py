import os
import re
import json
import sqlite3
from deep_translator import GoogleTranslator

# The 8 target languages + en
LANGS = ['hi', 'te', 'ta', 'kn', 'ml', 'bn', 'mr', 'gu']

frontend_src = 'c:/Users/sony/OneDrive/Documents/Desktop/AGROSAFE NEW/frontend/src'
locales_dir = 'c:/Users/sony/OneDrive/Documents/Desktop/AGROSAFE NEW/frontend/public/locales'

# 1. Extract all t('string') or t("string") from JSX files
strings_to_translate = set()

for root, _, files in os.walk(frontend_src):
    for f in files:
        if f.endswith('.jsx') or f.endswith('.js'):
            filepath = os.path.join(root, f)
            with open(filepath, 'r', encoding='utf-8') as file:
                content = file.read()
                # matches t('key', 'default value') or t('key')
                # We specifically look for the second argument if it exists, otherwise the first
                matches = re.findall(r"t\(\s*['\"](.*?)['\"]\s*(?:,\s*['\"](.*?)['\"]\s*)?\)", content)
                for m in matches:
                    text = m[1] if m[1] else m[0]
                    # if it's a dotted key like marketplace.title, we might skip it or keep it if it's English
                    if text and '.' not in text:
                        strings_to_translate.add(text)

print(f"Found {len(strings_to_translate)} unique strings to translate.")

# Convert to list for batching
strings_list = list(strings_to_translate)
if not strings_list:
    print("No strings to translate. Exiting.")
    exit(0)

# 2. Setup SQLite database for caching
conn = sqlite3.connect('translations_cache.db')
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS translations (lang TEXT, text_key TEXT, translated TEXT, PRIMARY KEY (lang, text_key))")
conn.commit()

# 3. Translate and update JSONs
for lang in LANGS:
    print(f"Translating for {lang}...")
    lang_dir = os.path.join(locales_dir, lang)
    os.makedirs(lang_dir, exist_ok=True)
    json_path = os.path.join(lang_dir, 'translation.json')
    
    # Load existing
    translations = {}
    if os.path.exists(json_path):
        with open(json_path, 'r', encoding='utf-8') as f:
            try:
                translations = json.load(f)
            except:
                pass

    translator = GoogleTranslator(source='en', target=lang)
    
    # Process in batches
    batch_size = 50
    for i in range(0, len(strings_list), batch_size):
        batch = strings_list[i:i+batch_size]
        missing = []
        # Check cache
        for text in batch:
            if text in translations and translations[text]:
                continue
            c.execute('SELECT translated FROM translations WHERE lang=? AND text_key=?', (lang, text))
            row = c.fetchone()
            if row:
                translations[text] = row[0]
            else:
                missing.append(text)
                
        if missing:
            try:
                print(f"  Fetching API translation for {len(missing)} items...")
                res = translator.translate_batch(missing)
                for j, text in enumerate(missing):
                    translated = res[j] if res[j] else text
                    translations[text] = translated
                    c.execute('INSERT OR REPLACE INTO translations (lang, text_key, translated) VALUES (?, ?, ?)', (lang, text, translated))
                conn.commit()
            except Exception as e:
                print(f"  Error translating: {e}")
                for text in missing:
                    translations[text] = text # fallback to english

    # Save JSON
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(translations, f, ensure_ascii=False, indent=2)

print("Translation generation complete!")
