import React from 'react';
import { ShieldCheck, EyeOff, Lock, AlertTriangle, Smartphone, BellRing, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function Settings() {
  const { t } = useTranslation();
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 font-sans">
      <div className="mb-10">
        <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight mb-2">{t('settings.title', 'Settings & Security')}</h2>
        <p className="text-slate-500 text-lg font-medium">{t('settings.subtitle', 'Manage your account and AI cyber-protection.')}</p>
      </div>

      <div className="space-y-8">
        
        {/* Cybercrime Detection Module */}
        <div className="bg-rose-50 border border-rose-100 rounded-[2rem] p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldCheck className="w-32 h-32 text-rose-500"/></div>
          <div className="flex items-center gap-3 mb-6 relative z-10">
            <ShieldCheck className="w-8 h-8 text-rose-600" />
            <h3 className="text-2xl font-black text-rose-900">AI Cybercrime Shield</h3>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-rose-100 mb-4 relative z-10">
            <div className="flex gap-4 items-start">
              <div className="bg-amber-100 text-amber-600 p-3 rounded-xl shrink-0"><AlertTriangle className="w-6 h-6"/></div>
               <div>
                  <h4 className="font-bold text-slate-900 text-lg mb-1">{t('settings.threat_detected', 'Threat Detected: Phishing SMS')}</h4>
                  <p className="text-slate-600 font-medium text-sm leading-relaxed">
                    {t('settings.threat_desc', 'AgroSafe AI detected a suspicious SMS claiming to offer "Instant Loan Waivers". This is a known fraud pattern targeting farmers in your district. Do not click the links provided in that SMS.')}
                  </p>
                  <p className="text-xs font-bold text-slate-400 mt-3 uppercase tracking-widest">{t('settings.detected_time', 'Detected 2 mins ago')}</p>
               </div>
            </div>
          </div>
          
          <p className="text-rose-700 font-bold text-sm relative z-10">{t('settings.monitoring', 'AgroSafe AI actively monitors your device clipboard and agricultural SMS/Links to prevent financial fraud.')}</p>
        </div>

        {/* General Settings */}
        <div className="bg-white border border-slate-100 rounded-[2rem] overflow-hidden shadow-sm">
          {[
            { icon: <Lock />, title: t('settings.privacy_title', 'Privacy & Data'), desc: t('settings.privacy_desc', 'Manage data sharing and AI learning preferences') },
            { icon: <BellRing />, title: t('settings.alert_title', 'Alert Preferences'), desc: t('settings.alert_desc', 'Configure weather, SMS, and crop illness alerts') },
            { icon: <Smartphone />, title: t('settings.device_title', 'Linked Devices'), desc: t('settings.device_desc', 'Manage sessions across your devices') },
            { icon: <EyeOff />, title: t('settings.incognito_title', 'Incognito Mode'), desc: t('settings.incognito_desc', 'Browse marketplace without leaving traces') }
          ].map((item, idx) => (
            <div key={idx} className="flex items-center justify-between p-6 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0 cursor-pointer">
              <div className="flex items-center gap-5">
                 <div className="bg-slate-100 text-slate-600 p-3 rounded-xl">
                   {item.icon}
                 </div>
                 <div>
                    <h4 className="font-bold text-slate-900">{item.title}</h4>
                    <p className="text-slate-500 text-sm font-medium">{item.desc}</p>
                 </div>
              </div>
              <ChevronRight className="text-slate-300" />
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
