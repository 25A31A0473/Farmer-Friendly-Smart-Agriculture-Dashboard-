import React, { useState, useRef } from 'react';
import { PhoneCall, Mic, RadioTower, Users, CheckCircle, Clock, MicOff, Volume2, Phone } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const INITIAL_FARMERS = [
  { name:'Ramesh Reddy', phone:'+91 98765 43210', lang:'Telugu', status:'Delivered' },
  { name:'Suresh Kumar', phone:'+91 87654 32109', lang:'Hindi', status:'Pending' },
  { name:'Kavita Devi', phone:'+91 76543 21098', lang:'Marathi', status:'Failed' },
  { name:'Balram Singh', phone:'+91 65432 10987', lang:'Hindi', status:'Delivered' },
  { name:'Meera Nair', phone:'+91 54321 09876', lang:'Malayalam', status:'Pending' },
];

const MESSAGES = [
  'Today\'s mandi price for tomatoes is ₹18/kg. Consider selling within 2 days.',
  'Weather alert: Heavy rain expected in your district tomorrow. Secure your harvest.',
  'New PM-KUSUM subsidy: Apply for solar pump at your local Krishi office.',
];

export default function AICallingSystem() {
  const { t } = useTranslation();
  const [farmers, setFarmers] = useState(INITIAL_FARMERS);
  const [isCalling, setIsCalling] = useState(false);
  const [activeCall, setActiveCall] = useState(0);
  const [callProgress, setCallProgress] = useState(0);
  const [log, setLog] = useState([]);
  const [msgIdx, setMsgIdx] = useState(0);
  
  // New Farmer Form State
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newLang, setNewLang] = useState('Hindi');

  const timerRef = useRef(null);

  const speak = (text, lang='hi-IN') => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    u.rate = 0.9;
    window.speechSynthesis.speak(u);
  };

  const startBroadcast = () => {
    if (farmers.length === 0) return;
    setIsCalling(true);
    setActiveCall(0);
    setCallProgress(0);
    setLog([]);
    let idx = 0;
    const next = () => {
      if (idx >= farmers.length) { setIsCalling(false); return; }
      const f = farmers[idx];
      setActiveCall(idx);
      setCallProgress(Math.round(((idx+1)/farmers.length)*100));
      setLog(l => [...l, { farmer: f.name, msg: MESSAGES[idx % MESSAGES.length], time: new Date().toLocaleTimeString() }]);
      speak(MESSAGES[idx % MESSAGES.length], f.lang === 'Telugu' ? 'te-IN' : f.lang === 'Hindi' ? 'hi-IN' : 'hi-IN');
      idx++;
      timerRef.current = setTimeout(next, 3000);
    };
    next();
  };

  const handleAddFarmer = (e) => {
    e.preventDefault();
    if (!newName || !newPhone) return;
    const newFarmer = {
      name: newName,
      phone: newPhone,
      lang: newLang,
      status: 'Pending'
    };
    setFarmers([newFarmer, ...farmers]);
    setNewName('');
    setNewPhone('');
  };

  const stopBroadcast = () => {
    setIsCalling(false);
    window.speechSynthesis?.cancel();
    clearTimeout(timerRef.current);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-teal-900 via-cyan-800 to-blue-900 text-white py-12 px-4 sm:px-8">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="bg-white/10 p-4 rounded-2xl backdrop-blur">
              <RadioTower className="w-12 h-12 text-teal-300"/>
            </div>
            <div>
              <p className="text-teal-300 text-xs font-black uppercase tracking-widest mb-1">Automated AI</p>
              <h1 className="text-4xl font-black">{t('calling.title','AI Community Calling')}</h1>
              <p className="text-teal-100 mt-1">{t('calling.subtitle','Automated multilingual voice updates for farmers with keypad phones.')}</p>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl px-6 py-4 text-center mt-4 md:mt-0">
            <p className="text-3xl font-black">{farmers.length}</p>
            <p className="text-teal-200 text-sm font-bold">Registered Farmers</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-8 mt-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Control Panel */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl text-center">
            <div className={`w-36 h-36 mx-auto rounded-full flex items-center justify-center mb-6 transition-all duration-500 ${isCalling?'bg-teal-500 shadow-[0_0_60px_rgba(20,184,166,0.5)] animate-pulse':'bg-gray-100'}`}>
              <RadioTower className={`w-20 h-20 ${isCalling?'text-white':'text-gray-400'}`}/>
            </div>
            <h2 className="text-2xl font-black text-gray-900 mb-2">
              {isCalling ? `Calling ${farmers[activeCall]?.name || ''}…` : 'Ready to Broadcast'}
            </h2>
            {isCalling && (
              <div className="mb-4">
                <div className="flex justify-between text-sm font-bold mb-1">
                  <span className="text-gray-500">Progress</span>
                  <span className="text-teal-600">{callProgress}%</span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-teal-500 rounded-full transition-all duration-500" style={{width:`${callProgress}%`}}/>
                </div>
              </div>
            )}
            <p className="text-gray-500 text-sm mb-8 max-w-sm mx-auto">
              {t('calling.desc','AI dials registered numbers and reads daily weather, market prices, and pest warnings in local language.')}
            </p>
            <button onClick={isCalling?stopBroadcast:startBroadcast}
              className={`px-10 py-4 font-black rounded-2xl text-lg shadow-xl transition-all ${isCalling?'bg-red-500 hover:bg-red-600 text-white':'bg-teal-600 hover:bg-teal-700 text-white'}`}>
              {isCalling ? <span className="flex items-center gap-2"><MicOff className="w-5 h-5"/>Stop Broadcast</span> : <span className="flex items-center gap-2"><Mic className="w-5 h-5"/>Start Auto-Dialer</span>}
            </button>
          </div>

          {/* Today's Message */}
          <div className="bg-teal-50 border border-teal-200 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <Volume2 className="w-5 h-5 text-teal-600"/>
              <h3 className="font-black text-teal-900">Today's Broadcast Message</h3>
            </div>
            <div className="space-y-3">
              {MESSAGES.map((m,i)=>(
                <div key={i} className={`p-3 rounded-xl border cursor-pointer transition-all ${msgIdx===i?'bg-teal-600 text-white border-teal-600':'bg-white text-gray-700 border-teal-100 hover:border-teal-300'}`}
                  onClick={()=>{setMsgIdx(i);speak(m,'hi-IN');}}>
                  <p className="text-sm font-medium">{m}</p>
                </div>
              ))}
            </div>
            <p className="text-xs text-teal-600 mt-3 font-bold">Click a message to preview via Text-to-Speech</p>
          </div>
        </div>

        {/* Farmer List & Call Log */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-teal-600"/>
              <h3 className="font-black text-gray-900">Registered Farmers</h3>
            </div>
            
            {/* Add Farmer Form */}
            <form onSubmit={handleAddFarmer} className="p-4 border-b border-gray-100 bg-gray-50 flex flex-col sm:flex-row gap-2">
              <input 
                type="text" 
                placeholder="Name" 
                value={newName} 
                onChange={(e) => setNewName(e.target.value)} 
                className="flex-1 p-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-teal-500"
                required
              />
              <input 
                type="tel" 
                placeholder="Phone Number" 
                value={newPhone} 
                onChange={(e) => setNewPhone(e.target.value)} 
                className="flex-1 p-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-teal-500"
                required
              />
              <select 
                value={newLang} 
                onChange={(e) => setNewLang(e.target.value)} 
                className="p-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-teal-500 bg-white"
              >
                <option>Hindi</option>
                <option>Telugu</option>
                <option>Marathi</option>
                <option>Malayalam</option>
              </select>
              <button type="submit" className="bg-teal-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-teal-700 transition-colors text-sm whitespace-nowrap">
                Add +
              </button>
            </form>

            <div className="divide-y divide-gray-50 max-h-80 overflow-y-auto">
              {farmers.map((f,i)=>(
                <div key={i} className={`flex items-center justify-between px-6 py-4 transition-colors ${isCalling && activeCall===i ? 'bg-teal-50' : ''}`}>
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-black ${isCalling && activeCall===i?'bg-teal-500 text-white animate-pulse':'bg-gray-100 text-gray-600'}`}>
                      {f.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-sm">{f.name}</p>
                      <p className="text-gray-400 text-xs">{f.phone} • {f.lang}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isCalling && activeCall===i && <Phone className="w-4 h-4 text-teal-500 animate-bounce"/>}
                    <span className={`text-xs font-black px-3 py-1 rounded-full ${f.status==='Delivered'?'bg-green-100 text-green-700':f.status==='Failed'?'bg-red-100 text-red-700':'bg-yellow-100 text-yellow-700'}`}>{f.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {log.length > 0 && (
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
                <Clock className="w-5 h-5 text-gray-400"/>
                <h3 className="font-black text-gray-900">Live Call Log</h3>
              </div>
              <div className="divide-y divide-gray-50 max-h-64 overflow-y-auto">
                {log.map((l,i)=>(
                  <div key={i} className="px-6 py-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-gray-900 text-sm flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500"/>{l.farmer}</span>
                      <span className="text-gray-400 text-xs">{l.time}</span>
                    </div>
                    <p className="text-gray-500 text-xs">{l.msg}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
