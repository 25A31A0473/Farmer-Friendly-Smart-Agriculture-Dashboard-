import React, { useState, useEffect, useRef } from 'react';
import { ShoppingBag, Truck, CheckCircle2, Search, MapPin, Tag, ShieldCheck, ChevronRight, X, IndianRupee, Store, Camera, Activity, Leaf, Star, Route, Users, TrendingUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { BrowserRouter as Router, useLocation } from 'react-router-dom';

export default function Marketplace() {
  const { t } = useTranslation();
  const location = useLocation();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Initialize tab optimally based on where user clicked from Dashboard
  const [activeTab, setActiveTab] = useState(location.state?.tab || 'consumer'); 
  
  // Modals
  const [selectedItem, setSelectedItem] = useState(null);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showReceipt, setShowReceipt] = useState(null);
  const [showLogistics, setShowLogistics] = useState(false);

  // Buy form state
  const [buyQty, setBuyQty] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [isBulk, setIsBulk] = useState(false);

  // Farmer Upload state
  const [uploadData, setUploadData] = useState({ crop: '', qty: '', price: '', category: 'Grains' });
  const [isScanningCrop, setIsScanningCrop] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    setLoading(true);
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/marketplace/listings');
      if (res.ok) {
        const data = await res.json();
        setListings(data.length ? data : mockListings);
      } else {
        setListings(mockListings);
      }
    } catch {
      setListings(mockListings);
    }
    setLoading(false);
  };

  const handleBuy = async (e) => {
    e.preventDefault();
    if (!selectedItem) return;
    
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/marketplace/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          listing_id: selectedItem.id,
          consumer_id: 'user_123',
          quantity_kg: buyQty,
          payment_method: paymentMethod
        })
      });
      
      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setShowBuyModal(false);
        setShowReceipt(data.receipt);
        // Refresh listings (mocking client side for now)
        setListings(prev => prev.map(l => l.id === selectedItem.id ? { ...l, quantity_kg: l.quantity_kg - buyQty } : l));
      } else {
        alert(data.detail || "Transaction failed");
      }
    } catch {
      // Fallback for mock
      setShowBuyModal(false);
      setShowReceipt({
        transaction_id: `txn_${Math.floor(Math.random()*10000)}`,
        amount_paid: selectedItem.price_per_kg * buyQty,
        seller: selectedItem.farmer_name,
        crop: selectedItem.crop_type,
        smart_contract_status: "locked_until_delivery"
      });
      setListings(prev => prev.map(l => l.id === selectedItem.id ? { ...l, quantity_kg: l.quantity_kg - buyQty } : l));
    }
  };

  const handleFarmerUpload = (e) => {
    if (e.target.files.length === 0) return;
    setIsScanningCrop(true);
    setTimeout(() => {
       const newItem = {
         id: `lst_${Date.now()}`,
         farmer_name: "You (Verified Farmer)",
         crop_type: uploadData.crop || "Fresh Produce",
         quantity_kg: Number(uploadData.qty) || 100,
         price_per_kg: Number(uploadData.price) || 50,
         village: "Current GPS Location",
         rating: 5.0,
         reviews: 0,
         organic: true
       };
       setListings([newItem, ...listings]);
       setIsScanningCrop(false);
       setUploadData({ crop: '', qty: '', price: '', category: 'Grains' });
       alert(t('marketplace.upload_success', "AI Quality Check Passed: Crop is Authentic & Fresh. Listed successfully!"));
       setActiveTab('consumer');
    }, 2500);
  };

  const filtered = listings.filter(l => 
    l.crop_type.toLowerCase().includes(search.toLowerCase()) || 
    l.farmer_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-green-900 via-nature-800 to-teal-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10 text-center">
          <Store className="w-16 h-16 mx-auto mb-6 text-green-300 opacity-90" />
          <h1 className="text-5xl md:text-6xl font-black mb-4 tracking-tight drop-shadow-md">{t('marketplace.title', 'Kisan Mart')}</h1>
          <p className="text-xl md:text-2xl text-green-50 max-w-2xl mx-auto opacity-90 font-medium leading-relaxed mb-10">
            {t('marketplace.subtitle', 'Direct from Farmers to You. Zero Middlemen. AI Verified.')}
          </p>

          <div className="flex justify-center gap-4 mb-10">
             <button onClick={()=>setActiveTab('consumer')} className={`px-8 py-3 rounded-full font-bold transition-all ${activeTab==='consumer' ? 'bg-white text-green-900 shadow-xl' : 'bg-green-900/50 text-white hover:bg-green-800'}`}>
                {t('marketplace.tab_consumer', 'Global Marketplace')}
             </button>
             <button onClick={()=>setActiveTab('farmer')} className={`px-8 py-3 rounded-full font-bold transition-all ${activeTab==='farmer' ? 'bg-white text-green-900 shadow-xl' : 'bg-green-900/50 text-white hover:bg-green-800'}`}>
                {t('marketplace.tab_farmer', 'Farmer Upload Hub')}
             </button>
          </div>
          
          {activeTab === 'consumer' && (
            <div className="mt-6 max-w-2xl mx-auto relative group">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 w-6 h-6 group-focus-within:text-nature-600 transition-colors" />
              <input 
                type="text" 
                placeholder={t('marketplace.search_placeholder', 'Search for organic rice, tomatoes, wheat...')} 
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-16 pr-6 py-5 rounded-full text-lg text-gray-900 focus:outline-none focus:ring-4 focus:ring-green-400/50 shadow-2xl transition-all"
              />
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {activeTab === 'farmer' ? (
          <div className="max-w-3xl mx-auto bg-white rounded-[2rem] shadow-xl p-8 border border-gray-100">
             <div className="flex items-center gap-3 mb-8">
               <div className="bg-nature-100 p-3 rounded-2xl"><Camera className="w-8 h-8 text-nature-600"/></div>
               <div>
                  <h2 className="text-2xl font-black text-gray-900">{t('marketplace.farmer_upload', 'Upload Harvest')}</h2>
                  <p className="text-gray-500 font-medium">{t('marketplace.farmer_sub', 'AI will verify freshness and auto-tag your GPS location.')}</p>
               </div>
             </div>

             <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{t('marketplace.crop_name', 'Crop Name')}</label>
                  <input type="text" value={uploadData.crop} onChange={e=>setUploadData({...uploadData, crop: e.target.value})} className="w-full px-4 py-3 bg-gray-50 rounded-xl focus:ring-2 focus:ring-nature-500 outline-none font-medium" placeholder="E.g., Organic Wheat" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{t('marketplace.category', 'Category')}</label>
                  <select value={uploadData.category} onChange={e=>setUploadData({...uploadData, category: e.target.value})} className="w-full px-4 py-3 bg-gray-50 rounded-xl focus:ring-2 focus:ring-nature-500 outline-none font-medium">
                    <option>{t('Grains', 'Grains')}</option><option>{t('Fruits', 'Fruits')}</option><option>{t('Vegetables', 'Vegetables')}</option><option>{t('Dairy', 'Dairy')}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{t('marketplace.qty', 'Quantity (kg)')}</label>
                  <input type="number" value={uploadData.qty} onChange={e=>setUploadData({...uploadData, qty: e.target.value})} className="w-full px-4 py-3 bg-gray-50 rounded-xl focus:ring-2 focus:ring-nature-500 outline-none font-medium" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{t('marketplace.price', 'Price per kg (₹)')}</label>
                  <input type="number" value={uploadData.price} onChange={e=>setUploadData({...uploadData, price: e.target.value})} className="w-full px-4 py-3 bg-gray-50 rounded-xl focus:ring-2 focus:ring-nature-500 outline-none font-medium" />
                </div>
             </div>

             <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFarmerUpload} capture="environment" />
             <div className="flex gap-4">
               <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isScanningCrop || !uploadData.crop}
                  className={`flex-1 py-4 rounded-2xl font-black text-lg flex justify-center items-center gap-2 transition-all ${isScanningCrop ? 'bg-gray-100 text-gray-400' : uploadData.crop ? 'bg-nature-600 text-white hover:bg-nature-700 shadow-xl shadow-nature-200' : 'bg-gray-200 text-gray-500'}`}
               >
                  {isScanningCrop ? <Activity className="w-6 h-6 animate-spin" /> : <Camera className="w-5 h-5" />}
                  {isScanningCrop ? t('marketplace.analyzing', 'Processing...') : t('marketplace.take_photo', 'Auto-List Crop')}
               </button>
               <button 
                  disabled={isScanningCrop || !uploadData.crop}
                  className={`px-6 py-4 rounded-2xl font-black text-sm flex justify-center items-center gap-2 transition-all border-2 ${uploadData.crop ? 'border-nature-600 text-nature-700 hover:bg-nature-50' : 'border-gray-200 text-gray-400'}`}
               >
                  <Users className="w-5 h-5" /> {t('marketplace.group_sell', 'Sell as Group')}
               </button>
             </div>
             <p className="text-center text-gray-400 text-xs mt-4 font-bold uppercase tracking-widest"><MapPin className="inline w-3 h-3"/> {t('GPS Auto-Tagging Enabled', 'GPS Auto-Tagging Enabled')}</p>
          </div>
        ) : (
          <>
        {/* Seasonal Alerts Banner */}
        <div className="bg-amber-50 border border-amber-200 rounded-[2rem] p-6 mb-8 flex flex-col md:flex-row items-center justify-between shadow-sm">
           <div className="flex items-center gap-4">
              <div className="bg-amber-100 text-amber-600 p-3 rounded-full"><TrendingUp className="w-6 h-6"/></div>
              <div>
                 <h3 className="text-amber-900 font-bold">{t('marketplace.seasonal_alert', 'Seasonal Alert: Fresh Mangoes & Wheat')}</h3>
                 <p className="text-amber-700 text-sm font-medium">{t('marketplace.ai_recommendation', 'AI Recommendation: Buy wheat in bulk now. Prices are dynamically lower due to peak harvest season.')}</p>
              </div>
           </div>
           <button className="mt-4 md:mt-0 px-6 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-bold transition-all text-sm">{t('marketplace.view_deals', 'View Deals')}</button>
        </div>

        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900">{t('marketplace.fresh_harvests', 'Fresh Harvests')}</h2>
          <span className="bg-green-100 text-green-800 text-sm font-bold px-4 py-1.5 rounded-full flex items-center gap-2">
            <ShieldCheck className="w-4 h-4" /> {t('marketplace.blockchain_verified', 'Blockchain Verified')}
          </span>
        </div>

        {loading ? (
          <div className="text-center py-20 text-gray-500">{t('marketplace.loading', 'Loading live marketplace...')}</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filtered.map(item => (
              <div key={item.id} className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group flex flex-col">
                <div className="h-48 bg-gray-200 relative overflow-hidden shrink-0">
                  <img src={`https://source.unsplash.com/400x300/?${item.crop_type},farming`} alt={item.crop_type} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm text-gray-900 text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1 shadow-sm">
                    <MapPin className="w-3 h-3 text-nature-600" /> {item.village || "Local Farm"}
                  </div>
                  {item.organic && (
                    <div className="absolute bottom-4 left-4 bg-green-500/90 backdrop-blur-sm text-white text-xs font-black px-3 py-1.5 rounded-md flex items-center gap-1 shadow-sm">
                      <Leaf className="w-3 h-3" /> {t('ORGANIC', 'ORGANIC')}
                    </div>
                  )}
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900 capitalize leading-tight">{item.crop_type}</h3>
                    <div className="text-right">
                      <p className="text-2xl font-black text-nature-600 leading-none flex items-center gap-2">
                        ₹{item.price_per_kg} <span className="text-sm font-medium text-gray-400">(${(item.price_per_kg / 83).toFixed(2)})</span>
                        {item.dynamic_discount && <span className="text-xs text-red-500 font-bold ml-1 line-through">₹{item.price_per_kg + 5}</span>}
                      </p>
                      <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mt-1">
                        {t('marketplace.per_kg', 'per kg')} {item.dynamic_discount && <span className="text-emerald-500 block">{t('- Demand Pricing', '- Demand Pricing')}</span>}
                      </p>
                    </div>
                  </div>
                  <div className="text-gray-500 text-sm mb-4 font-medium flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-nature-100 text-nature-700 flex items-center justify-center font-bold text-xs shrink-0">
                      {item.farmer_name.charAt(0)}
                    </span>
                    <span className="truncate">{item.farmer_name}</span>
                    <span className="text-amber-500 flex items-center gap-1 shrink-0"><Star className="w-3 h-3 fill-current"/>{item.rating || '4.8'}</span>
                  </div>
                  
                  <div className="mb-6 flex flex-wrap items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest">
                    <span>{item.quantity_kg > 0 ? `${item.quantity_kg} kg ${t('marketplace.available', 'available')}` : <span className="text-red-500">{t('marketplace.sold_out', 'Sold Out')}</span>}</span>
                    {item.export_ready && <span className="bg-blue-50 text-blue-600 px-2 py-1 rounded text-[10px]">{t('Export Ready', 'Export Ready')}</span>}
                  </div>
                  
                  <button 
                    disabled={item.quantity_kg <= 0}
                    onClick={() => { setSelectedItem(item); setShowBuyModal(true); setBuyQty(1); setIsBulk(false); }}
                    className="w-full py-3.5 mt-auto bg-gray-900 hover:bg-black text-white rounded-xl font-bold transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2 shadow-lg shadow-gray-200"
                  >
                    {item.quantity_kg <= 0 ? t('marketplace.out_of_stock', 'Out of Stock') : t('marketplace.buy_now', 'Select & Buy')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        </>
        )}
      </div>

      {/* Buy Modal */}
      {showBuyModal && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-[2rem] p-8 max-w-md w-full shadow-2xl relative animate-in zoom-in-95 duration-200 outline-none">
            <button onClick={() => setShowBuyModal(false)} className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 p-2 rounded-full transition-colors"><X className="w-5 h-5" /></button>
            <h3 className="text-2xl font-black mb-1">{selectedItem.crop_type}</h3>
            <p className="text-gray-500 font-medium mb-4">{t('marketplace.sold_by', 'Sold by')} {selectedItem.farmer_name} <ShieldCheck className="w-4 h-4 text-blue-500 inline"/></p>

            <div className="flex gap-4 mb-6">
               <button onClick={()=>setIsBulk(false)} className={`flex-1 py-2 rounded-lg font-bold text-sm border-2 ${!isBulk ? 'border-nature-600 bg-nature-50 text-nature-700' : 'border-gray-100 text-gray-500'}`}>{t('marketplace.retail', 'Retail Order')}</button>
               <button onClick={()=>setIsBulk(true)} className={`flex-1 py-2 rounded-lg font-bold text-sm border-2 ${isBulk ? 'border-nature-600 bg-nature-50 text-nature-700' : 'border-gray-100 text-gray-500'}`}>{t('marketplace.bulk', 'Bulk / B2B Order')}</button>
            </div>
            
            <form onSubmit={(e) => { if (isBulk && buyQty < 50) { e.preventDefault(); alert("Bulk orders must be at least 50 kg."); return; } handleBuy(e); }} className="space-y-6">
              <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-2">{t('marketplace.qty', 'Quantity (kg)')}</label>
                <input type="number" min={isBulk ? 50 : 1} max={selectedItem.quantity_kg} value={buyQty} onChange={e => setBuyQty(Number(e.target.value))} className="w-full bg-transparent text-2xl font-black focus:outline-none" />
                {isBulk && <p className="text-xs text-nature-600 font-bold mt-2">{t('Minimum 50 kg for Bulk discounts', 'Minimum 50 kg for Bulk discounts')}</p>}
              </div>
              
              <div className="flex justify-between items-center bg-nature-50 rounded-2xl p-4 border border-nature-100">
                <span className="text-nature-800 font-medium">{t('marketplace.total', 'Total Price')}</span>
                <span className="text-2xl font-black text-nature-700">₹{(selectedItem.price_per_kg * buyQty * (isBulk ? 0.9 : 1)).toFixed(2)}</span>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-3">{t('marketplace.payment', 'Payment Method')}</label>
                <div className="grid grid-cols-2 gap-3">
                  {['upi', 'wallet'].map(p => (
                    <div key={p} onClick={() => setPaymentMethod(p)} className={`p-4 border rounded-xl cursor-pointer text-center font-bold uppercase tracking-wide text-sm transition-all ${paymentMethod === p ? 'border-nature-600 bg-nature-50 text-nature-700 ring-2 ring-nature-600/20' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}>
                      {p === 'upi' ? t('marketplace.upi', 'UPI') : t('marketplace.crypto', 'Crypto Wallet')}
                    </div>
                  ))}
                </div>
              </div>
              
              <button type="submit" className="w-full py-4 bg-nature-600 hover:bg-nature-700 text-white rounded-xl font-black text-lg transition-all active:scale-95 shadow-xl shadow-nature-200 flex justify-center items-center gap-2">
                <ShieldCheck className="w-5 h-5" /> {t('marketplace.checkout', 'Secure Checkout')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Receipt & Logistics Modal */}
      {showReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-[2rem] p-10 max-w-lg w-full shadow-2xl relative text-center">
            <button onClick={() => { setShowReceipt(null); setShowLogistics(false); }} className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 p-2 rounded-full transition-colors"><X className="w-5 h-5" /></button>
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            <h3 className="text-2xl font-black mb-2 text-gray-900">{t('marketplace.success', 'Payment Successful!')}</h3>
            <p className="text-gray-500 mb-8 font-medium">{t('marketplace.locked', 'Smart contract locked until delivery.')}</p>
            
            <div className="bg-gray-50 rounded-2xl p-6 text-left mb-8 border border-gray-100">
              <div className="flex justify-between mb-3"><span className="text-gray-500">{t('Txn ID', 'Txn ID')}</span><span className="font-mono font-bold">{showReceipt.transaction_id}</span></div>
              <div className="flex justify-between mb-3"><span className="text-gray-500">{t('Seller', 'Seller')}</span><span className="font-bold flex items-center gap-1"><ShieldCheck className="w-3 h-3 text-blue-500"/>{showReceipt.seller}</span></div>
              <div className="flex justify-between mb-3"><span className="text-gray-500">{t('Item', 'Item')}</span><span className="font-bold capitalize">{showReceipt.crop}</span></div>
              <div className="flex justify-between pt-3 border-t border-gray-200 mt-2"><span className="text-gray-900 font-bold">{t('Amount Paid', 'Amount Paid')}</span><span className="font-black text-xl text-green-600">₹{showReceipt.amount_paid}</span></div>
            </div>

            {!showLogistics ? (
              <button onClick={() => setShowLogistics(true)} className="w-full py-4 bg-gray-900 hover:bg-black text-white rounded-xl font-bold flex justify-center items-center gap-3 transition-colors">
                <Route className="w-5 h-5" /> {t('marketplace.book_transport', 'Integrated Logistics & Tracking')}
              </button>
            ) : (
              <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 relative overflow-hidden text-left animate-in slide-in-from-bottom-4">
                <Truck className="absolute -right-4 -bottom-4 w-24 h-24 text-blue-100 opacity-50" />
                <h4 className="font-black text-blue-900 text-lg mb-2 relative z-10">{t('marketplace.logistics_title', 'AI Logistics Optimised')}</h4>
                <p className="text-blue-700 text-sm font-medium mb-4 relative z-10">{t('marketplace.logistics_desc', 'Nearest fleet assigned. Real-time truck route calculated.')}</p>
                <div className="flex items-center gap-4 relative z-10">
                  <div className="bg-white/60 backdrop-blur rounded-xl p-3 inline-block">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-blue-500 block">{t('Est. Shipping', 'Est. Shipping')}</span>
                    <span className="text-xl font-black text-blue-900">₹{isBulk ? 1400 : 140}</span>
                  </div>
                  <div className="bg-white/60 backdrop-blur rounded-xl p-3 inline-block">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-blue-500 block">{t('Delivery To', 'Delivery To')}</span>
                    <span className="text-sm font-black text-blue-900">{t('12:30 PM Tomorrow', '12:30 PM Tomorrow')}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const mockListings = [
  { id: 'lst_1', farmer_name: "Ramesh Kumar", crop_type: "Organic Sona Masuri Rice", quantity_kg: 500, price_per_kg: 55, village: "Warangal", rating: 4.8, organic: true, dynamic_discount: true, location_lat: 18.0, location_lon: 79.5, export_ready: true },
  { id: 'lst_2', farmer_name: "Suresh Reddy", crop_type: "Hybrid Tomatoes", quantity_kg: 200, price_per_kg: 18, village: "Medak", rating: 4.9, organic: false, dynamic_discount: false, location_lat: 18.0, location_lon: 78.5, export_ready: false },
  { id: 'lst_3', farmer_name: "Laxmi Devi", crop_type: "Desi Wheat", quantity_kg: 800, price_per_kg: 40, village: "Nizamabad", rating: 4.7, organic: true, dynamic_discount: true, location_lat: 18.5, location_lon: 78.0, export_ready: true },
  { id: 'lst_4', farmer_name: "Kiran R.", crop_type: "Premium Cotton", quantity_kg: 1000, price_per_kg: 65, village: "Adilabad", rating: 4.6, organic: true, dynamic_discount: false, location_lat: 19.5, location_lon: 78.5, export_ready: true },
];
