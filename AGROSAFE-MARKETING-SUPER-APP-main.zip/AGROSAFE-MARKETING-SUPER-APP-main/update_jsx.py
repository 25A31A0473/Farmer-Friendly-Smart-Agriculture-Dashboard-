import os
import re

files_to_update = [
    'frontend/src/pages/ConsumerEngagement.jsx',
    'frontend/src/pages/FinancialHub.jsx',
    'frontend/src/pages/SmartCropForecasting.jsx',
    'frontend/src/pages/SustainabilityModule.jsx',
    'frontend/src/pages/CommunityHub.jsx',
    'frontend/src/pages/Marketplace.jsx',
    'frontend/src/pages/AITutors.jsx'
]

def process_jsx(filepath):
    if not os.path.exists(filepath): return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Ensure import is present
    if 'useTranslation' not in content:
        content = content.replace("import React", "import React\nimport { useTranslation } from 'react-i18next';")
        # Find default export component to inject hook
        match = re.search(r'export default function (\w+)\(.*?\) {', content)
        if match:
            func_def = match.group(0)
            content = content.replace(func_def, func_def + "\n  const { t } = useTranslation();")

    # Replace literal text nodes >text< with >{t('text')}<
    def repl(m):
        text = m.group(1).strip()
        # Skip if it's purely symbols, numbers, or looks like code/jsx
        if not text or '{' in text or '}' in text or '<' in text or '>' in text or len(text) < 2:
            return m.group(0)
        # Skip if already translated or has react variables
        if text.startswith('t(') or '$' in text:
            return m.group(0)
        
        # Avoid breaking if it contains single quotes
        safe_text = text.replace("'", "\\'")
        # Keep original whitespace around the tag
        original = m.group(0)
        start_tag = original[:original.find(m.group(1))]
        end_tag = original[original.find(m.group(1))+len(m.group(1)):]
        
        return f"{start_tag}{{t('{safe_text}', '{safe_text}')}}{end_tag}"
        
    new_content = re.sub(r'>\s*([^<>{]+?)\s*<', repl, content)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
    print(f'Processed {filepath}')

for fp in files_to_update:
    process_jsx(fp)
