import React, { useState, useEffect } from 'react';
import { Users, Bell, Clock, Phone, Plus, Send, Trash2, CheckCircle2, AlertCircle, ShoppingCart, Sparkles, MessageSquare, History, ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { db, auth } from '../firebase';
import { collection, addDoc, query, where, getDocs, serverTimestamp, orderBy } from 'firebase/firestore';
import AICallingSystem from './AICallingSystem';

export default function CommunityAlerts() {
  const [activeTab, setActiveTab] = useState('alerts');

  return (
    <div className="min-h-screen bg-white pb-24 font-sans">
      <div className="bg-slate-100 p-2 flex justify-center gap-2 border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('alerts')} 
          className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${activeTab === 'alerts' ? 'bg-nature-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-200'}`}
        >
          Community Broadcast & SOS
        </button>
        <button 
          onClick={() => setActiveTab('calling')} 
          className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${activeTab === 'calling' ? 'bg-teal-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-200'}`}
        >
          AI Auto-Dialer (Calling)
        </button>
      </div>

      {activeTab === 'alerts' ? <AlertsTab /> : <AICallingSystem />}
    </div>
  );
}

function AlertsTab() {
  const { t, i18n } = useTranslation();
  const [groupName, setGroupName] = useState('');
  const [alertTime, setAlertTime] = useState('06:00');
  const [members, setMembers] = useState([{ name: '', phone: '' }]);
  const [marketPrices, setMarketPrices] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  const [aiPreview, setAiPreview] = useState(null);

  useEffect(() => {
    fetchMarketPrices();
    if (auth.currentUser) {
      loadGroups();
    }
  }, [auth.currentUser]);

  const loadGroups = async () => {
    try {
      const q = query(
        collection(db, 'community_groups'), 
        where('admin_id', '==', auth.currentUser.uid),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      const list = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setGroups(list);
    } catch (err) {
      console.error('Error loading groups:', err);
    }
  };

  const fetchMarketPrices = async () => {
    try {
      const resp = await fetch('https://twelve-hands-greet.loca.lt/api/market_prices');
      const data = await resp.json();
      setMarketPrices(data);
    } catch (err) {
      console.error('Error fetching market prices:', err);
    }
  };

  const fetchAiPreview = async () => {
    setLoading(true);
    try {
      const resp = await fetch(`https://twelve-hands-greet.loca.lt/api/community/compose_preview?lang=${i18n.language}`, { method: 'POST' });
      const data = await resp.json();
      setAiPreview(data.alert);
    } catch (err) {
      setAiPreview("Failed to generate AI preview. Check connection.");
    } finally {
      setLoading(false);
    }
  };

  const addMember = () => setMembers([...members, { name: '', phone: '' }]);
  const removeMember = (index) => setMembers(members.filter((_, i) => i !== index));
  const handleMemberChange = (index, field, value) => {
    const newMembers = [...members];
    newMembers[index][field] = value;
    setMembers(newMembers);
  };

  const createGroup = async () => {
    if (!auth.currentUser) {
      setStatus({ type: 'error', message: 'Auth Required: Please sign in to create groups.' });
      return;
    }

    if (!groupName || members.some(m => !m.name || !m.phone)) {
      setStatus({ type: 'error', message: 'Validation Failed: Group name and member details are mandatory.' });
      return;
    }

    setLoading(true);
    try {
      const docRef = await addDoc(collection(db, 'community_groups'), {
        name: groupName,
        admin_id: auth.currentUser.uid,
        members,
        alert_time: alertTime,
        lang: i18n.language,
        createdAt: serverTimestamp()
      });

      // Notify Backend
      await fetch('https://twelve-hands-greet.loca.lt/api/community/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          group_id: docRef.id,
          name: groupName,
          admin_id: auth.currentUser.uid,
          members,
          alert_time: alertTime,
          lang: i18n.language
        })
      });

      setGroups([{ id: docRef.id, name: groupName, members, alert_time: alertTime }, ...groups]);
      setStatus({ type: 'success', message: 'Group Scheduled Successfully!' });
      setGroupName('');
      setMembers([{ name: '', phone: '' }]);
    } catch (err) {
      setStatus({ type: 'error', message: 'Firestore Sync Error. Please retry.' });
    } finally {
      setLoading(false);
    }
  };

  const triggerBroadcast = async (groupId) => {
    setStatus({ type: 'info', message: 'AI is composing and broadcasting...' });
    try {
      const resp = await fetch(`https://twelve-hands-greet.loca.lt/api/community/trigger_alert/${groupId}`, { method: 'POST' });
      const data = await resp.json();
      if (data.status === 'success') {
        setStatus({ type: 'success', message: `Broadcast Successful to ${data.broadcast_summary.length} members!` });
      } else {
        setStatus({ type: 'success', message: `Triggered in Demo Mode (Message: ${data.message_sent})` });
      }
    } catch (err) {
      setStatus({ type: 'error', message: 'Broadcast channel unavailable.' });
    }
  };

  const triggerSOS = async (groupId) => {
    setStatus({ type: 'info', message: 'Triggering Emergency SOS...' });
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        try {
          const resp = await fetch(`https://twelve-hands-greet.loca.lt/api/sos_alert`, { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              lat: position.coords.latitude,
              lon: position.coords.longitude,
              phone: auth.currentUser?.phoneNumber || auth.currentUser?.email || "+910000000000",
              group_id: groupId
            })
          });
          const data = await resp.json();
          setStatus({ type: 'success', message: `Emergency SOS broadcasted successfully!` });
        } catch (err) {
          setStatus({ type: 'error', message: 'SOS Failed to send. Please dial 108 manually.' });
        }
      }, () => {
        setStatus({ type: 'error', message: 'Location access required for SOS.' });
      });
    } else {
      setStatus({ type: 'error', message: 'Geolocation not supported by this browser.' });
    }
  };

  return (
    <div className="bg-white pb-24">
      {/* Premium Header */}
      <div className="bg-gradient-to-r from-nature-700 via-nature-800 to-slate-900 text-white pt-16 pb-32 px-4 shadow-inner relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-3 px-5 py-2 bg-white/10 rounded-full border border-white/20 mb-8 backdrop-blur-md animate-in fade-in slide-in-from-top duration-700">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span className="text-sm font-bold tracking-tight">AI Community Broadcast Engine</span>
          </div>
          <h1 className="text-5xl lg:text-7xl font-black mb-6 tracking-tighter">Connect Your Community</h1>
          <p className="text-nature-100 text-xl lg:text-2xl opacity-80 max-w-3xl mx-auto leading-relaxed font-medium">
            Bridge the digital divide. Send AI-powered market summaries and tips directly to basic keypad phones via SMS and Voice calls.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Main Content: Group Creation */}
          <div className="lg:col-span-8 space-y-8">
            <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-50 p-10 lg:p-14">
              <h2 className="text-3xl font-black text-slate-900 flex items-center gap-4 mb-10">
                <Plus className="text-nature-600 bg-nature-50 p-2 w-10 h-10 rounded-xl" /> Create Daily Broadcast
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest pl-1">Group Name</label>
                  <input 
                    type="text" 
                    placeholder="Progressive Farmers Union"
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-nature-500/10 focus:bg-white outline-none transition-all font-bold text-slate-800 text-lg"
                    value={groupName}
                    onChange={e => setGroupName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest pl-1">Daily Blast Time</label>
                  <div className="relative group">
                    <Clock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-hover:text-nature-600 transition" size={24} />
                    <input 
                      type="time" 
                      className="w-full pl-16 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-nature-500/10 outline-none font-bold text-lg"
                      value={alertTime}
                      onChange={e => setAlertTime(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Members List */}
              <div className="pt-10 border-t border-slate-50">
                <div className="flex items-center justify-between mb-6 px-1">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Broadcast Recipients</h3>
                    <p className="text-slate-400 text-xs font-medium">Any phone, any network supported.</p>
                  </div>
                  <button 
                    onClick={addMember}
                    className="px-4 py-2 bg-slate-100 text-slate-600 font-black rounded-xl text-xs flex items-center gap-2 hover:bg-nature-600 hover:text-white transition-all shadow-sm"
                  >
                    <Plus size={16} /> Add Member
                  </button>
                </div>
                
                <div className="space-y-4 max-h-[400px] overflow-y-auto pr-4 custom-scrollbar mb-10">
                  {members.map((member, i) => (
                    <div key={i} className="flex gap-4 items-center animate-in slide-in-from-left duration-300 group">
                      <div className="bg-slate-50 rounded-2xl flex-1 flex border border-slate-100 group-hover:border-nature-200 transition">
                        <input 
                          placeholder="Name"
                          className="flex-1 px-4 py-3 bg-transparent outline-none font-bold text-slate-700"
                          value={member.name}
                          onChange={e => handleMemberChange(i, 'name', e.target.value)}
                        />
                        <div className="w-px h-8 bg-slate-200 my-auto" />
                        <input 
                          placeholder="Phone (e.g. +91...)"
                          className="flex-1 px-4 py-3 bg-transparent outline-none text-slate-500 font-medium w-full sm:w-auto"
                          value={member.phone}
                          onChange={e => handleMemberChange(i, 'phone', e.target.value)}
                        />
                        {member.phone && (
                          <div className="flex gap-2 pr-4 items-center">
                            <a href={`tel:${member.phone}`} title="Call" className="text-emerald-500 hover:text-emerald-600 transition"><Phone size={18}/></a>
                            <a href={`sms:${member.phone}`} title="SMS" className="text-blue-500 hover:text-blue-600 transition"><MessageSquare size={18}/></a>
                          </div>
                        )}
                      </div>
                      {members.length > 1 && (
                        <button 
                          onClick={() => removeMember(i)}
                          className="p-3 text-slate-200 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                        >
                          <Trash2 size={20} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Status & Feedback */}
              {status && (
                <div className={`p-6 rounded-3xl mb-10 flex items-center gap-4 animate-in zoom-in-95 ${
                  status.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 
                  status.type === 'info' ? 'bg-nature-50 text-nature-700 border border-nature-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                }`}>
                  <div className={`p-2 rounded-xl ${status.type === 'success' ? 'bg-emerald-100' : status.type === 'info' ? 'bg-nature-100' : 'bg-rose-100'}`}>
                    {status.type === 'success' ? <CheckCircle2 size={24}/> : status.type === 'info' ? <MessageSquare size={24}/> : <AlertCircle size={24}/>}
                  </div>
                  <p className="font-bold text-sm tracking-tight">{status.message}</p>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={createGroup}
                    className="flex-1 py-5 bg-nature-600 hover:bg-nature-700 text-white font-black rounded-3xl shadow-xl shadow-nature-100 transition-all active:scale-95 disabled:opacity-50 text-lg flex items-center justify-center gap-3"
                    disabled={loading}
                  >
                    {loading ? <Clock className="animate-spin" /> : <Bell />} Schedule Broadcast
                  </button>
                  <button 
                    onClick={fetchAiPreview}
                    className="px-8 py-5 bg-slate-900 text-white font-black rounded-3xl hover:bg-black transition-all flex items-center gap-3 shadow-xl shadow-slate-200"
                    disabled={loading}
                  >
                    <Sparkles className="w-6 h-6 text-amber-400" /> Preview AI Alert
                  </button>
              </div>

              {aiPreview && (
                <div className="mt-8 p-8 bg-slate-900 rounded-3xl border border-slate-700 animate-in slide-in-from-bottom relative group">
                  <div className="absolute -top-3 left-8 bg-amber-400 text-black text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">AI Composition Preview</div>
                  <p className="text-white text-lg font-medium leading-relaxed font-mono">"{aiPreview}"</p>
                  <p className="text-slate-500 text-[10px] mt-4 font-bold uppercase tracking-widest underline decoration-nature-500 decoration-2 underline-offset-4 cursor-default">
                    Will be sent in {i18n.language.toUpperCase()} with market integration
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Area */}
          <div className="lg:col-span-4 space-y-10">
            
            {/* Market Prices Sidebar */}
            <div className="bg-slate-50 rounded-[2.5rem] p-10 border border-slate-100 shadow-sm relative overflow-hidden">
              <div className="absolute -bottom-10 -right-10 bg-nature-100 h-32 w-32 rounded-full opacity-30" />
              <h3 className="text-2xl font-black text-slate-900 mb-8 flex gap-3 items-center">
                <ShoppingCart className="text-amber-500" size={28} /> Latest Mandi
              </h3>
              <div className="space-y-4">
                {marketPrices.map((p, i) => (
                  <div key={i} className="flex justify-between items-center p-5 bg-white rounded-3xl border border-slate-100 shadow-sm hover:translate-x-1 transition-transform">
                    <div className="flex gap-4 items-center">
                       <div className={`w-2 h-10 rounded-full ${p.trend === 'rising' ? 'bg-emerald-500' : p.trend === 'falling' ? 'bg-rose-500' : 'bg-slate-300'}`} />
                        <div>
                          <div className="text-base font-black text-slate-900">{p.commodity}</div>
                          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{p.trend} Today</div>
                        </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-black text-nature-700">₹{p.price}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Managed Groups */}
            <div className="bg-white rounded-[2.5rem] p-10 shadow-2xl shadow-slate-200 border border-slate-50">
              <h3 className="text-2xl font-black text-slate-900 mb-8 flex items-center gap-3">
                <History className="text-nature-600" /> Active Blast list
              </h3>
              {groups.length === 0 ? (
                <div className="text-center py-10 opacity-30">
                   <Bell size={48} className="mx-auto mb-4" />
                   <p className="font-bold text-sm">No scheduled reports</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {groups.map((g, i) => (
                    <div key={i} className="p-6 bg-slate-50 rounded-[1.8rem] border border-slate-100 group">
                      <div className="font-black text-lg text-slate-900 mb-2">{g.name}</div>
                      <div className="flex justify-between items-center text-xs font-bold text-slate-400">
                        <span className="flex items-center gap-1"><Users size={14}/> {g.members.length}</span>
                        <span className="flex items-center gap-1"><Clock size={14}/> {g.alert_time}</span>
                      </div>
                      <button 
                        onClick={() => triggerBroadcast(g.id)}
                        className="w-full mt-6 py-3 bg-white text-slate-900 border border-slate-200 font-black rounded-2xl flex items-center justify-center gap-2 hover:bg-nature-600 hover:text-white transition-all shadow-md active:scale-95"
                      >
                        Send Manual Blast <ArrowRight size={16}/>
                      </button>
                      <a 
                        href={`sms:${g.members.map(m => m.phone).join(',')}`}
                        className="w-full mt-2 py-3 bg-blue-50 text-blue-600 border border-blue-200 font-black rounded-2xl flex items-center justify-center gap-2 hover:bg-blue-600 hover:text-white transition-all shadow-sm active:scale-95"
                      >
                        <MessageSquare size={16}/> Native Group SMS
                      </a>
                      <button 
                        onClick={() => triggerSOS(g.id)}
                        className="w-full mt-2 py-3 bg-rose-50 text-rose-600 border border-rose-200 font-black rounded-2xl flex items-center justify-center gap-2 hover:bg-rose-600 hover:text-white transition-all shadow-sm active:scale-95"
                      >
                        <AlertCircle size={16}/> Emergency SOS
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
