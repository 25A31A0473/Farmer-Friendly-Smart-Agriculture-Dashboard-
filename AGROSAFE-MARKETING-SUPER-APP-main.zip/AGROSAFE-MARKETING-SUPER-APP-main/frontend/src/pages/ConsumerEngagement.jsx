import React from 'react';
import { Gift, Box, Star, Heart, CheckCircle2, ChevronRight, UserCircle2, ThumbsUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function ConsumerEngagement() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      <div className="bg-gradient-to-br from-rose-900 via-pink-800 to-red-900 text-white py-16 px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
        <Heart className="w-16 h-16 mx-auto mb-6 text-rose-300 opacity-90 relative z-10" />
        <h1 className="text-4xl md:text-5xl font-black mb-4 relative z-10">{t('Consumer Engagement', 'Consumer Engagement')}</h1>
        <p className="text-xl text-rose-100 max-w-2xl mx-auto opacity-90 font-medium relative z-10">
          {t('Earn rewards, subscribe to seasonal boxes, and read verified farmer stories.', 'Earn rewards, subscribe to seasonal boxes, and read verified farmer stories.')}
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 space-y-12">
        {/* Loyalty Rewards */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Gift className="w-8 h-8 text-rose-600" />
              <h2 className="text-2xl font-bold text-gray-900">{t('Agro Rewards', 'Agro Rewards')}</h2>
            </div>
            <div className="bg-rose-100 text-rose-800 px-4 py-2 rounded-full font-black flex items-center gap-2">
              <Star className="w-5 h-5 fill-current"/> {t('1,250 Points', '1,250 Points')}
            </div>
          </div>
          
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Support Local, Get Rewarded', 'Support Local, Get Rewarded')}</h3>
              <p className="text-gray-500 mb-6">{t('Earn points on every purchase directly from a farmer. Redeem points for discounts or donate them to the Farmer Welfare Fund.', 'Earn points on every purchase directly from a farmer. Redeem points for discounts or donate them to the Farmer Welfare Fund.')}</p>
              
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-2xl flex justify-between items-center border border-gray-100">
                  <span className="font-bold text-gray-700">{t('Next Tier: Gold Member', 'Next Tier: Gold Member')}</span>
                  <span className="text-sm text-gray-500">{t('250 pts away', '250 pts away')}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div className="bg-rose-500 h-3 rounded-full" style={{width: '80%'}}></div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-rose-50 p-4 rounded-2xl text-center border border-rose-100 cursor-pointer hover:bg-rose-100 transition-colors">
                <div className="w-12 h-12 bg-rose-200 text-rose-700 rounded-full flex items-center justify-center mx-auto mb-2"><Gift className="w-6 h-6"/></div>
                <span className="block font-bold text-gray-900 mb-1">{t('₹500 Off', '₹500 Off')}</span>
                <span className="text-sm text-rose-600 font-bold">{t('1000 Pts', '1000 Pts')}</span>
              </div>
              <div className="bg-blue-50 p-4 rounded-2xl text-center border border-blue-100 cursor-pointer hover:bg-blue-100 transition-colors">
                <div className="w-12 h-12 bg-blue-200 text-blue-700 rounded-full flex items-center justify-center mx-auto mb-2"><Heart className="w-6 h-6"/></div>
                <span className="block font-bold text-gray-900 mb-1">{t('Donate to Farm', 'Donate to Farm')}</span>
                <span className="text-sm text-blue-600 font-bold">{t('500 Pts', '500 Pts')}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Subscription Boxes */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <Box className="w-8 h-8 text-amber-600" />
            <h2 className="text-2xl font-bold text-gray-900">{t('Seasonal Produce Subscriptions', 'Seasonal Produce Subscriptions')}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-3xl p-6 shadow-sm border-2 border-transparent hover:border-amber-200 transition-all group">
              <div className="bg-amber-100 w-16 h-16 rounded-2xl flex items-center justify-center mb-4"><Box className="w-8 h-8 text-amber-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('The Fruit Basket', 'The Fruit Basket')}</h3>
              <p className="text-gray-500 text-sm mb-4">{t('Assorted seasonal fruits delivered fresh from organic orchards every week.', 'Assorted seasonal fruits delivered fresh from organic orchards every week.')}</p>
              <div className="font-black text-2xl text-gray-900 mb-6">{t('₹899', '₹899')} <span className="text-sm text-gray-400 font-medium">{t('/ week', '/ week')}</span></div>
              <button className="w-full py-3 bg-amber-50 text-amber-700 rounded-xl font-bold group-hover:bg-amber-600 group-hover:text-white transition-colors">{t('Subscribe', 'Subscribe')}</button>
            </div>
            <div className="bg-white rounded-3xl p-6 shadow-xl border-2 border-green-500 relative transform scale-105">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-xs font-black uppercase tracking-wider">{t('Most Popular', 'Most Popular')}</div>
              <div className="bg-green-100 w-16 h-16 rounded-2xl flex items-center justify-center mb-4"><Box className="w-8 h-8 text-green-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Family Veggie Box', 'Family Veggie Box')}</h3>
              <p className="text-gray-500 text-sm mb-4">{t('Everything you need for a week of healthy eating. 100% pesticide-free vegetables.', 'Everything you need for a week of healthy eating. 100% pesticide-free vegetables.')}</p>
              <div className="font-black text-2xl text-gray-900 mb-6">{t('₹1,299', '₹1,299')} <span className="text-sm text-gray-400 font-medium">{t('/ week', '/ week')}</span></div>
              <button className="w-full py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-200">{t('Subscribe Now', 'Subscribe Now')}</button>
            </div>
            <div className="bg-white rounded-3xl p-6 shadow-sm border-2 border-transparent hover:border-blue-200 transition-all group">
              <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mb-4"><Box className="w-8 h-8 text-blue-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Healthy Grains Box', 'Healthy Grains Box')}</h3>
              <p className="text-gray-500 text-sm mb-4">{t('Millets, quinoa, and unpolished rice sourced directly from sustainable farmers.', 'Millets, quinoa, and unpolished rice sourced directly from sustainable farmers.')}</p>
              <div className="font-black text-2xl text-gray-900 mb-6">{t('₹1,499', '₹1,499')} <span className="text-sm text-gray-400 font-medium">{t('/ month', '/ month')}</span></div>
              <button className="w-full py-3 bg-blue-50 text-blue-700 rounded-xl font-bold group-hover:bg-blue-600 group-hover:text-white transition-colors">{t('Subscribe', 'Subscribe')}</button>
            </div>
          </div>
        </section>

        {/* Farmer Stories */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <UserCircle2 className="w-8 h-8 text-teal-600" />
            <h2 className="text-2xl font-bold text-gray-900">{t('Verified Farmer Stories', 'Verified Farmer Stories')}</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 flex flex-col md:flex-row hover:shadow-lg transition-shadow">
              <img src="https://source.unsplash.com/300x300/?indian,farmer,smile" alt="Farmer" className="w-full md:w-48 h-48 md:h-auto object-cover" />
              <div className="p-6 flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-bold text-gray-900">{t('Kavita Reddy', 'Kavita Reddy')}</h3>
                  <CheckCircle2 className="w-5 h-5 text-blue-500"/>
                </div>
                <p className="text-sm text-teal-600 font-bold mb-3">{t('Pioneering Organic Turmeric in Telangana', 'Pioneering Organic Turmeric in Telangana')}</p>
                <p className="text-gray-500 text-sm mb-4 line-clamp-3">{t('"Switching to organic wasn\'t easy, but thanks to the AgroSafe community, my yields are up and I\'m earning 30% more by selling directly to consumers like you."', '"Switching to organic wasn\'t easy, but thanks to the AgroSafe community, my yields are up and I\'m earning 30% more by selling directly to consumers like you."')}</p>
                <button className="text-teal-600 font-bold text-sm flex items-center hover:underline mt-auto w-max">{t('Read Full Story', 'Read Full Story')} <ChevronRight className="w-4 h-4"/></button>
              </div>
            </div>

            <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 flex flex-col md:flex-row hover:shadow-lg transition-shadow">
              <img src="https://source.unsplash.com/300x300/?indian,farmer,field" alt="Farmer" className="w-full md:w-48 h-48 md:h-auto object-cover" />
              <div className="p-6 flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-bold text-gray-900">{t('Ram Mohan', 'Ram Mohan')}</h3>
                  <CheckCircle2 className="w-5 h-5 text-blue-500"/>
                </div>
                <p className="text-sm text-teal-600 font-bold mb-3">{t('Water Conservation Champion', 'Water Conservation Champion')}</p>
                <p className="text-gray-500 text-sm mb-4 line-clamp-3">{t('"By using the AI weather predictions and drip irrigation subsidies, we\'ve saved millions of liters of water this year while growing top-quality tomatoes."', '"By using the AI weather predictions and drip irrigation subsidies, we\'ve saved millions of liters of water this year while growing top-quality tomatoes."')}</p>
                <button className="text-teal-600 font-bold text-sm flex items-center hover:underline mt-auto w-max">{t('Read Full Story', 'Read Full Story')} <ChevronRight className="w-4 h-4"/></button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
