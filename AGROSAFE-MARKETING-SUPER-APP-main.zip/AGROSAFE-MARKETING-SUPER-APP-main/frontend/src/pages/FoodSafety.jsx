import React, { useState, useRef } from 'react';
import { Apple, Plus, AlertTriangle, ShieldCheck, ThermometerSnowflake, Tag, Sparkles, HeartHandshake, X, Camera, Upload, Activity, ShieldAlert, PhoneCall } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function FoodSafety() {
  const { t, i18n } = useTranslation();
  const [items, setItems] = useState([
    { id: 1, name: "Milk", category: "Dairy", expiry: "2023-10-25", safe: false, suitableFor: "All", protein: "8g/cup", vitamin: "D, B12" },
    { id: 2, name: "Whole Wheat Bread", category: "Bakery", expiry: "2024-05-10", safe: true, suitableFor: "Diabetic Friendly", protein: "4g/slice", vitamin: "B1, B3" },
    { id: 3, name: "Fresh Spinach", category: "Vegetables", expiry: "2024-05-15", safe: true, suitableFor: "High BP, All", protein: "3g/100g", vitamin: "A, C, K" },
  ]);

  const [newItem, setNewItem] = useState({ name: '', category: 'Vegetables', expiry: '' });
  const [isScanning, setIsScanning] = useState(false);
  const fileInputRef = useRef(null);

  // AI Nutrition State
  const [showAIModal, setShowAIModal] = useState(false);
  const [age, setAge] = useState(30);
  const [conditions, setConditions] = useState('');
  const [nutritionPlan, setNutritionPlan] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);

  // NGO State
  const [ngoAlert, setNgoAlert] = useState(null);

  const handleAddItem = (e) => {
    e.preventDefault();
    if (!newItem.name || !newItem.expiry) return;
    
    // Simple mock logic for safety check based on date
    const expiryDate = new Date(newItem.expiry);
    const today = new Date();
    const isSafe = expiryDate >= today;

    setItems([...items, { 
      id: Date.now(), 
      ...newItem, 
      safe: isSafe,
      suitableFor: "General",
      protein: "Pending...",
      vitamin: "Pending..."
    }]);
    setNewItem({ name: '', category: 'Vegetables', expiry: '' });
  };

  const handleScanUpload = (e) => {
    if (e.target.files.length === 0) return;
    setIsScanning(true);
    
    // Simulate AI Camera Processing
    setTimeout(() => {
      setItems([
        { id: Date.now()+1, name: "Scanned Apple", category: "Fruits", expiry: "2024-12-10", safe: true, suitableFor: "Diabetic Friendly", protein: "0.3g", vitamin: "C, K" },
        { id: Date.now()+2, name: "Scanned Spoiled Yogurt", category: "Dairy", expiry: "2023-11-01", safe: false, suitableFor: "None", protein: "N/A", vitamin: "N/A" },
        ...items
      ]);
      setIsScanning(false);
      alert("AI Vision Analysis Complete! 2 items detected.");
    }, 2000);
  };

  const getAINutrition = async (e) => {
    e.preventDefault();
    setLoadingAI(true);
    const available = items.filter(i => i.safe).map(i => i.name);
    
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/food/nutrition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ age: Number(age), health_conditions: conditions, available_items: available })
      });
      const data = await res.json();
      setNutritionPlan(data.plan || "Follow a balanced diet based on your inventory.");
    } catch {
      setNutritionPlan("Consider making a wholesome spinach sandwich with your fresh spinach and whole wheat bread. This provides necessary iron and fiber.");
    }
    setLoadingAI(false);
  };

  const handleRedistribute = async (item) => {
    try {
      const res = await fetch('https://twelve-hands-greet.loca.lt/api/food/redistribute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item_name: item.name,
          quantity: "1 unit",
          expiry_date: item.expiry,
          donor_phone: "+91-9876543210", donor_lat: 17.385, donor_lon: 78.4867
        })
      });
      const data = await res.json();
      setNgoAlert(data.message || `Alerted NGOs about ${item.name}.`);
    } catch {
      setNgoAlert(`Alerted 3 local NGOs that ${item.name} is available for pickup.`);
    }
    setTimeout(() => setNgoAlert(null), 5000);
    // Remove from our list
    setItems(items.filter(i => i.id !== item.id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-500 font-sans">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <Apple className="h-10 w-10 text-health-600" />
          <div>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight">Food Safety & Nutrition</h2>
            <p className="text-gray-500 font-medium">Monitor household food expiry and get personalized AI diets.</p>
          </div>
        </div>
        <button onClick={() => setShowAIModal(true)} className="px-6 py-3 bg-health-100 text-health-700 hover:bg-health-200 hover:text-health-800 rounded-full font-bold transition-colors flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-health-600" /> AI Diet Planner
        </button>
      </div>

      {ngoAlert && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-6 py-4 rounded-2xl mb-8 flex items-center gap-3 shadow-sm animate-in slide-in-from-top">
          <HeartHandshake className="w-6 h-6 text-green-600" />
          <span className="font-bold">{ngoAlert}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Add Item Form */}
        <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100 h-fit sticky top-24">
          <h3 className="text-xl font-bold mb-6 text-gray-900">Add Groceries</h3>
          <form onSubmit={handleAddItem} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Item Name</label>
              <input 
                type="text" 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-health-500 focus:bg-white outline-none transition font-medium" 
                placeholder="e.g. Organic Tomatoes"
                value={newItem.name}
                onChange={e => setNewItem({...newItem, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Category</label>
              <select 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-health-500 focus:bg-white outline-none transition font-medium"
                value={newItem.category}
                onChange={e => setNewItem({...newItem, category: e.target.value})}
              >
                <option>Vegetables</option>
                <option>Fruits</option>
                <option>Dairy</option>
                <option>Meat</option>
                <option>Bakery</option>
                <option>Pantry</option>
                <option>Medicine</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Expiry Date</label>
              <input 
                type="date" 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-health-500 focus:bg-white outline-none transition font-medium text-gray-700"
                value={newItem.expiry}
                onChange={e => setNewItem({...newItem, expiry: e.target.value})}
              />
            </div>
            <button type="submit" className="w-full py-4 bg-health-600 text-white font-bold rounded-xl hover:bg-health-700 transition-all flex justify-center items-center gap-2 mt-6 shadow-xl shadow-health-200">
              <Plus className="w-5 h-5" /> Add to Inventory
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-gray-100">
            <h4 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-4">AI Vision Scanner</h4>
            <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handleScanUpload} />
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isScanning}
              className={`w-full py-4 font-bold rounded-xl flex items-center justify-center gap-2 transition-all ${isScanning ? 'bg-gray-100 text-gray-400' : 'bg-gray-900 text-white hover:bg-black shadow-lg shadow-gray-300'}`}
            >
              {isScanning ? <Activity className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
              {isScanning ? 'Processing Image...' : 'Scan Multiple Items'}
            </button>
            <p className="text-xs text-gray-400 mt-3 text-center">Take a photo of your groceries to auto-analyze quality, nutrition, and safety.</p>
          </div>
        </div>

        {/* Inventory List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-xl font-bold mb-6 text-gray-900 flex items-center gap-2 justify-between">
            <span>Your Inventory</span>
            <span className="text-xs font-bold bg-gray-100 text-gray-600 py-1.5 px-3 rounded-full">{items.length} Items</span>
          </h3>
          
          {items.map(item => (
            <div key={item.id} className={`p-6 rounded-[2rem] flex flex-col sm:flex-row items-center justify-between border transition-all hover:shadow-md ${item.safe ? 'bg-white border-gray-100 hover:border-health-200' : 'bg-red-50 border-red-100'}`}>
              <div className="flex items-center gap-4 w-full sm:w-auto mb-4 sm:mb-0">
                <div className={`p-4 rounded-2xl ${item.safe ? 'bg-health-50 text-health-600' : 'bg-red-100 text-red-600'}`}>
                  {item.safe ? <ShieldCheck className="w-8 h-8" /> : <AlertTriangle className="w-8 h-8" />}
                </div>
                <div>
                  <h4 className="text-xl font-bold text-gray-900">{item.name}</h4>
                  <div className="flex gap-2 mt-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 border border-gray-200 rounded-md px-2 py-1 flex items-center gap-1"><Tag className="w-3 h-3" /> {item.category}</span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-health-700 bg-health-50 border border-health-100 rounded-md px-2 py-1">{item.suitableFor}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 w-full sm:w-auto border-t sm:border-none pt-4 sm:pt-0 border-gray-100">
                {!item.safe && (
                  <button onClick={() => handleRedistribute(item)} className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 text-xs font-bold rounded-lg transition-colors flex items-center gap-2">
                    <HeartHandshake className="w-4 h-4" /> Give to NGO
                  </button>
                )}
                <div className="text-right">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Expires On</p>
                  <p className={`font-black text-lg ${item.safe ? 'text-gray-900' : 'text-red-600'}`}>
                    {new Date(item.expiry).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
                
                {item.safe ? (
                  <div className="hidden xl:block text-right border-l pl-4 border-gray-100 ml-4">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Nutrition</p>
                    <p className="text-xs font-bold text-indigo-600">Prot: {item.protein}</p>
                    <p className="text-xs font-bold text-amber-600">Vit: {item.vitamin}</p>
                  </div>
                ) : (
                  <button onClick={() => window.open('https://www.google.com/maps/search/hospital+near+me', '_blank')} className="px-3 py-2 bg-red-600 text-white text-xs font-bold rounded-lg ml-2 flex items-center gap-1 shadow-md hover:bg-red-700 animate-pulse">
                    <PhoneCall className="w-3 h-3" /> Hospital
                  </button>
                )}

                <button 
                  className="p-3 text-gray-400 hover:text-red-500 transition-colors ml-2 bg-gray-50 hover:bg-red-50 rounded-xl"
                  onClick={() => setItems(items.filter(i => i.id !== item.id))}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
          
          {items.length === 0 && (
            <div className="text-center py-16 bg-white rounded-[2rem] border border-dashed border-gray-200">
              <ThermometerSnowflake className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 font-medium text-lg">Your fridge and pantry are empty.</p>
            </div>
          )}
        </div>

      </div>

      {/* AI Nutrition Modal */}
      {showAIModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-[2rem] w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-health-50">
              <h3 className="text-2xl font-black text-health-900 flex items-center gap-2"><Sparkles className="text-health-600" /> AI Diet Planner</h3>
              <button onClick={() => setShowAIModal(false)} className="p-2 bg-white rounded-full text-gray-500 hover:text-gray-900 shadow-sm"><X className="w-5 h-5"/></button>
            </div>
            
            <div className="p-8 overflow-y-auto flex-grow">
              {!nutritionPlan ? (
                <form onSubmit={getAINutrition} className="space-y-6">
                   <p className="font-medium text-gray-500 mb-6">Create a personalized diet plan using the safe ingredients currently in your inventory.</p>
                   
                   <div className="grid grid-cols-2 gap-6">
                     <div>
                       <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Your Age</label>
                       <input type="number" min="1" max="100" value={age} onChange={e=>setAge(e.target.value)} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-health-500 outline-none font-bold" />
                     </div>
                     <div>
                       <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Inventory Available</label>
                       <div className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl font-medium text-gray-600 truncate">
                         {items.filter(i=>i.safe).map(i=>i.name).join(", ") || "Nothing"}
                       </div>
                     </div>
                   </div>

                   <div>
                      <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Health Conditions</label>
                      <input type="text" placeholder="e.g. Diabetes, Hypertension..." value={conditions} onChange={e=>setConditions(e.target.value)} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-health-500 outline-none font-medium" />
                   </div>

                   <button disabled={loadingAI || items.filter(i=>i.safe).length===0} type="submit" className="w-full py-4 bg-health-600 text-white rounded-xl font-black text-lg shadow-xl shadow-health-200 disabled:opacity-50 flex justify-center items-center gap-2">
                     {loadingAI ? 'Scanning Options...' : 'Generate Plan'}
                   </button>
                   {items.filter(i=>i.safe).length===0 && <p className="text-sm text-red-500 text-center font-bold">You need safe food in your inventory first.</p>}
                </form>
              ) : (
                <div className="animate-in slide-in-from-bottom flex flex-col h-full">
                  <div className="bg-health-50 text-health-900 p-6 rounded-2xl whitespace-pre-line leading-relaxed font-medium flex-grow border border-health-100">
                    {nutritionPlan}
                  </div>
                  <button onClick={() => setNutritionPlan('')} className="mt-6 w-full py-4 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl transition-colors">
                    Reset Planner
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
