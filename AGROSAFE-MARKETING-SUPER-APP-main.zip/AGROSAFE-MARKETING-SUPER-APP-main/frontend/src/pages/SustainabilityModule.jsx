import React from 'react';
import { Leaf, Droplets, Wind, Sprout, Award, ChevronRight, BarChart3, TreePine } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function SustainabilityModule() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      {/* Header */}
      <div className="bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 text-white py-16 px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
        <Leaf className="w-16 h-16 mx-auto mb-6 text-green-300 opacity-90 relative z-10" />
        <h1 className="text-4xl md:text-5xl font-black mb-4 relative z-10">{t('Climate & Sustainability', 'Climate & Sustainability')}</h1>
        <p className="text-xl text-green-100 max-w-2xl mx-auto opacity-90 font-medium relative z-10">
          {t('Track your carbon footprint, regenerate your soil, and get rewarded for eco-friendly farming.', 'Track your carbon footprint, regenerate your soil, and get rewarded for eco-friendly farming.')}
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 space-y-8">
        {/* Carbon Footprint Tracker */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <Wind className="w-8 h-8 text-teal-600" />
            <h2 className="text-2xl font-bold text-gray-900">{t('Carbon Footprint Tracker', 'Carbon Footprint Tracker')}</h2>
          </div>
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="col-span-1 md:col-span-1 flex flex-col items-center justify-center text-center">
                <div className="w-40 h-40 rounded-full border-8 border-teal-100 flex flex-col items-center justify-center mb-4 relative">
                  <div className="absolute inset-0 rounded-full border-8 border-teal-500 border-t-transparent -rotate-45"></div>
                  <span className="text-4xl font-black text-gray-900">{t('2.4', '2.4')}</span>
                  <span className="text-sm font-bold text-gray-500 uppercase">{t('Tons CO₂e', 'Tons CO₂e')}</span>
                </div>
                <h3 className="font-bold text-lg text-gray-900">{t('Your Farm\'s Emission', 'Your Farm\'s Emission')}</h3>
                <p className="text-sm text-emerald-600 font-bold mt-1">{t('15% below regional average', '15% below regional average')}</p>
              </div>
              <div className="col-span-1 md:col-span-2 space-y-4">
                <h3 className="font-bold text-gray-900 mb-2">{t('Emission Breakdown', 'Emission Breakdown')}</h3>
                <div>
                  <div className="flex justify-between text-sm mb-1"><span className="text-gray-600">{t('Fertilizer Use', 'Fertilizer Use')}</span><span className="font-bold">{t('45%', '45%')}</span></div>
                  <div className="w-full bg-gray-100 rounded-full h-2"><div className="bg-red-400 h-2 rounded-full" style={{width: '45%'}}></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1"><span className="text-gray-600">{t('Irrigation Energy', 'Irrigation Energy')}</span><span className="font-bold">{t('30%', '30%')}</span></div>
                  <div className="w-full bg-gray-100 rounded-full h-2"><div className="bg-amber-400 h-2 rounded-full" style={{width: '30%'}}></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1"><span className="text-gray-600">{t('Tractor Fuel', 'Tractor Fuel')}</span><span className="font-bold">{t('25%', '25%')}</span></div>
                  <div className="w-full bg-gray-100 rounded-full h-2"><div className="bg-gray-400 h-2 rounded-full" style={{width: '25%'}}></div></div>
                </div>
                <button className="mt-4 px-4 py-2 bg-teal-50 text-teal-700 rounded-lg font-bold text-sm w-full md:w-auto hover:bg-teal-100 transition-colors">
                  {t('Generate Carbon Credit Certificate', 'Generate Carbon Credit Certificate')}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* AI Sustainability Tips */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <Sprout className="w-8 h-8 text-emerald-600" />
            <h2 className="text-2xl font-bold text-gray-900">{t('AI Eco-Farming Advisor', 'AI Eco-Farming Advisor')}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center mb-4"><Droplets className="w-6 h-6 text-blue-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Water Conservation', 'Water Conservation')}</h3>
              <p className="text-gray-600 text-sm mb-4">{t('Switch to drip irrigation for your tomato crop. Expected water savings: 40%.', 'Switch to drip irrigation for your tomato crop. Expected water savings: 40%.')}</p>
              <a href="#" className="text-blue-600 font-bold text-sm flex items-center hover:underline">{t('View Guide', 'View Guide')} <ChevronRight className="w-4 h-4"/></a>
            </div>
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center mb-4"><TreePine className="w-6 h-6 text-amber-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Soil Regeneration', 'Soil Regeneration')}</h3>
              <p className="text-gray-600 text-sm mb-4">{t('Plant legumes (like moong) as a cover crop post-harvest to naturally restore nitrogen.', 'Plant legumes (like moong) as a cover crop post-harvest to naturally restore nitrogen.')}</p>
              <a href="#" className="text-amber-600 font-bold text-sm flex items-center hover:underline">{t('Watch Tutorial', 'Watch Tutorial')} <ChevronRight className="w-4 h-4"/></a>
            </div>
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center mb-4"><Leaf className="w-6 h-6 text-green-600"/></div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{t('Organic Transition', 'Organic Transition')}</h3>
              <p className="text-gray-600 text-sm mb-4">{t('Replace chemical pesticides with Neem oil spray for the current pest alert.', 'Replace chemical pesticides with Neem oil spray for the current pest alert.')}</p>
              <a href="#" className="text-green-600 font-bold text-sm flex items-center hover:underline">{t('Buy Neem Oil', 'Buy Neem Oil')} <ChevronRight className="w-4 h-4"/></a>
            </div>
          </div>
        </section>

        {/* Subsidy Integration */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <Award className="w-8 h-8 text-amber-500" />
            <h2 className="text-2xl font-bold text-gray-900">{t('Green Subsidies & Grants', 'Green Subsidies & Grants')}</h2>
          </div>
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-3xl p-8 border border-emerald-100">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <div>
                <h3 className="text-xl font-black text-gray-900 mb-2">{t('Paramparagat Krishi Vikas Yojana (PKVY)', 'Paramparagat Krishi Vikas Yojana (PKVY)')}</h3>
                <p className="text-gray-600 mb-4 max-w-2xl">{t('Financial assistance of ₹50,000 per hectare for 3 years to support organic farming transition.', 'Financial assistance of ₹50,000 per hectare for 3 years to support organic farming transition.')}</p>
                <div className="flex gap-3">
                  <span className="px-3 py-1 bg-white text-emerald-700 rounded-full text-xs font-bold border border-emerald-200">{t('Eligibility: Match', 'Eligibility: Match')}</span>
                  <span className="px-3 py-1 bg-white text-gray-600 rounded-full text-xs font-bold border border-gray-200">{t('Deadline: 30 Nov', 'Deadline: 30 Nov')}</span>
                </div>
              </div>
              <button className="px-8 py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 w-full md:w-auto shadow-lg shadow-emerald-200 shrink-0">
                {t('Auto-Fill Application', 'Auto-Fill Application')}
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
