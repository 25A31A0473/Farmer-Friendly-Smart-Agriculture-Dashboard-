import React, { useState } from 'react';
import { ShieldCheck, IndianRupee, TrendingUp, AlertCircle, CheckCircle2, ChevronRight, FileText, Smartphone, Users } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function FinancialHub() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('insurance');

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans">
      {/* Header */}
      <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-blue-900 text-white py-16 px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/field-bg.jpg')] opacity-10 bg-cover bg-center mix-blend-overlay"></div>
        <IndianRupee className="w-16 h-16 mx-auto mb-6 text-indigo-300 opacity-90 relative z-10" />
        <h1 className="text-4xl md:text-5xl font-black mb-4 relative z-10">{t('Agro Finance & Insurance', 'Agro Finance & Insurance')}</h1>
        <p className="text-xl text-indigo-100 max-w-2xl mx-auto opacity-90 font-medium relative z-10">
          {t('One-click access to crop insurance, micro-loans, and AI financial advisor.', 'One-click access to crop insurance, micro-loans, and AI financial advisor.')}
        </p>

        <div className="flex justify-center gap-4 mt-8 relative z-10">
          <button onClick={() => setActiveTab('insurance')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'insurance' ? 'bg-white text-indigo-900' : 'bg-indigo-900/50 text-white hover:bg-indigo-700'}`}>
            {t('Crop Insurance', 'Crop Insurance')}
          </button>
          <button onClick={() => setActiveTab('loans')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'loans' ? 'bg-white text-indigo-900' : 'bg-indigo-900/50 text-white hover:bg-indigo-700'}`}>
            {t('Micro-Loans', 'Micro-Loans')}
          </button>
          <button onClick={() => setActiveTab('advisor')} className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'advisor' ? 'bg-white text-indigo-900' : 'bg-indigo-900/50 text-white hover:bg-indigo-700'}`}>
            {t('AI Advisor', 'AI Advisor')}
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {activeTab === 'insurance' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('Available Schemes', 'Available Schemes')}</h2>
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 mb-6 flex flex-col md:flex-row gap-6 items-center hover:shadow-md transition-shadow">
                <div className="bg-blue-50 p-4 rounded-2xl shrink-0"><ShieldCheck className="w-10 h-10 text-blue-600" /></div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900">{t('PMFBY (Govt. Crop Insurance)', 'PMFBY (Govt. Crop Insurance)')}</h3>
                  <p className="text-gray-500 mt-1">{t('Comprehensive coverage against crop failure due to natural calamities.', 'Comprehensive coverage against crop failure due to natural calamities.')}</p>
                  <div className="flex gap-4 mt-3 text-sm font-medium">
                    <span className="text-blue-600 bg-blue-50 px-3 py-1 rounded-full">{t('Premium: 2% (Kharif)', 'Premium: 2% (Kharif)')}</span>
                    <span className="text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">{t('Coverage: ₹50,000/acre', 'Coverage: ₹50,000/acre')}</span>
                  </div>
                </div>
                <button className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 w-full md:w-auto">{t('Apply Now', 'Apply Now')}</button>
              </div>
              <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6 items-center hover:shadow-md transition-shadow">
                <div className="bg-amber-50 p-4 rounded-2xl shrink-0"><AlertCircle className="w-10 h-10 text-amber-600" /></div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900">{t('Weather Index Insurance', 'Weather Index Insurance')}</h3>
                  <p className="text-gray-500 mt-1">{t('Instant payouts based on local weather station data (drought/flood).', 'Instant payouts based on local weather station data (drought/flood).')}</p>
                  <div className="flex gap-4 mt-3 text-sm font-medium">
                    <span className="text-amber-600 bg-amber-50 px-3 py-1 rounded-full">{t('Smart Contract', 'Smart Contract')}</span>
                    <span className="text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">{t('Auto-Payout', 'Auto-Payout')}</span>
                  </div>
                </div>
                <button className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 w-full md:w-auto">{t('1-Click Enroll', '1-Click Enroll')}</button>
              </div>
            </div>
            <div className="col-span-1">
              <div className="bg-indigo-50 rounded-3xl p-6 border border-indigo-100">
                <h3 className="text-lg font-bold text-indigo-900 mb-4">{t('Active Policies', 'Active Policies')}</h3>
                <div className="bg-white p-4 rounded-2xl shadow-sm mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-gray-900">{t('Wheat (Rabi 2026)', 'Wheat (Rabi 2026)')}</span>
                    <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded text-xs font-bold">{t('Active', 'Active')}</span>
                  </div>
                  <p className="text-sm text-gray-500">{t('Policy ID: PMF-89234', 'Policy ID: PMF-89234')}</p>
                  <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between">
                    <span className="text-sm font-medium text-gray-600">{t('Sum Insured', 'Sum Insured')}</span>
                    <span className="font-bold text-gray-900">{t('₹1,20,000', '₹1,20,000')}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'loans' && (
          <div>
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{t('Micro-Loans & Credit', 'Micro-Loans & Credit')}</h2>
                <p className="text-gray-500">{t('Get instant capital for seeds, fertilizers, or equipment.', 'Get instant capital for seeds, fertilizers, or equipment.')}</p>
              </div>
              <div className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-xl font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5"/> {t('Credit Score: Excellent (780)', 'Credit Score: Excellent (780)')}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center">
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4"><Smartphone className="w-8 h-8"/></div>
                <h3 className="text-xl font-bold mb-2">{t('Kisan Credit Card (KCC)', 'Kisan Credit Card (KCC)')}</h3>
                <p className="text-gray-500 text-sm mb-4">{t('Interest as low as 4% p.a. with timely repayment subsidy.', 'Interest as low as 4% p.a. with timely repayment subsidy.')}</p>
                <button className="w-full py-2 bg-blue-50 text-blue-700 font-bold rounded-lg hover:bg-blue-100">{t('Apply Digitally', 'Apply Digitally')}</button>
              </div>
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center">
                <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4"><Users className="w-8 h-8"/></div>
                <h3 className="text-xl font-bold mb-2">{t('Community Lending', 'Community Lending')}</h3>
                <p className="text-gray-500 text-sm mb-4">{t('Peer-to-peer micro-loans backed by local farmer collectives.', 'Peer-to-peer micro-loans backed by local farmer collectives.')}</p>
                <button className="w-full py-2 bg-indigo-50 text-indigo-700 font-bold rounded-lg hover:bg-indigo-100">{t('View Offers', 'View Offers')}</button>
              </div>
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4"><TrendingUp className="w-8 h-8"/></div>
                <h3 className="text-xl font-bold mb-2">{t('Equipment Finance', 'Equipment Finance')}</h3>
                <p className="text-gray-500 text-sm mb-4">{t('Specialized loans for tractors, drip irrigation, and solar panels.', 'Specialized loans for tractors, drip irrigation, and solar panels.')}</p>
                <button className="w-full py-2 bg-emerald-50 text-emerald-700 font-bold rounded-lg hover:bg-emerald-100">{t('Explore', 'Explore')}</button>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 mb-4">{t('Repayment Dashboard', 'Repayment Dashboard')}</h3>
              <div className="flex flex-col md:flex-row items-center justify-between p-4 border border-gray-100 rounded-2xl bg-gray-50">
                <div className="flex items-center gap-4">
                  <div className="bg-red-50 text-red-600 p-3 rounded-xl"><AlertCircle className="w-6 h-6"/></div>
                  <div>
                    <h4 className="font-bold text-gray-900">{t('KCC Loan EMI', 'KCC Loan EMI')}</h4>
                    <p className="text-sm text-gray-500">{t('Due in 5 days (10 May 2026)', 'Due in 5 days (10 May 2026)')}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 mt-4 md:mt-0">
                  <div className="text-right">
                    <p className="font-black text-xl text-gray-900">{t('₹4,500', '₹4,500')}</p>
                    <p className="text-xs text-gray-500">{t('Amount Due', 'Amount Due')}</p>
                  </div>
                  <button className="px-6 py-2 bg-gray-900 text-white rounded-xl font-bold hover:bg-black">{t('Pay Now', 'Pay Now')}</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'advisor' && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-8 text-white mb-8 flex flex-col md:flex-row items-center gap-8 shadow-xl">
              <div className="bg-white/20 p-6 rounded-full shrink-0">
                <TrendingUp className="w-16 h-16 text-white"/>
              </div>
              <div>
                <h2 className="text-2xl font-black mb-2">{t('AI Financial Advisor', 'AI Financial Advisor')}</h2>
                <p className="text-blue-100 mb-4">{t('Based on your 5-acre farm profile and current market trends, here is your personalized financial plan for the upcoming Kharif season.', 'Based on your 5-acre farm profile and current market trends, here is your personalized financial plan for the upcoming Kharif season.')}</p>
                <button className="px-4 py-2 bg-white text-indigo-600 rounded-lg font-bold flex items-center gap-2 hover:bg-blue-50">
                  <FileText className="w-4 h-4"/> {t('Generate Full Report', 'Generate Full Report')}
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-emerald-500">
                <h3 className="font-bold text-lg mb-2">{t('Recommendation 1: Crop Insurance', 'Recommendation 1: Crop Insurance')}</h3>
                <p className="text-gray-600">{t('Opt for Weather Index Insurance this season. Predictions indicate a 60% chance of delayed monsoons in your district. This policy pays out automatically if rainfall is 20% below average.', 'Opt for Weather Index Insurance this season. Predictions indicate a 60% chance of delayed monsoons in your district. This policy pays out automatically if rainfall is 20% below average.')}</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-blue-500">
                <h3 className="font-bold text-lg mb-2">{t('Recommendation 2: Subsidy Claim', 'Recommendation 2: Subsidy Claim')}</h3>
                <p className="text-gray-600">{t('You are eligible for a 40% government subsidy on solar water pumps under the PM-KUSUM scheme. Apply before June 15th to reduce long-term energy costs.', 'You are eligible for a 40% government subsidy on solar water pumps under the PM-KUSUM scheme. Apply before June 15th to reduce long-term energy costs.')}</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-indigo-500">
                <h3 className="font-bold text-lg mb-2">{t('Recommendation 3: Loan Restructuring', 'Recommendation 3: Loan Restructuring')}</h3>
                <p className="text-gray-600">{t('Your current KCC loan balance is ₹45,000. Consider using profits from the upcoming tomato harvest to clear 50% of the principal to maintain your excellent credit score and access higher limits next year.', 'Your current KCC loan balance is ₹45,000. Consider using profits from the upcoming tomato harvest to clear 50% of the principal to maintain your excellent credit score and access higher limits next year.')}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
