import React from 'react';
import { Leaf, Users, ShieldCheck, HeartPulse, Globe, Sparkles, Zap, Shield, Target, MessageCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function About() {
  const { t } = useTranslation();

  return (
    <div className="bg-[#fafbfc] min-h-screen py-20 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-6xl mx-auto">
        
        {/* Hero Section */}
        <div className="text-center mb-24 animate-in fade-in slide-in-from-bottom duration-1000">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-nature-50 text-nature-700 rounded-full text-xs font-black uppercase tracking-widest mb-8 border border-nature-100">
             <Sparkles size={14} className="text-amber-500" /> Empowering the Ground Up
          </div>
          <h1 className="text-6xl lg:text-8xl font-black text-slate-900 tracking-tighter mb-8 leading-[0.9]">
            We Bridge <span className="text-nature-600 italic">Tradition</span> & Intelligence.
          </h1>
          <p className="mt-4 text-xl lg:text-2xl text-slate-500 max-w-3xl mx-auto leading-relaxed font-medium">
            AgroSafe AI is a unified super-platform designed to protect the most essential people on earth: Our Farmers.
          </p>
        </div>

        {/* Vision & Mission Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-32">
           <div className="bg-white p-12 rounded-[3rem] shadow-xl shadow-slate-200 border border-slate-50 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform duration-700 font-black text-9xl">01</div>
              <div className="bg-nature-600 w-16 h-16 rounded-3xl flex items-center justify-center mb-8 shadow-xl shadow-nature-200">
                 <Target className="text-white w-8 h-8" />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-4">Our Vision</h3>
              <p className="text-slate-500 text-lg leading-relaxed font-medium">
                 To eliminate rural isolation by providing every farmer with a world-class AI advisor that fits in their pocket, speaks their language, and acts on their behalf.
              </p>
           </div>
           <div className="bg-slate-900 p-12 rounded-[3rem] shadow-2xl shadow-slate-300 text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700 font-black text-9xl">02</div>
              <div className="bg-rose-600 w-16 h-16 rounded-3xl flex items-center justify-center mb-8 shadow-xl shadow-rose-900/50">
                 <Shield className="text-white w-8 h-8" />
              </div>
              <h3 className="text-3xl font-black mb-4 uppercase tracking-tighter">Our Mission</h3>
              <p className="text-slate-400 text-lg leading-relaxed font-medium">
                 Building a resilient agricultural ecosystem where climate risks are predicted, crop diseases are diagnosed instantly, and community health is never a compromise.
              </p>
           </div>
        </div>

        {/* Feature Pillars Section */}
        <div className="mb-32">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
             <div className="max-w-xl">
                <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-none mb-4">Powered by Gemini AI</h2>
                <p className="text-slate-500 font-medium">State-of-the-art multimodal intelligence integrated into every module.</p>
             </div>
             <div className="h-px bg-slate-100 flex-1 hidden md:block mb-6 ml-10" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { 
                icon: <Zap className="w-6 h-6 text-amber-600" />, 
                title: "Climate Pulse", 
                desc: "Predictive engine for floods and droughts with 94% accuracy.",
                bg: "bg-amber-50"
              },
              { 
                icon: <MessageCircle className="w-6 h-6 text-nature-600" />, 
                title: "Voice First", 
                desc: "Full voice synthesis and recognition for non-literate accessibility.",
                bg: "bg-nature-50"
              },
              { 
                icon: <ShieldCheck className="w-6 h-6 text-sky-600" />, 
                title: "Safety Vault", 
                desc: "Expiry tracking and medicine safety for rural families.",
                bg: "bg-sky-50"
              },
              { 
                icon: <Leaf className="w-6 h-6 text-emerald-600" />, 
                title: "Vision Brain", 
                desc: "Gemini Vision powered image diagnosis for crop pathogens.",
                bg: "bg-emerald-50"
              },
              { 
                icon: <HeartPulse className="w-6 h-6 text-rose-600" />, 
                title: "Health Nav", 
                desc: "Instant symptom triage and emergency ambulance protocols.",
                bg: "bg-rose-50"
              },
              { 
                icon: <Users className="w-6 h-6 text-slate-600" />, 
                title: "Community Blast", 
                desc: "SMS & Voice broadcast to bridge the connectivity gap.",
                bg: "bg-slate-100"
              }
            ].map((feature, i) => (
              <div key={i} className={`${feature.bg} p-8 rounded-[2rem] border border-black/5 hover:-translate-y-2 transition-all duration-300 group`}>
                <div className="bg-white w-12 h-12 rounded-2xl flex items-center justify-center mb-6 shadow-sm group-hover:shadow-md transition">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600 text-sm font-medium leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Manifesto */}
        <div className="bg-nature-600 rounded-[4rem] p-16 lg:p-24 text-center text-white relative overflow-hidden">
           <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-transparent" />
           <Globe size={300} className="absolute -bottom-20 -left-20 text-white/5" />
           <div className="relative z-10 max-w-2xl mx-auto">
             <h2 className="text-4xl lg:text-6xl font-black mb-6 tracking-tight">The future is fertile.</h2>
             <p className="text-nature-100 text-xl font-medium opacity-90 mb-10">
               We believe that the smartest technology should be available to those who work the hardest.
             </p>
             <div className="w-16 h-1 bg-white/30 mx-auto rounded-full" />
           </div>
        </div>
        
        <div className="text-center py-12">
            <p className="text-slate-400 text-xs font-black uppercase tracking-[0.3em]">Project AgroSafe AI • Final Release v2.5</p>
        </div>
      </div>
    </div>
  );
}
