import os
import json
import google.generativeai as genai
from groq import Groq
from dotenv import load_dotenv

# Load main backend env for API key
load_dotenv("../.env")

API_KEY = os.getenv("GOOGLE_API_KEY")
IS_GROQ = API_KEY.startswith("gsk_") if API_KEY else False

if not API_KEY:
    raise ValueError("Valid GOOGLE_API_KEY is required in .env")

if not IS_GROQ:
    genai.configure(api_key=API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
else:
    groq_client = Groq(api_key=API_KEY)

# Base EN File
BASE_JSON_PATH = "../../frontend/public/locales/en/translation.json"

with open(BASE_JSON_PATH, "r", encoding="utf-8") as f:
    en_data = json.load(f)

LANGUAGES = {
    "hi": "Hindi",
    "bn": "Bengali",
    "te": "Telugu",
    "mr": "Marathi",
    "ta": "Tamil",
    "ur": "Urdu",
    "gu": "Gujarati",
    "kn": "Kannada"
}

def translate_json(data, target_lang):
    prompt = f"""
    You are an expert translator. Translate ALL string values in the following JSON into {target_lang}.
    Absolutely keep the EXACT same JSON structure and keys (in English). ONLY translate the values.
    Return ONLY valid raw JSON string. Do NOT output markdown backticks (like ```json), just the plain JSON text starting with {{ and ending with }}.

    JSON to translate:
    {json.dumps(data, indent=2)}
    """
    try:
        if IS_GROQ:
            chat_completion = groq_client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model="llama-3.3-70b-versatile",
            )
            raw = chat_completion.choices[0].message.content
        else:
            response = model.generate_content(prompt)
            raw = response.text
            
        raw = raw.replace("```json", "").replace("```", "").strip()
        
        # Quick cleanup in case LLM prepends text 
        start_idx = raw.find("{")
        end_idx = raw.rfind("}")
        if start_idx != -1 and end_idx != -1:
            raw = raw[start_idx:end_idx+1]
            
        return json.loads(raw)
    except Exception as e:
        print(f"Failed to translate to {target_lang}: {e}")
        return data

print("Starting Auto-Translation Sweep...")

for code, lang in LANGUAGES.items():
    print(f"Translating to {lang} ({code})...")
    trans_data = translate_json(en_data, lang)
    
    # Save to file
    out_dir = f"../../frontend/public/locales/{code}"
    os.makedirs(out_dir, exist_ok=True)
    out_path = f"{out_dir}/translation.json"
    
    with open(out_path, "w", encoding="utf-8") as out_f:
        json.dump(trans_data, out_f, ensure_ascii=False, indent=2)
    
    print(f"Saved: {out_path}")

print("✅ Auto-Translation Complete!")
